<?php

namespace Dsn\Element;



class GridaRegisterElement {

	use GridaRenderSectionElement;


	public function registerWidgetSection() {

		/**
		 * Add Controller For Element
		 */
		add_action( 'elementor/element/section/section_layout/before_section_start', [
			$this,
			'register_widgets_before_section',
		], 10, 2 );
		add_action( 'elementor/element/column/layout/before_section_start', [
			$this,
			'register_widgets_before_section',
		], 10, 2 );

	}


	/** @var \Elementor\Element_Base $element */
	public function register_widgets_before_section( $element, $args ) {

		$control = new \GridaControl( $element );

		$is_section = $element->get_name() === 'section';
		$is_column  = $element->get_name() === 'column';


		$element->start_controls_section(
			'grida_section_space',
			[
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
				'label' => __( 'Grida Style', 'grida' ),
			]
		);

		$this->addSpaceSection( $element );

		$element->add_control( 'hr_1', [ 'type' => \Elementor\Controls_Manager::DIVIDER, ] );



		if ( $is_column ) {
			$this->addlayout( $element );
		} elseif ( $is_section ) {
			$this->addlayout( $element, [ 'full-width' => esc_html__( 'Ful Width', 'grida' ) ] );
		}
		$element->add_control( 'hr_2', [ 'type' => \Elementor\Controls_Manager::DIVIDER, ] );
		$this->addStyleBg( $element, $control );


		$element->end_controls_section();


		if ( $is_column ) {
			$this->column_widget( $element );

		}



		if ( $is_section ) {
			$this->section_widget( $element, $control );
			$this->paginationRight( $control, $element );
		}


	}


	private function paginationRight( \GridaControl $control, \Elementor\Element_Base $element ) {
		$element->start_controls_section(
			'grida_right_paginate',
			[
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
				'label' => __( 'Right Pagination', 'grida' ),
			]
		);

		$control->addSwitcher( 'use_section_paginate' )
		        ->setLabel( esc_html__( "Use Section Paginate", 'grida' ) )
		        ->setReturn_value( "1" )
		        ->get();

		$control->addText( 'text_paginate' )
		        ->setLabel( esc_html__( "Text Paginate", 'grida' ) )
		        ->setLabelBlock()
		        ->setConditions( 'use_section_paginate', '1' )
		        ->get();

		$element->end_controls_section();

	}


	/**
	 * @param $element
	 * Margin And Padding Section
	 */
	private function addSpaceSection( $element ) {

		$element->add_control(
			'dsn_col_margin',
			[
				'label' => __( 'Margin', 'grida' ),

				'type'         => \Elementor\Controls_Manager::CHOOSE,
				'options'      => [
					'mt-section'     => [
						'title' => __( 'Margin Top', 'grida' ),
						'icon'  => 'eicon-v-align-top',
					],
					'section-margin' => [
						'title' => __( 'Margin Top & Bottom ', 'grida' ),
						'icon'  => 'eicon-v-align-middle',
					],

					'mb-section' => [
						'title' => __( 'Margin Bottom', 'grida' ),
						'icon'  => 'eicon-v-align-bottom',
					],

				],
				'default'      => '',
				'prefix_class' => '',
			]
		);

		$element->add_control(
			'dsn_col_padding',
			[
				'label' => __( 'Padding', 'grida' ),

				'type'         => \Elementor\Controls_Manager::CHOOSE,
				'options'      => [
					'pt-section'      => [
						'title' => __( 'Padding Top', 'grida' ),
						'icon'  => 'eicon-v-align-top',
					],
					'section-padding' => [
						'title' => __( 'Padding Top & Bottom', 'grida' ),
						'icon'  => 'eicon-v-align-middle',
					],

					'pb-section' => [
						'title' => __( 'Padding Bottom', 'grida' ),
						'icon'  => 'eicon-v-align-bottom',
					],

				],
				'default'      => '',
				'prefix_class' => '',
			]
		);

	}

	/**
	 * @param $element
	 * @param array $args
	 */
	private function addlayout( $element, array $args = array() ) {


		$option = array_merge( [
			''                                  => __( 'Default', 'grida' ),
			'dsn-container'                     => __( 'Wide Page', 'grida' ),
			'container'                         => __( 'Container Page', 'grida' ),
			'dsn-container dsn-right-container' => __( 'Right Container Page', 'grida' ),
			'dsn-container dsn-left-container'  => __( 'Left Container Page', 'grida' ),
		], $args );

		$element->add_control(
			'dsn_width_layout',
			[
				'label'        => __( 'Width Layout', 'grida' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => '',
				'options'      => $option,
				'prefix_class' => '',
			]
		);

	}


	/**
	 * @param $element \Elementor\Element_Base
	 * @param $control \GridaControl
	 */
	private function addStyleBg( $element, $control ) {

		$element->add_control(
			'background_dsn_style_ver',
			[
				'label'        => __( 'Version Background Section', 'grida' ),
				'type'         => \Elementor\Controls_Manager::SELECT,
				'default'      => '',
				'description'  => __( 'If you choose the wallpaper version, it is best to choose the type of background section', 'grida' ),
				'label_block'  => true,
				'options'      => [
					''             => __( 'Default', 'grida' ),
					'v-light'      => __( 'Light', 'grida' ),
					'v-light-head' => __( 'Light (Static)', 'grida' ),
					'v-dark'       => __( 'Dark', 'grida' ),
					'v-dark-head'  => __( 'Dark  (Static)', 'grida' ),
				],
				'prefix_class' => '',

			]
		);

		$element->add_control(
			'background_dsn_style',
			[
				'label'       => __( 'Background Section', 'grida' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'background-transparent',
				'label_block' => true,

				'options'      => [
					'background-transparent'     => __( 'Default', 'grida' ),
					'background-main'            => __( 'Background Main', 'grida' ),
					'background-section'         => __( 'Background Section', 'grida' ),
					'background-theme'           => __( 'Background Theme', 'grida' ),
					'background-gradient-left'   => __( 'Background Gradient Left', 'grida' ),
					'background-gradient-bottom' => __( 'Background Gradient Bottom', 'grida' ),
					'background-gradient-right'  => __( 'Background Gradient Right', 'grida' ),
					'background-gradient-top'    => __( 'Background Gradient Top', 'grida' ),
				],
				'prefix_class' => '',

			]
		);


	}


	/** @var \Elementor\Element_Base $element */
	private function column_widget( $element ) {

		$element->start_controls_section(
			'grida_section_animate',
			[
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
				'label' => __( 'Grida Animate', 'grida' ),
			]
		);

		$element->add_control( 'data_animation_section', [
			'label'        => __( 'Animate Section', 'grida' ),
			'type'         => \Elementor\Controls_Manager::SWITCHER,
			'description'  => __( 'you can turn on animation in the children element', 'grida' ),
			'return_value' => '1',
		] );


		$element->end_controls_section();

	}

	/**
	 * @param \Elementor\Element_Base $element
	 * @param \GridaControl $control ;
	 */
	private function section_widget( $element, $control ) {

		$this->sectionBgControl( $element, $control );
		$this->changeColor( $element, $control );
	}

	/**
	 * @param \Elementor\Element_Base $element
	 * @param \GridaControl $control ;
	 */
	private function changeColor( $element, $control ) {

		$element->start_controls_section(
			'grida_change_color',
			[
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
				'label' => __( 'grida Change Color Section', 'grida' ),
			]
		);
		$control->addSwitcher( 'dsn_change_color' )
		        ->setLabel( __( 'Change Color', 'grida' ) )
		        ->get();

		$control->getTrigerHock( 'triggerhook_change_color', 'top' )
		        ->setConditions( 'dsn_change_color', '1' )
		        ->get();

		$element->end_controls_section();


	}

	/**
	 * @param \Elementor\Element_Base $element
	 * @param \GridaControl $control ;
	 */
	private function sectionBgControl( $element, $control ) {


		$element->start_controls_section(
			'grida_section_bg',
			[
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				'label' => __( 'Grida Parallax Background', 'grida' ),
			]
		);

		$control->addImage()->get()
		        ->addImageSzie()->getGroup();

//		$control->addHidden( 'classDark' )
//		        ->setDefault( 'v-dark-head' )
//		        ->setCondition( [ 'image[id]!' => '' ] )
//		        ->setPrefix_class()
//		        ->get();

		/**
		 * Overlay Bg
		 */
		$control->addPopover( 'opacity_overlay_popover' )
		        ->setLabel( __( "Background Overlay", 'elementor' ) )
		        ->setSeparator( "before" )
		        ->get();

		$element->start_popover();

		$control->addColor( 'color_overlay' )
		        ->setLabel( __( 'Color Overlay' ) )
		        ->get();

		$control->addNumberSlider( 'opacity_overlay', 0, 10, 1 )
		        ->setLabel( __( 'Opacity Overlay' ) )
		        ->setDefaultRange( 4 )
		        ->get();

		$element->end_popover();


		$control->addBlendMode( 'bland_overlay', '.img-box-parallax img' )
		        ->get();


		$control->addPopover( 'position_image' )
		        ->setLabel( __( 'Position Image', 'grida' ) )
		        ->get();
		$element->start_popover();

		$control->addNumber( 'position_image_position_x', 1, 100, 10 )
		        ->setLabel( __( 'Position X', 'grida' ) )
		        ->setDefault( 50 )
		        ->get();


		$control->addNumber( 'position_image_position_y', 1, 100, 10 )
		        ->setLabel( __( 'Position Y', 'grida' ) )
		        ->setDefault( 50 )
		        ->get();

		$element->end_popover();
		$this->getEntranceAnimationImage( $control );

		$element->end_controls_section();


	}


	private function getEntranceAnimationImage( $control ) {


		$control->addChose( 'direction_animate_image' )
		        ->setLabel( __( "Direction", 'grida' ) )
		        ->setOptionChoose( 'has-opposite-direction', __( 'Up', 'grida' ), 'eicon-arrow-up' )
		        ->setOptionChoose( 'has-direction', __( 'Down', 'grida' ), 'eicon-arrow-down' )
		        ->setDefault( 'has-direction' )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSelect( 'animate_image_style', [
			''                 => __( "Default", 'grida' ),
			'has-bigger-scale' => __( "Scale Down", 'grida' ),
			'has-scale'        => __( "Scale Up", 'grida' ),
		] )
		        ->setLabel( __( "Entrance Animation Type", 'grida' ) )
		        ->setDefault( '' )->get();


		$control->getTrigerHock( 'animate_image_triggerhook', 1, array(), true )
		        ->get();


		$control->addNumberSlider( 'speed_animation_image', 0, 100, 10 )
		        ->setDefaultRange( 30 )
		        ->setLabel( __( 'Speed', 'grida' ) )
		        ->get();

	}


}