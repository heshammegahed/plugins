<?php

namespace Dsn\Element;


class GridaSlider extends \Elementor\Widget_Base {

	use \Dsn\Element\Grida_Widget_Base;
	use \Dsn\Element\gridaSwiper;

	private $swiper_option = array();
	/**
	 * @var null|\gridaShortCode
	 */
	private $shortcode = null;

	protected  $style_item = '.swiper-slide';

	protected $parallax = null;

	protected array $condition_parallax = [];

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_sliders';
	}


	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'slider', 'media', 'content', 'swiper' ] );
	}


	protected function _register_controls() {
		$this->start_controls_section(
			'content_swiper_section',
			[
				'label' => esc_html__( 'Slides', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->_register_controls_content_before();
		$this->_register_controls_content();
		$this->_register_controls_content_after();

		$this->end_controls_section();


		/**
		 *
		 */
		$this->_parallax_controller();
		$this->_content_pagination_Navigation();
		$this->getAdvancedOption();
		$this->getStyleOption();
	}


	protected function _register_controls_content() {
	}

	protected function _register_controls_content_before() {
	}

	/**
	 * After Content
	 */
	protected function _register_controls_content_after() {
		$control = $this->getControl();


		$control->addSwitcher( 'autoHeight' )
		        ->setLabel( esc_html__( 'auto Height', 'grida' ) )
		        ->setDescription( esc_html__( 'Set to true and slider wrapper will adapt its height to the height of the currently active slide', 'grida' ) )
		        ->setDefault( '1' )
		        ->setConditions( 'direction', 'horizontal' )
		        ->setSeparator( 'before' )
		        ->get();

		$control->addSlider( 'height', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Height', 'elementor' ) )
		        ->setConditions( 'direction', 'horizontal' )
		        ->setSelectors( '.swiper-slide', 'height: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSlider( 'height_swiper', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Height swiper', 'elementor' ) )
		        ->setConditions( 'direction', 'vertical' )
		        ->setSelectors( '.swiper-container-vertical', 'height: {{SIZE}}{{UNIT}};min-height: {{SIZE}}{{UNIT}};' )
		        ->setDefaultRange( 70, 'vh' )
		        ->getResponsive();


	}


	/**
	 * parallex Content
	 */
	protected function _parallax_controller() {

		$use_parallax = $this->parallax !== null && is_array( $this->parallax ) && count( $this->parallax );

		if ( ! $use_parallax ) {
			return;
		}


		$control = $this->getControl();

		$this->start_controls_section(
			'parallax_swiper_section',
			[
				'label'     => esc_html__( 'Parallax', 'grida' ),
				'tab'       => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => $this->condition_parallax
			]
		);

		$control->addSwitcher( 'parallax' )
		        ->setLabel( esc_html__( 'parallax', 'grida' ) )
		        ->setDescription( esc_html__( 'Enable, if you want to use "parallaxed" elements inside of slider.', 'grida' ) )
		        ->get();


		$this->start_controls_tabs( 'parallax_tab_swiper', [
			'condition' => [ 'parallax' => '1' ],
		] );

		foreach ( $this->parallax as $key => $value ):

			$this->start_controls_tab( $key, [
				'label' => $value,
			] );

			$control->addSlider( 'parallax_' . $key, [
				'default'    => [
					'unit' => '%',
					'size' => 0,
				],
				'size_units' => [ '%', 'px' ],
				'range'      => [
					'%'  => [
						'min' => - 100,
						'max' => 100,
					],
					'px' => [
						'min' => - 1000,
						'max' => 1000,
					],

				],
			] )
			        ->setLabel( esc_html__( 'parallax', 'grida' ) )
			        ->setDescription( esc_html__( 'enable transform-translate parallax transition.', 'grida' ) )
			        ->get();

			$control->addNumberSlider( 'scale_' . $key, 0, 2, 0.1 )
			        ->setLabel( esc_html__( 'Scale', 'grida' ) )
			        ->setDefaultRange( 1 )
			        ->setDescription( esc_html__( 'scale ratio of the parallax element when it is in "inactive" (not on active slide) state', 'grida' ) )
			        ->get();

			$control->addNumberSlider( 'opacity_' . $key, 0, 1, 0.1 )
			        ->setLabel( esc_html__( 'Opacity', 'grida' ) )
			        ->setDefaultRange( 1 )
			        ->setDescription( esc_html__( 'opacity of the parallax element when it is in "inactive" (not on active slide) state', 'grida' ) )
			        ->get();


			$control->addNumberSlider( 'duration_' . $key, 0, 10000, 100 )
			        ->setLabel( esc_html__( 'Duration', 'grida' ) )
			        ->setDescription( esc_html__( 'custom transition duration for parallax elements', 'grida' ) )
			        ->get();


			$this->end_controls_tab();
		endforeach;


		$this->end_controls_tabs();


		$this->end_controls_section();

	}


	/**
	 * Get Control Over
	 * Use In Child Class
	 *
	 * @param string $img_bland
	 */
	protected function getOverlay( $img_bland = '.img-box-parallax img' ) {
		$control = $this->getControl();


		$control->addColor( 'color_overlay' )
		        ->setLabel( __( 'Color Overlay' ) )
		        ->setSeparator( "before" )
		        ->get();

		$control->addNumberSlider( 'opacity_overlay', 0, 10, 1 )
		        ->setLabel( __( 'Opacity Overlay' ) )
		        ->setDefaultRange( 0 )
		        ->get();


		$control->addBlendMode( 'bland_overlay', $img_bland )
		        ->get();

	}


	/**
	 * @param $element
	 * @param $id
	 *
	 * @return $this
	 */
	public function add_parallax_attributes( $element, $id, \gridaShortCode $shortcode ) {
		$this->shortcode = $shortcode;
		if ( ! $this->shortcode->getVal( 'parallax' ) ) {
			return $this;
		}

		$parallax = $this->shortcode->getVal( 'parallax_' . $id, array( 'unit' => '%', 'size' => 0 ) );
		$size     = $this->shortcode->getOptionArray( $parallax, 'size' );
		if ( $size ):
			$unit = $this->shortcode->getOptionArray( $parallax, 'unit', '%' );
			if ( $unit !== '%' ) {
				$unit = '';
			}

			$this->add_render_attribute( $element, 'data-swiper-parallax', $size . $unit );
		endif;
		$scale = $this->shortcode->getValueNumberSlide( 'scale_' . $id, 1 );

		if ( $scale !== 1 && $scale !== '' ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-scale', $scale );
		}

		$opacity = $this->shortcode->getValueNumberSlide( 'opacity_' . $id, 1 );
		if ( $opacity < 1 && $opacity !== '' ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-opacity', $opacity );
		}

		if ( $duration_ = $this->shortcode->getValueNumberSlide( 'duration_' . $id ) ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-duration', $duration_ );
		}


		$this->add_render_attribute( $element, 'class', 'dsn-swiper-parallax-transform' );

		return $this;
	}


	/**
	 *
	 */
	protected function getStyleOption() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_swiper_section',
			[
				'label' => esc_html__( 'Layout', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addNumberSlider( 'slidesPerView', 1, 9, 0.5 )
		        ->setLabel( esc_html__( 'slides PerView', 'grida' ) )
		        ->setDescription( esc_html__( "Number of slides per view (slides visible at the same time on slider's container).", 'grida' ) )
		        ->setDefaultDesktopRange( 1 )
		        ->setDefaultTabletRange( 1 )
		        ->setDefaultMobileRange( 1 )
		        ->getResponsive();

		$control->addSwitcher( 'centeredSlides' )
		        ->setLabel( esc_html__( 'Centered Slides', 'grida' ) )
		        ->setDescription( esc_html__( 'If true, then active slide will be centered, not always on the left side.', 'grida' ) )
		        ->getResponsive();


		$control->addNumberSlider( 'slidesPerGroup', 1, 9, 1 )
		        ->setLabel( esc_html__( 'Slides to Scroll', 'grida' ) )
		        ->setDescription( esc_html__( 'Set numbers of slides to define and enable group sliding. Useful to use with slidesPerView > 1', 'grida' ) )
		        ->setDefaultDesktopRange( 1 )
		        ->setDefaultTabletRange( 1 )
		        ->setDefaultMobileRange( 1 )
		        ->getResponsive();

		$control->addNumberSlider( 'spaceBetween', 0, 100, 10 )
		        ->setLabel( esc_html__( 'Space Between', 'grida' ) )
		        ->setDescription( esc_html__( 'Distance between slides in px.', 'grida' ) )
		        ->setDefaultDesktopRange( 0 )
		        ->setDefaultTabletRange( 0 )
		        ->setDefaultMobileRange( 0 )
		        ->getResponsive();


		$this->end_controls_section();

		$this->start_controls_section(
			'style_swiper_slides',
			[
				'label' => esc_html__( 'slides', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addColor( 'bg_color_item' )
		        ->setLabel( esc_html__( "background Color", 'grida' ) )
		        ->setSelectors( $this->style_item, 'background-color:{{VALUE}};' )
		        ->get();

		$control->addSelect( 'bg_ver_item', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Slide', 'grida' ) )
		        ->setLabelBlock()
		        ->setConditions( 'bg_color_item', '' )
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_item', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Slide', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-transparent' )
		        ->setConditions( 'bg_color_item', '' )
		        ->setSeparator( "after" )
		        ->get();


		$this->setFilterSwiper();


		$this->add_responsive_control(
			'item_padding_swiper',
			[
				'label'      => __( 'Padding', 'elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ' . $this->style_item => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'      => 'border',
				'selector'  => '{{WRAPPER}} ' . $this->style_item,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label'      => __( 'Border Radius', 'elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ' . $this->style_item => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow',
				'selector' => '{{WRAPPER}} ' . $this->style_item,
			]
		);


		$this->end_controls_section();


	}

	/**
	 *
	 */
	public function getAdvancedOption() {

		$control = $this->getControl();
		$this->start_controls_section(
			'setting_swiper_section',
			[
				'label'     => esc_html__( 'Slides', 'grida' ),
				'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
				'condition' => $this->condition_parallax
			]
		);


		$control->addNumberSlider( 'speed', 300, 5000, 100 )
		        ->setLabel( esc_html__( 'Speed', 'grida' ) )
		        ->setDescription( esc_html__( 'Duration of transition between slides (in ms).', 'grida' ) )
		        ->setDefaultDesktopRange( 1000 )
		        ->setDefaultTabletRange( 1000 )
		        ->setDefaultMobileRange( 1000 )
		        ->getResponsive();

		$control->addSelect( 'direction', [
			'horizontal' => esc_html__( 'horizontal', 'grida' ),
			'vertical'   => esc_html__( 'Vertical', 'grida' ),
		] )
		        ->setDefault( 'horizontal' )
		        ->setLabel( esc_html__( 'Direction', 'grida' ) )
		        ->setDescription( esc_html__( "Can be 'horizontal' or 'vertical' (for vertical slider).", 'grida' ) )
		        ->get();

		$control->addSelect( 'effect', [
			'slide'     => esc_html__( 'slide', 'grida' ),
			'fade'      => esc_html__( 'fade', 'grida' ),
			'cube'      => esc_html__( 'cube', 'grida' ),
			'coverflow' => esc_html__( 'coverflow', 'grida' ),
			'flip'      => esc_html__( 'flip', 'grida' ),
			'cards'      => esc_html__( 'Cards', 'grida' ),
		] )
		        ->setDefault( 'slide' )
		        ->setLabel( esc_html__( 'Effect', 'grida' ) )
		        ->setDescription( esc_html__( 'Transition effect. Can be "slide", "fade", "cube", "coverflow" or "flip"', 'grida' ) )
		        ->get();

		$control->addSwitcher( 'loop' )
		        ->setLabel( esc_html__( 'loop', 'grida' ) )
		        ->setDescription( esc_html__( 'Set to true to enable continuous loop mode', 'grida' ) )
		        ->get();


		$control->addSwitcher( 'allowTouchMove' )
		        ->setLabel( esc_html__( 'allow Touch Move', 'grida' ) )
		        ->setDescription( esc_html__( 'If false, then the only way to switch the slide is use of external API functions like slidePrev or slideNext', 'grida' ) )
		        ->setDefault( "1" )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSwitcher( 'grabCursor' )
		        ->setLabel( esc_html__( 'Grab Cursor', 'grida' ) )
		        ->setDescription( esc_html__( 'This option may a little improve desktop usability. If true, user will see the "grab" cursor when hover on Swiper.', 'grida' ) )
		        ->get();

		$control->addSwitcher( 'slideToClickedSlide' )
		        ->setLabel( esc_html__( 'Slide To Clicked Slide', 'grida' ) )
		        ->setDescription( esc_html__( 'Set to true and click on any slide will produce transition to this slide', 'grida' ) )
		        ->get();


		$this->end_controls_section();

		$this->start_controls_section(
			'setting_autoplay_swiper_section',
			[
				'label'     => esc_html__( 'AutoPlay Option', 'grida' ),
				'tab'       => \Elementor\Controls_Manager::TAB_SETTINGS,
				'condition' => $this->condition_parallax
			]
		);


		$control->addSwitcher( 'autoplay' )
		        ->setLabel( esc_html__( 'autoplay', 'grida' ) )
		        ->setDescription( esc_html__( 'Object with autoplay parameters or boolean true to enable with default settings', 'grida' ) )
		        ->get();

		$control->addNumber( 'delay', 0, '', 1000 )
		        ->setLabel( esc_html__( 'delay', 'grida' ) )
		        ->setDescription( esc_html__( 'Distance between slides in px.', 'grida' ) )
		        ->setDefault( 2000 )
		        ->setConditions( 'autoplay', '1' )
		        ->get();

		$control->addSwitcher( 'disableOnInteraction' )
		        ->setLabel( esc_html__( 'Disable On Interaction', 'grida' ) )
		        ->setDescription( esc_html__( 'Set to false and autoplay will not be disabled after user interactions (swipes), it will be restarted every time after interaction', 'grida' ) )
		        ->setDefault( '1' )
		        ->setConditions( 'autoplay', '1' )
		        ->get();

		$control->addSwitcher( 'reverseDirection' )
		        ->setLabel( esc_html__( 'Reverse Direction', 'grida' ) )
		        ->setDescription( esc_html__( 'Enables autoplay in reverse direction', 'grida' ) )
		        ->setConditions( 'autoplay', '1' )
		        ->get();

		$control->addSwitcher( 'stopOnLastSlide' )
		        ->setLabel( esc_html__( 'Stop On Last Slide', 'grida' ) )
		        ->setDescription( esc_html__( 'Enable this parameter and autoplay will be stopped when it reaches last slide (has no effect in loop mode)', 'grida' ) )
		        ->setConditions( 'autoplay', '1' )
		        ->get();


		$control->addSwitcher( 'waitForTransition' )
		        ->setLabel( esc_html__( 'Wait For Transition', 'grida' ) )
		        ->setDescription( esc_html__( 'When enabled autoplay will wait for wrapper transition to continue. Can be disabled in case of using Virtual Translate when your slider may not have transition', 'grida' ) )
		        ->setDefault( '1' )
		        ->setConditions( 'autoplay', '1' )
		        ->get();


		$this->end_controls_section();

	}


	protected function _content_pagination_Navigation() {


		$control = $this->getControl();

		$this->start_controls_section(
			'paginate_swiper_section',
			[
				'label' => esc_html__( 'Pagination & Navigation', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addSwitcher( 'show_navigation' )
		        ->setLabel( esc_html__( "Navigation (Arrow)", 'grida' ) )
		        ->get();

		$control->addSelect( 'show_pagination', [
			''            => esc_html__( 'None', 'grida' ),
			'bullets'     => esc_html__( 'bullets', 'grida' ),
			'fraction'    => esc_html__( 'fraction', 'grida' ),
			'progressbar' => esc_html__( 'progressbar', 'grida' ),
		] )
		        ->setLabel( esc_html__( 'Pagination', 'cona' ) )
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'type_bullets', [
			''                  => esc_html__( 'Style 1', 'grida' ),
			'dsn-swiper-circle' => esc_html__( 'Style 2', 'grida' ),
		] )
		        ->setLabel( esc_html__( 'Type Bullets', 'grida' ) )
		        ->setDefault( '' )
		        ->setConditions( 'show_pagination', 'bullets' )
		        ->get();

		$control->getJustifyContent( 'justify_content' )
		        ->setDefault( 'justify-content-between' )
		        ->setConditions( 'show_navigation', '===', '1' )
		        ->setConditions( 'show_pagination', '!=', '' )
		        ->get();


		$this->end_controls_section();

	}

	public function get_content_paginate_render( $attr = null ) {
		$out             = '';
		$show_navigation = $this->shortcode->getVal( 'show_navigation' );
		$show_pagination = $this->shortcode->getVal( 'show_pagination' );
		$type_bullets    = $this->shortcode->getVal( 'type_bullets' );

		if ( ! $show_navigation && ! $show_pagination ) {
			return '';
		}

		if ( $show_navigation ) {
			$out .= '<div class="swiper-prev">
                                            <div class="prev-container">
                                                <div class="container-inner">
                                                    <div class="triangle"></div>
                                                    <svg class="circle" xmlns="http://www.w3.org/2000/svg"
                                                        viewBox="0 0 24 24">
                                                        <g class="circle-wrap" fill="none" stroke-width="1"
                                                            stroke-linejoin="round" stroke-miterlimit="10">
                                                            <circle cx="12" cy="12" r="10.5"></circle>
                                                        </g>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>';

		}

		if ( $show_pagination ) {
			$out .= sprintf( '<div class="swiper-pagination %s mr-30 ml-30 heading-color" data-dsn-type="%s"></div>', $type_bullets, $show_pagination );
		}

		if ( $show_navigation ) {
			$out .= '<div class="swiper-next">
                                        <div class="next-container">
                                            <div class="container-inner">
                                                <div class="triangle"></div>
                                                <svg class="circle" xmlns="http://www.w3.org/2000/svg" width="24"
                                                     height="24" viewBox="0 0 24 24">
                                                    <g class="circle-wrap" fill="none" stroke-width="1"
                                                       stroke-linejoin="round" stroke-miterlimit="10">
                                                        <circle cx="12" cy="12" r="10.5"></circle>
                                                    </g>
                                                </svg>
                                            </div>
                                        </div>
                                    </div>';
		}


		$this->add_render_attribute( 'dsn_swiper_paginate', 'class', 'dsn-swiper-paginate container d-flex p-relative w-100 h-100 mt-30 align-items-center' );
		$this->add_render_attribute( 'dsn_swiper_paginate', 'class', $this->shortcode->getVal( 'justify_content', 'justify-content-between' ) );

		if ( $attr !== null && is_array( $attr ) ) {
			$this->add_render_attribute( 'dsn_swiper_paginate', $attr );
		}


		return sprintf( '<div %1$s>%2$s</div>', $this->get_render_attribute_string( 'dsn_swiper_paginate' ), $out );

	}


	/**
	 * @param \gridaShortCode $shortcode
	 *
	 * @return array
	 */
	public function getOptionSlider( \gridaShortCode $shortcode ) {


		$this->shortcode = $shortcode;


		$this->setOptionSwiperResponsiveNumberSlider( 'spaceBetween', 0 );


		$this->setOptionSwiperBoolean( 'allowTouchMove', '1' )
		     ->setOptionSwiperResponsiveBoolean( 'centeredSlides', '' );


		$this->setOptionSwiper( 'direction', 'horizontal' )
		     ->setOptionSwiperBoolean( 'autoHeight', '1' )
		     ->setOptionSwiperBoolean( 'slideToClickedSlide', '' )
		     ->setOptionSwiperBoolean( 'grabCursor', '' )
		     ->setOptionSwiperBoolean( 'loop', '' )
		     ->setOptionSwiperBoolean( 'parallax', '' )
		     ->setOptionSwiperResponsiveNumberSlider( 'slidesPerGroup', 1 )
		     ->setOptionSwiperResponsiveNumberSlider( 'slidesPerView', 1 )
		     ->setOptionSwiperResponsiveNumberSlider( 'speed', 1000 )
		     ->setOptionSwiper( 'effect', 'slide' );


		if ( $this->shortcode->getVal( 'autoplay' ) ) {
			$this->autoPlay( 'delay', 2000, false );
			$this->autoPlay( 'disableOnInteraction', '1' );
			$this->autoPlay( 'reverseDirection' );
			$this->autoPlay( 'stopOnLastSlide' );
			$this->autoPlay( 'waitForTransition', '1' );
		}

		return $this->swiper_option;
	}


	public function start_swiper( $has_parallax_image = false ) {


		$this->add_render_attribute( 'dsn-swiper', [
			'class'           => 'grida-swiper-slider dsn-swiper p-relative',
			'data-dsn-option' => json_encode( $this->getOptionSlider( new \gridaShortCode( array( 'widget-base' => $this ) ) ) ),
		] );
		if ( $has_parallax_image ) {
			$this->add_render_attribute( 'dsn-swiper', 'class', 'has-parallax-image' );
		}
		echo '<div ' . $this->get_render_attribute_string( 'dsn-swiper' ) . '><div class="swiper-container "><div class="swiper-wrapper">';
	}

	public function end_swiper( $with_control = true ) {
		echo '</div>';
		if ( $with_control ) {
			echo $this->get_content_paginate_render();
		}
		echo '</div></div>';
	}

	protected function add_render_swiper_item( $element = 'swiper-slid' ) {
		$this->add_render_attribute( $element, 'class', 'swiper-slide' );
	}


	protected function setFilterSwiper() {
		$this->getControl()->addSwitcher( 'filter_bluer' )
		     ->setLabel( esc_html__( "Filter Blur Swiper", "grida" ) )
		     ->setReturn_value( 'filter-swiper-blur' )
		     ->setPrefix_class()
		     ->get();
	}

}