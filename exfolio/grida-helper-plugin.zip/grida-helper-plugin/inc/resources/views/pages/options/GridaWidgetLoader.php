<?php


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Eremia Widget Extension
 * The main class that initiates and runs the plugin.
 *
 */
class GridaWidgetLoader extends \Dsn\Element\GridaRegisterElement {


	/**
	 * Instance
	 *
	 * @access private
	 * @static
	 * @var GridaWidgetLoader The single instance of the class.
	 */
	private static $_instance = null;


	/**
	 * Minimum ELEMENTOR Version
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 */
	const MIN_PHP_VERSION = '5.6';


	/**
	 * Minimum ACF Version
	 */
	const MIN_ACF_VERSION = '5.0';


	/**
	 * Register Block Name
	 */
	const DSN_BLOCK = array(
		'Heading',
		'Button',
		'InfoHeader',
		'Image',
		'Title',
		'JustfiGallery',
		'sliders' => 'MediaSlider',
		'posts'   => array( 'control' => 'Post', 'SliderProject', 'PostGrid', 'PostSwiper', 'Story' ),
		'List',
		'service' => [ 'control' => 'Service', 'Grid', 'Swiper' ],
		'Testimonial',
		'Logo',
		'Social',
		'brand'   => [ 'control' => 'Brand', 'GridBrand', 'SwiperBrand' ],
		'team'    => [ 'control' => 'Team', 'GridTeam', 'SwiperTeam' ],
		'BGMask',
		'Map',
		'Skills',
		'AnimateLine',

//		'MoveSection',
//		'Awards',
//		'Facts',
		'Accordion',
		'Experience',

		'GridMasonry',
		'Feature',
		'MoveImage',


	);


	const DSN_WIDGET = array(
		'Social',
//        'Logo',
		'ScrollTop',
	);


	/**
	 * Instance
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @access public
	 * @static
	 *
	 * @return GridaWidgetLoader An instance of the class.
	 */
	public static function instance() {


		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;

	}


	/**
	 * Initializing the GridaWidgetLoader class.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		require_once __DIR__ . '/widgets/control/GridaControl.php';
		add_action( 'widget_loader', [ $this, 'register_widget' ] );
//		add_filter( 'style_loader_tag', [ $this, 'preload_style' ], 10, 3 );

	}


	function preload_style( $tag, $handle, $src ) {
		// the handles of the enqueued scripts we want to async
		$async_scripts = array( 'eremia-fonts' );

		if ( in_array( $handle, $async_scripts ) ) {
			return sprintf( '<link id="eremia-fonts" rel="preload" href="%1$s" as="style" onload="this.onload=null;this.rel=\'stylesheet\'"><noscript><link href="%1$s" rel="stylesheet"></noscript>', $src );
		}

		return $tag;
	}



	/**
	 *
	 */

	/**
	 * Initialize the Widget
	 * Retrieve the current widget initial configuration.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function register_widget() {


		// Check for required ACF Plugin
		if ( ! class_exists( 'ACF' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_acf_req' ] );

			return;
		}


		if ( did_action( 'elementor/loaded' ) ) {
			// Check for required Elementor version
			if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );

				return;
			}
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MIN_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_min_php_version' ] );

			return;
		}


		/**
		 * registering new Elementor widgets Category
		 */
		add_action( 'elementor/elements/categories_registered', [ $this, 'register_widget_categories' ] );


		/**
		 * registering new Elementor widgets
		 */
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );


		$this->registerWidgetSection();


		$this->registerRenderSection();

		add_action( 'elementor/elements/elements_registered', [ $this, 'register_elements' ] );


		return;


		// Register widgets Theme
		add_action( 'widgets_init', [ $this, 'register_widgets_theme' ] );


		return;


		/**
		 * Register Elements
		 */


//


		/**
		 * save document Settings controls in the end of
		 */
//        add_action('elementor/editor/after_save', [$this, 'save_after_update']);
	}


	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required ACF Plugin version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_acf_req() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		printf( '<div class="notice notice-error is-dismissible"><p>%1$s</p><p>%2$s</p></div>', sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'grida' ),
			'<strong>' . esc_html__( 'Droow Widget Extension', 'grida' ) . '</strong>',
			'<strong>' . esc_html__( 'Advanced Custom Fields', 'grida' ) . '</strong>',
			self::MIN_ACF_VERSION
		),
			esc_html__( "Use the Advanced Custom Fields plugin to take full control of your WordPress edit screens & custom field data, - you can Gutenberg editor blocks , - Widget Extension Elementor .", 'grida' ) );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-test-extension' ),
			'<strong>' . esc_html__( 'Elementor Test Extension', 'grida' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'grida' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}


	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_min_php_version() {

		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		printf( '<div class="notice notice-error is-dismissible"><p>%1$s</p><p>%2$s</p></div>', sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'grida' ),
			'<strong>' . esc_html__( 'Droow Widget Extension', 'grida' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'grida' ) . '</strong>',
			self::MIN_PHP_VERSION
		),
			esc_html__( "these older versions have reached official End Of Life and as such may expose your site to security vulnerabilities and bugs, and may not always work as expected.", 'grida' ) );

	}

	/**
	 * Register Custom Widget Categories
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function register_widget_categories( $elements_manager ) {

		$elements_manager->add_category(
			'grida_cat',
			[
				'title' => esc_html__( 'Grida Widget(Design Grid)', 'grida' ),
				'icon'  => 'fa fa-plug',
			]
		);

	}


	/**
	 * Register Custom Widgets
	 *
	 * @access public
	 *
	 * @return void
	 */
	public function register_widgets() {

		require_once __DIR__ . '/widgets/control/GridaSlider.php';
		require_once __DIR__ . '/widgets/control/GridaLayout.php';

		/**
		 * Control Widget
		 */


		foreach ( self::DSN_BLOCK as $key => $block ):


			if ( $block ) {
				if ( is_array( $block ) ) {
					foreach ( $block as $key2 => $instance ) {
						if ( $key2 === 'control' ) {

							require_once __DIR__ . '/widgets/' . $key . '/' . $instance . 'Control.php';
							continue;
						}

						$this->getInstanceWidget( $key, $instance );
					}
				} else {
					$this->getInstanceWidget( $key, $block );
				}


			}

		endforeach;


	}

	private function getInstanceWidget( $key, $instance ) {
		$instance = 'Grida' . $instance;
		if ( is_string( $key ) ) {
			$key .= '/';
		} else {
			$key = '';
		}


		require_once __DIR__ . '/widgets/' . $key . $instance . '.php';
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new $instance() );
	}


	/**
	 * Register Custom Elements
	 *
	 * @access public
	 *
	 * @return void
	 */

	public function register_elements() {
		require_once 'widgets/control/eremiaColumn.php';
		require_once 'widgets/control/eremiaSection.php';
		\Elementor\Plugin::instance()->elements_manager->register_element_type( new eremiaColumn() );
		\Elementor\Plugin::instance()->elements_manager->register_element_type( new eremiaSection() );
	}


	public function register_widgets_theme() {

		foreach ( self::DSN_WIDGET as $wid ):
			if ( $wid ) {
				$wid = 'Eremia' . $wid;
				require_once __DIR__ . '/widgets/theme/' . $wid . '.php';
				register_widget( $wid );
			}

		endforeach;
	}


	public function save_after_update( $post_id ) {
		$this->set_update_value( array(
			'menu_type',
			'position_image_position_x',
			'position_image_position_y',
			'opacity_overlay',
			'header_type',
		), $post_id );
	}

	private function set_update_value( array $keys, $post_id ) {


		// Get the page settings manager
		$page_settings_manager = \Elementor\Core\Settings\Manager::get_settings_managers( 'page' );

		// Get the settings model for current post
		$page_settings_model = $page_settings_manager->get_model( $post_id );

		if ( count( $keys ) ):
			foreach ( $keys as $key ):
				update_field( $key, $page_settings_model->get_settings( $this->getIdTheme( $key ) ), $post_id );
			endforeach;
		endif;


	}

}

GridaWidgetLoader::instance();


