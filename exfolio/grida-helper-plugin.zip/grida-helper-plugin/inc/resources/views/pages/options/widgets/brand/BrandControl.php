<?php

namespace Dsn\Element;


trait  BrandControl {

	public function __content_controller( \GridaControl $control ) {


		$control->addSwitcher( 'style_service' )
		        ->setLabel( esc_html__( 'With Corner', 'grida' ) )
		        ->setReturn_value( 'dsn-with-Corner' )
		        ->setPrefix_class()
		        ->setSeparatorBefore()
		        ->get();

		$control->addImageSzie()
		        ->setDefault( 'thumbnail' )
		        ->getGroup();


		$control->startRepeater();
		$control->addImage()->get();

		$control->addLink( 'link' )
		        ->setLabel( esc_html__( 'Link', 'grida' ), true )
		        ->setDynamicActive( true )
		        ->setDefault_url()
		        ->setDefault_is_external( true )
		        ->setDefault_is_nofollow( true )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( "Items" )
		        ->setTitle_field( 'link' )
		        ->get();


	}

	public function __style_controller( \GridaControl $control ) {
		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Service', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Service', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-section' )
		        ->get();

		$control->addPaddingGroup( 'item_padding', '.brand-item-inner' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.brand-item' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.brand-item' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.brand-item' )->getGroup();

	}

}