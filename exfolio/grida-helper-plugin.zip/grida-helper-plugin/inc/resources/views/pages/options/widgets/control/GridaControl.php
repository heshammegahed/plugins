<?php

class GridaControl {

	private $element_base = null;
	private $element = null;
	private $isGroup = false;

	private $id = null;
	private $args = [];


	public function __construct( $element_base ) {
		$this->element_base = $element_base;
		$this->element      = $element_base;
	}


	private function getOptionArray( $options, $id, $default = false ) {
		return grida_get_option_array( $options, $id, $default );
	}

	public function setLabel( $label, $placeholder = false, $dynamicActive = true ) {
		$this->args['label'] = $label;
		if ( $placeholder ) {
			$this->setPlaceholder( $label );
		}

		if ( $dynamicActive ) {
			$this->setDynamicActive( true );
		}

		return $this;
	}

	/**
	 * @return null
	 */
	public function get_element_base() {
		return $this->element_base;
	}


	/**
	 * @param bool $label
	 *
	 * @return $this
	 */
	public function setLabelBlock( $label = true ) {
		$this->args['label_block'] = $label;

		return $this;
	}

	public function setPlaceholder( $placeholder ) {
		$this->args['placeholder'] = $placeholder;

		return $this;
	}

	/**
	 * @param $default
	 *
	 * @return $this
	 */
	public function setDefault( $default ) {
		$this->args['default'] = $default;

		return $this;
	}


	public function setDescription( $default ) {
		$this->args['description'] = $default;

		return $this;
	}


	public function setSeparator( $separator ) {
		$this->args['separator'] = $separator;

		return $this;
	}

	public function setSeparatorAfter() {
		return $this->setSeparator( "after" );
	}

	public function setSeparatorBefore() {
		return $this->setSeparator( "before" );
	}

	/**
	 * @param string $default
	 *
	 * @return $this
	 */
	public function setDefault_url( $default = '' ) {
		$this->args['default']['url'] = $default;

		return $this;
	}

	/**
	 * @param bool $default
	 *
	 * @return $this
	 */
	public function setDefault_is_external( $default = false ) {
		$this->args['default']['is_external'] = $default;

		return $this;
	}

	/**
	 * @param false $default
	 *
	 * @return $this
	 */
	public function setDefault_is_nofollow( $default = false ) {
		$this->args['default']['nofollow'] = $default;

		return $this;
	}


	public function setDynamicActive( $default ) {
		if ( ! isset( $this->args['dynamic']['active'] ) ) {
			$this->args['dynamic']['active'] = $default;
		}

		return $this;
	}


	public function setLabel_on( $label_on ) {
		$this->args['label_on'] = $label_on;

		return $this;
	}

	public function setLabel_off( $label_off ) {
		$this->args['label_off'] = $label_off;

		return $this;
	}


	public function setReturn_value( $return_value ) {
		$this->args['return_value'] = (string) $return_value;

		return $this;
	}

	public function setTitle_field( $return_value ) {
		$this->args['title_field'] = "{{{ $return_value }}}";

		return $this;
	}

	public function setRows( $rows ) {
		$this->args['rows'] = $rows;

		return $this;
	}


	/**
	 * @param array $condition
	 *
	 * @return $this
	 */
	public function setCondition( array $condition ) {
		$this->args['condition'] = $condition;

		return $this;
	}

	/**
	 * @param string $relation
	 *
	 * @return $this
	 */
	public function setRelation( $relation = "or" ) {
		$this->args['conditions'] ['relation'] = $relation;

		return $this;
	}


	/**
	 * @param $min
	 * @param $max
	 *
	 * @return $this
	 */
	public function setRangePx( $min, $max ) {
		$this->args['range'] ['px'] = [
			'min' => $min,
			'max' => $max,
		];

		return $this;
	}

	/**
	 * @param $default
	 *
	 * @return $this
	 */
	public function setDefaultDesktop( $default ) {
		$this->args['desktop_default'] = $default;

		return $this;
	}

	/**
	 * @param $size
	 * @param string $unit
	 *
	 * @return $this
	 */
	public function setDefaultRange( $size, $unit = 'px' ) {
		$this->args['default'] = [
			'size' => $size,
			'unit' => $unit,
		];

		return $this;
	}


	public function setDefaultDesktopRange( $size, $unit = 'px' ) {
		$this->setDefaultDesktop( [
			'size' => $size,
			'unit' => $unit,
		] );

		return $this;
	}

	/**
	 * @param $default
	 *
	 * @return $this
	 */
	public function setDefaultTablet( $default ) {
		$this->args['tablet_default'] = $default;


		return $this;
	}

	/**
	 * @param $size
	 * @param string $unit
	 *
	 * @return $this
	 */
	public function setDefaultTabletRange( $size, $unit = 'px' ) {
		$this->setDefaultTablet( [
			'size' => $size,
			'unit' => $unit,
		] );

		return $this;
	}

	/**
	 * @param $default
	 *
	 * @return $this
	 */
	public function setDefaultMobile( $default ) {
		$this->args['mobile_default'] = $default;

		return $this;
	}

	/**
	 * @param $size
	 * @param string $unit
	 *
	 * @return $this
	 */
	public function setDefaultMobileRange( $size, $unit = 'px' ) {
		$this->setDefaultMobile( [
			'size' => $size,
			'unit' => $unit,
		] );

		return $this;
	}

	/**
	 * @param $key
	 * @param $value
	 *
	 * @return $this
	 */
	public function setSelectors( $key, $value ) {
		$this->args['selectors'] [ '{{WRAPPER}} ' . $key ] = $value;

		return $this;

	}

	/**
	 * @param bool $value
	 *
	 * @return $this
	 */
	public function setMultiple( $value = true ) {
		$this->args['multiple'] = $value;

		return $this;
	}

	/**
	 * @param $key
	 * @param $value
	 *
	 * @return $this
	 */
	public function setSelectorRepeater( $key, $value ) {
		$this->args['selectors'] [ '{{WRAPPER}} {{CURRENT_ITEM}} ' . $key ] = $value;

		return $this;

	}

	/**
	 * @param $key
	 *
	 * @return $this;
	 */
	public function setSelectorGrid( $key ) {
		$this->setSelectors( $key, 'grid-template-columns: repeat({{SIZE}},1fr);' );

		return $this;
	}


	public function setPrefix_class( $prefix_class = '' ) {

		$this->args['prefix_class'] = $prefix_class;

		return $this;
	}


	/**
	 * @param $key
	 * @param null $opration
	 * @param null $value
	 * @param string $relation
	 *
	 * One of and/or. If omitted, defaults to and.
	 * terms    An array of arrays containing the rules.
	 * name    The parent control’s name.
	 *
	 * Access responsive variations by suffixing with _tablet or _mobile.
	 * Important! Access values in complex Unit/Multiple controls with:
	 * scale_mobile[size] or link[url]
	 * (for Slider or URL, respectively.)
	 *
	 * operator    Defaults to strict equality (===), when omitted. Otherwise, use one of:
	 *
	 * ==
	 * !=
	 * !==
	 * in
	 * !in
	 * contains
	 * !contains
	 * <
	 * <=
	 * >
	 * >=
	 * ===
	 *
	 * value
	 *
	 * Some option’s value from the parent control.
	 * It needs to be an array when using in and !in operators.
	 *
	 * @return $this
	 */
	public function setConditions( $key, $opration = null, $value = null, $relation = 'or' ) {

		if ( is_array( $key ) ) {
			$this->args['conditions'] ['relation'] = $relation;
			$this->args['conditions'] ['terms']    = $key;

			return $this;
		}


		if ( $value === null ) {
			$value    = $opration;
			$opration = '===';
		}


		$this->args['conditions'] ['relation'] = $relation;
		$this->args['conditions'] ['terms'][]  = [
			'name'     => $key,
			'operator' => $opration,
			'value'    => $value,
		];

		return $this;
	}


	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addText( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::TEXT;
		$this->args   = $args;

		return $this;
	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addHidden( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::HIDDEN;
		$this->args   = $args;

		return $this;
	}


	public function addHiddenNoSpace( $id, array $args = array() ) {

		$this->addHidden( $id, $args )
		     ->setDefault( 'dsn-mb-no-space' )
		     ->setPrefix_class();

		return $this;
	}


	public function addPopover( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::POPOVER_TOGGLE;
		$this->args   = $args;

		return $this;
	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addImage( $id = 'image', array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::MEDIA;
		$this->args   = array_merge( [
			'label'   => __( 'Choose Image', 'elementor' ),
			'dynamic' => [
				'active' => true,
			],
			'default' => [
				'url' => \Elementor\Utils::get_placeholder_image_src(),
			],
		], $args );

		return $this;
	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addGallery( $id = 'gallery', array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::GALLERY;
		$this->args   = array_merge( [
			'label'   => __( 'Galleries', 'grida' ),
			'dynamic' => [
				'active' => true,
			],
		], $args );

		return $this;
	}

	/**
	 * @param string $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function getGroupImage( $id = 'image', array $args = array() ) {
		$this->addImage( $id, $this->getOptionArray( $args, 'image', array() ) )
		     ->get()
		     ->addImageSzie( $id, $this->getOptionArray( $args, 'size', array() ) )
		     ->getGroup()
		     ->getCaption();

		return $this;
	}


	public function getGroupGallery( $id = 'gallery', array $args = array() ) {
		$this->addGallery( $id, $this->getOptionArray( $args, 'gallery', array() ) )
		     ->get()
		     ->addImageSzie( $id, $this->getOptionArray( $args, 'size', array() ) )
		     ->getGroup()
		     ->getCaption();

		return $this;
	}

	public function getCaption( $id = 'caption_source', $id_custom_caption = 'caption', array $args = array() ) {


		$this->addSelect( $id, [
			'none'       => __( 'None', 'elementor' ),
			'attachment' => __( 'Attachment Caption', 'elementor' ),
			'custom'     => __( 'Custom Caption', 'elementor' ),
		],
			[
				'label'   => __( 'Caption', 'elementor' ),
				'default' => 'none',
			] )
		     ->get()
		     ->addText( $id_custom_caption, [
			     'label'       => __( 'Custom Caption', 'elementor' ),
			     'default'     => __( 'Enter your image caption', 'elementor' ),
			     'placeholder' => __( 'Enter your image caption', 'elementor' ),
			     'condition'   => [
				     'caption_source' => 'custom',
			     ],
			     'dynamic'     => [
				     'active' => true,
			     ],
		     ] )->get();


		return $this;
	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addDivider( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::DIVIDER;
		$this->args   = $args;

		return $this;
	}


	/**
	 * @param $id
	 * @param array $options
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addSelect( $id, array $options = array(), array $args = array() ) {

		$this->id        = $id;
		$args['type']    = \Elementor\Controls_Manager::SELECT;
		$args['options'] = $options;
		$this->args      = $args;

		return $this;
	}


	/**
	 * @param $id
	 * @param array $options
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addSelect2( $id, array $options = array(), array $args = array() ) {

		$this->id        = $id;
		$args['type']    = \Elementor\Controls_Manager::SELECT2;
		$args['options'] = $options;
		$this->args      = $args;

		return $this;
	}


	public function addSlider( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::SLIDER;
		$this->args   = $args;

		return $this;
	}

	/**
	 * @return array
	 */
	public function getDefaultWidthHeight( $vwh = 'vw' ) {
		return [
			'default'        => [
				'unit' => '%',
			],
			'tablet_default' => [
				'unit' => '%',
			],
			'mobile_default' => [
				'unit' => '%',
			],
			'size_units'     => [ '%', 'px', $vwh ],
			'range'          => [
				'%'  => [
					'min' => 1,
					'max' => 100,
				],
				'px' => [
					'min' => 1,
					'max' => 1000,
				],
				$vwh => [
					'min' => 1,
					'max' => 100,
				],
			],
		];
	}


	/**
	 * @return array
	 */
	public function getStyleButton() {
		return array(
			'dsn-def-btn'                  => esc_html__( 'Default', 'grida' ),
			'dsn-def-btn dsn-border-style' => esc_html__( 'Button With Border', 'grida' ),
			'grida-btn'                    => esc_html__( 'grida Button', 'grida' ),
		);
	}

	/**
	 * @return array
	 */
	public function getBorderColor() {
		return array(
			'border-color-default'     => esc_html__( 'Default', 'grida' ),
			'border-color-theme-color' => esc_html__( 'Theme Color', 'grida' ),
			'border-color-main'        => esc_html__( 'Main Color', 'grida' ),
			'border-color-assistant'   => esc_html__( 'Assistant Color', 'grida' ),
		);
	}

	/**
	 * @param $id
	 * @param $key
	 * @param int $descktop
	 * @param int $table
	 * @param int $mobile
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addGrid( $id = 'col_grid', $key = '.d-grid.dsn-effect-grid', $descktop = 3, $table = 2, $mobile = 1, $args = array() ) {
		$this->setRangePx( 1, 6 );
		$this->addSlider( $id, $args );
		$this->setDefaultDesktopRange( $descktop );
		$this->setDefaultTabletRange( $table );
		$this->setDefaultMobileRange( $mobile );
		$this->setSelectorGrid( $key );
		$this->setLabel( esc_html__( 'Columns', 'grida' ) );

		return $this;
	}


	/**
	 * @param string $id
	 * @param string $key
	 * @param int $descktop
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addGridGapColumns( $id = 'dsn_col_gap', $key = '.d-grid.dsn-effect-grid', $descktop = 30, $args = array() ) {

		$this->addSlider( $id, [
			'label'           => esc_html__( 'Columns Gap', 'grida' ),
			'desktop_default' => [
				'size' => $descktop,
				'unit' => 'px',
			],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'selectors'       => [
				'{{WRAPPER}} ' . $key => 'grid-column-gap: {{SIZE}}px;',
			],
		] );

		return $this;
	}

	/**
	 * @param string $id
	 * @param string $key
	 * @param int $descktop
	 * @param int $tablet
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addGridGapRow( $id = 'dsn_row_gap', $key = '.d-grid.dsn-effect-grid', $descktop = 50, $tablet = 30, $args = array() ) {

		$this->addSlider( $id, [
			'label'           => esc_html__( 'Rows Gap', 'grida' ),
			'desktop_default' => [
				'size' => $descktop,
				'unit' => 'px',
			],
			'tablet_default'  => [
				'size' => $tablet,
				'unit' => 'px',
			],
			'range'           => [
				'px' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'selectors'       => [
				'{{WRAPPER}} ' . $key => 'grid-row-gap: {{SIZE}}px;',
			],
		] );

		return $this;

	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addTextarea( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::TEXTAREA;
		$this->args   = $args;

		return $this;
	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addTextareaEditor( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::WYSIWYG;
		$this->args   = $args;

		return $this;
	}


	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addLink( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::URL;
		$this->args   = $args;

		return $this;
	}


	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addSwitcher( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::SWITCHER;
		$this->args   = $args;
		$this->setReturn_value( "1" );

		return $this;
	}

	public function addNumber( $id, $min, $max, $step, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::NUMBER;
		$this->args   = array_merge( $args, [ 'min' => $min, 'max' => $max, 'step' => $step ] );

		return $this;
	}

	public function addNumberSlider( $id, $min, $max, $step, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::SLIDER;
		$this->args   = array_merge( $args, [
				'range' => [
					'px' => [ 'min' => $min, 'max' => $max, 'step' => $step ],
				],
			]
		);


		return $this;
	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addChose( $id, array $args = array() ) {

		$this->id       = $id;
		$args['type']   = \Elementor\Controls_Manager::CHOOSE;
		$args['toggle'] = false;
		$this->args     = $args;

		return $this;
	}

	public function setOptionChoose( $key, $title, $icon ) {
		$this->args['options'][ $key ] = [ 'title' => $title, 'icon' => $icon ];

		return $this;
	}


	public function addSize( $id = 'font_size', $options = array(), array $args = array() ) {

		return $this->addSelect( $id, array_merge( [
			''               => esc_html__( 'Default', 'grida' ),
			'title'          => esc_html__( 'Title Section Large', 'grida' ),
			'title-h2'       => esc_html__( 'Title Section Default', 'grida' ),
			'title-block'    => esc_html__( 'Title Block', 'grida' ),
			'sm-title-block' => esc_html__( 'Title Block Small ', 'grida' ),
			'sub-heading'    => esc_html__( 'Paragraph Large ', 'grida' ),
			'sm-p'           => esc_html__( 'Paragraph Small ', 'grida' ),
			'font-number'    => esc_html__( 'Number', 'grida' ),

		], $options ), $args )
		            ->setDefault( '' )
		            ->setLabel( __( 'Size', 'grida' ) );
	}


	/**
	 * @param $id
	 * @param $key
	 * @param string $value
	 *
	 * @return GridaControl|null
	 */
	public function addSpacing( $id, $key, string $value = 'bottom' ) {


		return $this->addSlider( $id, [
			'label' => esc_html__( 'Spacing', 'grida' ),
			'range' => [
				'px' => [ 'max' => 100, ],
			],
		] )->setSelectors( $key, 'margin-' . $value . ':{{SIZE}}{{UNIT}}' );

	}


	/**
	 * @param string $id
	 * @param array $options
	 * @param array $args
	 *
	 * @return gridaControl
	 * @return gridaControl
	 */
	public function addLineText( $id = 'dsn_line_text', $options = array(), array $args = array() ) {

		return $this->addSelect( $id, array_merge( [
			''                             => esc_html__( 'Default', 'grida' ),
			'line-under-left'              => esc_html__( 'Line Under Left', 'grida' ),
			'line-under'                   => esc_html__( 'Line Under Right', 'grida' ),
			'line-bg-left'                 => esc_html__( 'Line BG Left', 'grida' ),
			'line-bg-right'                => esc_html__( 'Line BG Right', 'grida' ),
			'line-shape'                   => esc_html__( 'Line Shape (After & Before)', 'grida' ),
			'line-shape line-shape-after'  => esc_html__( 'Line Shape (After)', 'grida' ),
			'line-shape line-shape-before' => esc_html__( 'Line Shape (Before)', 'grida' ),
			'border-section-bottom'        => esc_html__( 'Border Bottom', 'grida' ),
			'border-before'                => esc_html__( 'Border Left', 'grida' ),
			'p-10 background-main'         => esc_html__( 'Background Main', 'grida' ),
			'p-10 background-section'      => esc_html__( 'Background Section', 'grida' ),
			'p-10 background-theme'        => esc_html__( 'Background Theme', 'grida' ),
		], $options ), $args )
		            ->setDefault( '' )
		            ->setLabel( __( 'Line Text', 'grida' ) );
	}

	public function addHtmlTag( $id = 'dsn_html_tag', $options = array(), array $args = array() ) {

		return $this->addSelect( $id, array_merge( [
			'h1'   => 'H1',
			'h2'   => 'H2',
			'h3'   => 'H3',
			'h4'   => 'H4',
			'h5'   => 'H5',
			'h6'   => 'H6',
			'div'  => 'div',
			'span' => 'span',
			'p'    => 'p',

		], $options ), $args )->setDefault( 'h2' )->setLabel( __( 'HTML Tag', 'grida' ) );
	}


	public function startRepeater() {
		$this->element_base = new \Elementor\Repeater();

		return $this;
	}

	public function endRepeater( $id, array $args = array() ) {
		$repeater           = $this->element_base;
		$this->element_base = $this->element;
		$this->id           = $id;
		$args['type']       = \Elementor\Controls_Manager::REPEATER;
		$args['fields']     = $repeater->get_controls();
		$this->args         = $args;


		return $this;
	}


	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addColor( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::COLOR;
		$this->args   = $args;

		return $this;
	}


	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addIcons( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::ICONS;
		$this->args   = $args;

		return $this;
	}

	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addIcon( $id, array $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::ICON;
		$this->args   = $args;

		return $this;
	}

	public function addHeadingColor( $id, $selector, array $args = array() ) {
		$this->addSelect( $id, [
			''              => __( 'Default', 'grida' ),
			'body-color'    => __( 'Body Color', 'grida' ),
			'heading-color' => __( 'Heading Color', 'grida' ),
			'theme-color'   => __( 'Theme Color', 'grida' ),
			'custom'        => __( 'Custom Color', 'grida' ),
		], array_merge( [ 'default' => '', 'label' => __( 'Color', 'grida' ) ], $args ) )->get();

		$this->id     = $id . '_group';
		$args['type'] = \Elementor\Controls_Manager::COLOR;
		$this->args   = $args;
		$this->setConditions( $id, '===', 'custom' );
		if ( is_array( $selector ) ) {
			foreach ( $selector as $sele ):
				$this->setSelectors( $sele, 'color: {{VALUE}};' );
			endforeach;
		} else {
			$this->setSelectors( $selector, 'color: {{VALUE}};' );
		}

		return $this;
	}


	/**
	 * @param $id
	 * @param string $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addTypography( $id, $selector = '.dsn-heading-title', array $args = array() ) {

		$this->id     = \Elementor\Group_Control_Typography::get_type();
		$args['name'] = $id;
		$this->args   = array_merge( [ 'selector' => '{{WRAPPER}} ' . $selector ], $args );

		$this->isGroup = true;


		return $this;
	}

	/**
	 * @param $id
	 * @param string $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addPaddingGroup( $id = 'item_padding', $selector = '.dsn-heading-title', array $args = array() ) {


		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::DIMENSIONS;
		$this->args   = array_merge( $args, [
				'label'      => __( 'Padding', 'elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ' . $selector => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		return $this;
	}

	/**
	 * @param $id
	 * @param string $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addBorderRadiusGroup( $id = 'item_border_radius', $selector = '.dsn-heading-title', array $args = array() ) {


		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::DIMENSIONS;
		$this->args   = array_merge( $args, [
				'label'      => __( 'Border Radius', 'grida' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ' . $selector => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		return $this;
	}


	/**
	 * @param $id
	 * @param string $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addMarginGroup( $id = 'item_margin', $selector = '.dsn-heading-title', array $args = array() ) {


		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::DIMENSIONS;
		$this->args   = array_merge( $args, [
				'label'      => __( 'Margin', 'elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ' . $selector => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		return $this;
	}


	/**
	 * @param $id
	 * @param string $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addTextShadow( $id, $selector = '.dsn-heading-title', array $args = array() ) {

		$this->id     = \Elementor\Group_Control_Text_Shadow::get_type();
		$args['name'] = $id;
		$this->args   = array_merge( [ 'selector' => '{{WRAPPER}} ' . $selector ], $args );

		$this->isGroup = true;


		return $this;
	}


	/**
	 * @param $id
	 * @param string $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addBoxShadow( $id = 'item_box_shadow', $selector = '.dsn-heading-title', array $args = array() ) {

		$this->id     = \Elementor\Group_Control_Box_Shadow::get_type();
		$args['name'] = $id;
		$this->args   = array_merge( [ 'selector' => '{{WRAPPER}} ' . $selector ], $args );

		$this->isGroup = true;


		return $this;
	}

	/**
	 * @param $id
	 * @param string $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addBorder( $id = 'item_border_style', $selector = '.dsn-heading-title', array $args = array() ) {

		$this->id     = \Elementor\Group_Control_Border::get_type();
		$args['name'] = $id;
		$this->args   = array_merge( [ 'selector' => '{{WRAPPER}} ' . $selector ], $args );

		$this->isGroup = true;


		return $this;
	}


	public function addImageSzie( $id = 'image', array $args = array() ) {

		$this->id     = \Elementor\Group_Control_Image_Size::get_type();
		$args['name'] = $id;
		$this->args   = array_merge( [ 'default' => 'large' ], $args );

		$this->isGroup = true;


		return $this;
	}

	/**
	 * @param string $id
	 * @param $selector
	 * @param array $args
	 *
	 * @return $this
	 */
	public function addFilterImage( $id = 'css_filters', $selector = 'img', array $args = array() ) {

		$this->id     = \Elementor\Group_Control_Css_Filter::get_type();
		$args['name'] = $id;
		$this->args   = $args;

		$this->isGroup = true;


		return $this;
	}


	/**
	 * @param $id
	 * @param string $selector
	 * @param array $options
	 * @param array $args
	 *
	 * @return $this|gridaControl
	 */
	public function addBlendMode( $id, $selector = '.dsn-heading-title', $options = array(), array $args = array() ) {


		$this->addSelect( $id, array_merge( [
			''            => esc_html__( 'Normal', 'grida' ),
			'multiply'    => 'Multiply',
			'screen'      => 'Screen',
			'overlay'     => 'Overlay',
			'darken'      => 'Darken',
			'lighten'     => 'Lighten',
			'color-dodge' => 'Color Dodge',
			'saturation'  => 'Saturation',
			'color'       => 'Color',
			'difference'  => 'Difference',
			'exclusion'   => 'Exclusion',
			'hue'         => 'Hue',
			'luminosity'  => 'Luminosity',

		], $options ), $args );

		if ( $selector ) {
			$this->setSelectors( $selector, 'mix-blend-mode: {{VALUE}}' );
		}

		$this->setDefault( '' )
		     ->setLabel( esc_html__( 'Blend Mode', 'grida' ) );


		return $this;
	}


	/**
	 * @param $id
	 * @param float $default
	 * @param array $args
	 * @param false $is_numberslid
	 *
	 * @return $this
	 */
	public function getTrigerHock( $id, $default = "bottom", array $args = array() ) {

		$args = array_merge( [
			'label'       => __( 'Start', 'grida' ),
			'description' => __( "The ScrollTrigger's starting scroll position (numeric, in pixels). This value gets calculated when the ScrollTrigger is refreshed, so anytime the window/scroller gets resized it'll be recalculated", 'grida' ),
			'default'     => $default,
		], $args );


		return $this->addSelect( $id, [
			'bottom' => esc_html__( "start Section Bottom Window", 'grida' ),
			'center' => esc_html__( "center Window", 'grida' ),
			'top'    => esc_html__( "start Section Top Window", 'grida' ),
		], $args )
		            ->setLabelBlock()
		            ->setDefault( $default );


	}


	/**
	 * @param string $id
	 *
	 * @return $this
	 */
	public function getAlign( $id = 'align' ) {

		$this->addChose( $id, array(
			'label'        => __( 'Alignment', 'elementor' ),
			'options'      => [
				'left'    => [
					'title' => __( 'Left', 'elementor' ),
					'icon'  => 'eicon-text-align-left',
				],
				'center'  => [
					'title' => __( 'Center', 'elementor' ),
					'icon'  => 'eicon-text-align-center',
				],
				'right'   => [
					'title' => __( 'Right', 'elementor' ),
					'icon'  => 'eicon-text-align-right',
				],
				'justify' => [
					'title' => __( 'Justified', 'elementor' ),
					'icon'  => 'eicon-text-align-justify',
				],
			],
			'prefix_class' => 'elementor%s-align-',
			'default'      => '',
		) );

		return $this;
	}

	/**
	 * @param string $id
	 *
	 * @return $this
	 */
	public function getJustifyContent( $id = 'justify_content' ) {


		$this->addChose( $id, array(
			'label'   => __( 'Justify Content', 'elementor' ),
			'options' => [
				'justify-content-start'  => [
					'title' => __( 'Left', 'elementor' ),
					'icon'  => 'eicon-h-align-left',
				],
				'justify-content-center' => [
					'title' => __( 'Center', 'elementor' ),
					'icon'  => 'eicon-h-align-center',
				],

				'justify-content-end'     => [
					'title' => __( 'Right', 'elementor' ),
					'icon'  => 'eicon-h-align-right',
				],
				'justify-content-between' => [
					'title' => __( 'Between', 'grida' ),
					'icon'  => 'eicon-code-bold',
				],
			],

			'default' => 'justify-content-center',
		) );


		return $this;
	}


	/**
	 * @param string $id
	 *
	 * @return $this
	 */
	public function getAlignmentItem( $id = 'alignment_item' ) {


		$this->addChose( $id, array(
			'label'   => __( 'Alignment Item', 'elementor' ),
			'options' => [
				'align-items-start'  => [
					'title' => __( 'Top', 'daro' ),
					'icon'  => 'eicon-v-align-top',
				],
				'align-items-center' => [
					'title' => __( 'Center', 'daro' ),
					'icon'  => 'eicon-v-align-middle',
				],
				'align-items-end'    => [
					'title' => __( 'Bottom', 'daro' ),
					'icon'  => 'eicon-v-align-bottom',
				],
			],
			'default' => 'align-items-center',
		) );


		return $this;
	}


	/**
	 * @param false $isResponsive
	 *
	 * @return $this
	 */
	public function get( $isResponsive = false ) {

		if ( $this->isGroup ) {
			$this->element_base->add_group_control( $this->id, $this->args );
		} elseif ( ! $isResponsive ) {
			$this->element_base->add_control( $this->id, $this->args );
		} else {
			$this->element_base->add_responsive_control( $this->id, $this->args );
		}

		$this->isGroup = false;
		$this->args = [];


		return $this;
	}


	/**
	 * @return $this
	 */
	public function get_popover() {
		$this->get();
		$this->element_base->start_popover();

		return $this;
	}


	/**
	 * @return $this
	 */
	public function end_popover() {
		$this->element_base->end_popover();

		return $this;
	}


	/**
	 * @param $id
	 * @param array $args
	 *
	 * @return $this
	 */
	public function start_popover( $id, $args = array() ) {

		$this->id     = $id;
		$args['type'] = \Elementor\Controls_Manager::POPOVER_TOGGLE;
		$this->args   = $args;

		return $this;
	}


	/**
	 * @return $this
	 */
	public function getResponsive() {
		$this->element_base->add_responsive_control( $this->id, $this->args );
		$this->args = [];
		return $this;
	}

	public function getGroup() {
		$this->element_base->add_group_control( $this->id, $this->args );
		$this->isGroup = false;
		$this->args = [];
		return $this;
	}


	/**
	 * @return array
	 */
	public function getOptionVerBackground(): array {
		return [
			''             => __( 'Default', 'grida' ),
			'v-light'      => __( 'Light', 'grida' ),
			'v-light-head' => __( 'Light (Static)', 'grida' ),
			'v-dark'       => __( 'Dark', 'grida' ),
			'v-dark-head'  => __( 'Dark  (Static)', 'grida' ),
		];
	}

	/**
	 * @return array
	 */
	public function getOptionBackground(): array {
		return [
			'background-transparent'     => __( 'Default', 'grida' ),
			'background-main'            => __( 'Background Main', 'grida' ),
			'background-section'         => __( 'Background Section', 'grida' ),
			'background-theme'           => __( 'Background Theme', 'grida' ),
			'background-gradient-left'   => __( 'Background Gradient Left', 'grida' ),
			'background-gradient-bottom' => __( 'Background Gradient Bottom', 'grida' ),
			'background-gradient-right'  => __( 'Background Gradient Right', 'grida' ),
			'background-gradient-top'    => __( 'Background Gradient Top', 'grida' ),
		];
	}

	/**
	 * @param string $post_type
	 *
	 * @return array
	 */
	public function getPostsArray( $post_type = 'any' ): array {
		$post_type = get_posts( array(
			'posts_per_page' => - 1,
			'post_type'      => $post_type,
		) );
		$items     = array();
		if ( count( $post_type ) ) {
			foreach ( $post_type as $po ):
				$items[ $po->ID ] = $po->post_title;
			endforeach;
		}

		return $items;
	}


	public function getArgas() {
		return $this->args;
	}


}