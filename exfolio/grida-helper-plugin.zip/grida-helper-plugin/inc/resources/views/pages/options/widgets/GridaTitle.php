<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class GridaTitle extends \Elementor\Widget_Base {

	use \Dsn\Element\Grida_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_title';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Grida Title Section', 'grida' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-post-title';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'title', 'header' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Title', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();
		$control->addTextarea( 'title' )
		        ->setLabel( esc_html__( 'Title', 'grida' ) )
		        ->setPlaceholder( esc_html__( 'Enter your title', 'grida' ) )
		        ->setDefault( esc_html__( 'Add Your Title', 'grida' ) )
		        ->setDynamicActive( true )
		        ->get();

		$control->addTextarea( 'description' )
		        ->setLabel( esc_html__( 'Description', 'grida' ) )
		        ->setSeparator( "before" )
		        ->setPlaceholder( esc_html__( 'Enter your description', 'grida' ) )
		        ->setDefault( esc_html__( 'Add Your Description', 'grida' ) )
		        ->setDynamicActive( true )
		        ->get();

		$control->addChose( 'direction' )
		        ->setLabel( esc_html__( 'Direction', 'grida' ) )
		        ->setConditions( 'description', '!=', '' )
		        ->setOptionChoose( '1', __( 'After Title', 'elementor' ), 'eicon-v-align-top' )
		        ->setOptionChoose( '', __( 'Before Title', 'elementor' ), 'eicon-v-align-bottom' )
		        ->setDefault( '1' )
		        ->get();


		$control->addHtmlTag()
		        ->setSeparator( 'before' )
		        ->get();

		$control->addSize()
		        ->setDefault( 'title-h2' )
		        ->get();

		$this->end_controls_section();

		$this->styleTab();

	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style Content', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->getAlign()
		        ->setDefault( "center" )
		        ->getResponsive();

		$control->getJustifyContent( 'justify_content_slider' )->get();


		$control->addSelect( 'dsn_section_width_layout', [
			''                                  => __( 'Default', 'grida' ),
			'dsn-container'                     => __( 'Wide Page', 'grida' ),
			'container'                         => __( 'Container Page', 'grida' ),
			'dsn-container dsn-right-container' => __( 'Right Container Page', 'grida' ),
			'dsn-container dsn-left-container'  => __( 'Left Container Page', 'grida' ),
		], [
			'label'        => __( 'Width Layout', 'grida' ),
			'default'      => '',
			'prefix_class' => '',
		] )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSlider( 'spaces_description' )
		        ->setLabel( __( 'Spacing Between', 'elementor' ) )
		        ->setRangePx( 0, 120 )
		        ->setSelectors( '.description.mb-10', 'margin-bottom: {{SIZE}}{{UNIT}};' )
		        ->setSelectors( '.description.mt-10', 'margin-top: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSwitcher( 'space_section' )
		        ->setLabel( esc_html__( "Use Space Default", 'grida' ) )
		        ->setDefault( 'mb-70' )
		        ->setReturn_value( 'mb-70' )
		        ->get();

		$control->addHiddenNoSpace( 'hidden-space' )
		        ->setConditions( 'space_section', 'mb-70' )
		        ->get();

		$this->end_controls_section();


		$this->start_controls_section(
			'style_title_section',
			[
				'label' => esc_html__( 'Style Title', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addHeadingColor( 'title_color', '.dsn-heading-title' )
		        ->setLabel( __( 'Custom Color', 'grida' ) )
		        ->get();
		$control->addTypography( 'title_typography' )->getGroup();

		$control->addLineText( 'dsn_line_title' )
		        ->get();

		$control->addLineText( 'dsn_line_title_into' )
		        ->setLabel( __( 'Line Text Into', 'grida' ) )
		        ->get();

		$control->addSlider( 'space', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Max Width', 'elementor' ) )
		        ->setSelectors( '.dsn-heading-title', 'max-width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addTextShadow( 'title_Text_shadow' )->getGroup();
		$control->addBlendMode( 'title_blend_mode' )->get();

		$control->addSwitcher( 'use_as_troke' )
		        ->setReturn_value( 'letter-stroke' )
		        ->setLabel( __( 'Use As Stroke', 'grida' ) )
		        ->get();

		$control->addSelect( 'dsn_title_animate', [
			''         => __( 'None', 'grida' ),
			'dsn-up'   => __( 'Fade', 'grida' ),
			'dsn-text' => __( 'Text', 'grida' ),
		] )
		        ->setLabel( __( 'Animate Text', 'grida' ) )
		        ->setDefault( '' )
		        ->setSeparator( "before" )
		        ->get();


		$this->end_controls_section();


		$this->start_controls_section(
			'style_description_section',
			[
				'label' => esc_html__( 'Style Description', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addHeadingColor( 'description_color', '.description' )
		        ->setLabel( __( 'Custom Color', 'grida' ) )
		        ->get();
		$control->addTypography( 'description_typography', '.description' )->getGroup();

		$control->addLineText( 'dsn_line_description' )
		        ->setDefault( 'line-shape line-shape-before' )
		        ->get();

		$control->addLineText( 'dsn_line_description_into' )
		        ->setDefault( 'line-bg-right' )
		        ->setLabel( __( 'Line Text Into', 'grida' ) )
		        ->get();

		$control->addSlider( 'space_description', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Max Width', 'elementor' ) )
		        ->setSelectors( '.description', 'max-width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addSelect( 'dsn_description_animate', [
			''         => __( 'None', 'grida' ),
			'dsn-up'   => __( 'Fade', 'grida' ),
			'dsn-text' => __( 'Text', 'grida' ),
		] )
		        ->setLabel( __( 'Animate Text', 'grida' ) )
		        ->setDefault( '' )
		        ->setSeparator( "before" )
		        ->get();


		$this->end_controls_section();


	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$this->add_inline_editing_attributes( 'title' );
		$this->add_inline_editing_attributes( 'description' );
		echo grida_shortcode_render_group( 'title', array( 'widget-base' => $this ) );

	}


}
