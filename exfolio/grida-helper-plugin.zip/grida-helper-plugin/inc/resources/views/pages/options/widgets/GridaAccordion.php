<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class GridaAccordion extends \Elementor\Widget_Base {

	use \Dsn\Element\Grida_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_accordion';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Grida Accordion', 'grida' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-accordion';

	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'accordion', 'tabs', 'toggle' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Accordion', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();

		$control->addSwitcher( 'list_with_number' )
		        ->setLabel( esc_html__( "List With Number", 'grida' ) )
		        ->setDescription( esc_html__( "if Us this feature can't us icon with list" ) )
		        ->get();

		$control->startRepeater();

		$control->get_element_base()->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'elementor' ),
				'type'  => \Elementor\Controls_Manager::ICONS,
			]
		);

		$control->addText( 'title' )
		        ->setDefault( 'Web Design' )
		        ->setLabel( esc_html__( "Title", 'grida' ) )
		        ->setDynamicActive( true )
		        ->get();

		$control->addTextareaEditor( 'description' )
		        ->setLabel( esc_html__( "Description", 'grida' ) )
		        ->setDefault( '<p>Cepteur sint occaecat cupidatat proident, taken possession of my entire soul, like these sweet mornings of spring which I enjoy with my whole.</p>' )
		        ->setTitle_field( 'title' )
		        ->setDynamicActive( true )
		        ->get();

		$control->endRepeater( 'items' )
		        ->setLabel( esc_html__( 'Accordion Items', 'grida' ) )
		        ->get();

		$control->addHtmlTag()
		        ->setSeparator( "before" )
		        ->get();

		$control->addSize()
		        ->setDefault( 'sm-title-block' )
		        ->get();


		$this->end_controls_section();

		$this->styleTab();

	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->end_controls_section();


	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$items_key = $this->getKeys( 'items', [ 'title', 'description' => 'advanced' ] );
		echo grida_shortcode_render_group( 'accordion', array( 'widget-base' => $this ), $items_key );

	}


}
