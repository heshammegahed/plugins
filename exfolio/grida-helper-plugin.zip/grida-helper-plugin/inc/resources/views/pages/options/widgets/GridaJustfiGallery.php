<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class GridaJustfiGallery extends \Elementor\Widget_Base {

	use \Dsn\Element\Grida_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_gallery';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Gallery Justified', 'grida' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-gallery-justified';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'image', 'photo', 'gallery', 'justified', 'slider' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();

		$control->getGroupGallery();


		$this->add_control(
			'popup_image',
			[
				'label'     => __( 'Popup Image', 'grida' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$control->addImageSzie( 'size_img_popup' )
		        ->setDefault( 'full' )
		        ->getGroup();


		$this->end_controls_section();

		$this->styleSettings();

	}


	private function styleSettings() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Additional Options', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			]
		);

		$control->addNumberSlider( 'rowHeight', 0, 1000, 10 )
		        ->setLabel( __( 'Row Height', 'grida' ) )
		        ->setDescription( __( 'The preferred rows height in pixel.', 'grida' ) )
		        ->setDefaultRange( 300 )
		        ->get();

		$control->addNumberSlider( 'margins', 0, 1000, 10 )
		        ->setLabel( __( 'Margins', 'grida' ) )
		        ->setDescription( __( 'Decide the margins between the images.', 'grida' ) )
		        ->setDefaultRange( 15 )
		        ->get();

		$control->addSelect( 'lastRow', [
			'nojustify' => __( 'No justify', 'grida' ),
			'justify'   => __( 'Justify', 'grida' ),
			'left'      => __( 'Left', 'grida' ),
			'center'    => __( 'Center', 'grida' ),
			'right'     => __( 'Right', 'grida' ),
			'hide'      => __( 'Hide', 'grida' ),
		] )
		        ->setLabel( __( 'Last row', 'grida' ) )
		        ->setDefault( 'nojustify' )
		        ->get();


		$this->end_controls_section();


	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		echo grida_shortcode_render_group( 'justified-gallery', array( 'widget-base' => $this ) );

	}


}
