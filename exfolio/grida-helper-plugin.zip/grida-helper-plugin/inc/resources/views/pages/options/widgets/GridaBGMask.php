<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class GridaBGMask extends \Elementor\Widget_Base {

	use \Dsn\Element\Grida_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_bg_mask';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Background Mask', 'grida' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-background';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'mask', 'background' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Background Mask', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();


		$control->addHidden( 'bg_mask_hidden' )
		        ->setDefault( 'dsn-equal-height h-100' )
		        ->setPrefix_class()
		        ->get();


		$control->addSelect( 'background_mask', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Mask', 'grida' ) )
		        ->setDefault( 'background-section' )
		        ->get();


		$default_width = [
			'size_units' => [ '%', 'px', 'vw' ],
			'range'      => [
				'%'  => [
					'min' => - 100,
					'max' => 100,
				],
				'px' => [
					'min' => - 1000,
					'max' => 1000,
				],
				'vw' => [
					'min' => - 100,
					'max' => 100,
				],
			],
		];

		$default_height = [
			'size_units' => [ '%', 'px', 'vh' ],
			'range'      => [
				'%'  => [
					'min' => - 100,
					'max' => 100,
				],
				'px' => [
					'min' => - 1000,
					'max' => 1000,
				],
				'vh' => [
					'min' => - 100,
					'max' => 100,
				],
			],
		];

		$control->addSlider( 'width_mask', $default_width )
		        ->setDefaultRange( 100, '%' )
		        ->setLabel( esc_html__( 'Width Mask', 'grida' ) )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSlider( 'calc_width_mask', $default_width )
		        ->setDefaultRange( 0 )
		        ->setLabel( esc_html__( 'Plus Width Mask', 'grida' ) )
		        ->get();

		$control->addSlider( 'height_mask', $default_height )
		        ->setDefaultRange( 100, '%' )
		        ->setLabel( esc_html__( 'Height Mask', 'grida' ) )
		        ->setSeparator( "before" )
		        ->get();


		$control->addSlider( 'calc_height_mask', $default_height )
		        ->setDefaultRange( 0 )
		        ->setLabel( esc_html__( 'Plus Height Mask', 'grida' ) )
		        ->get();


		$control->addSlider( 'top_mask', $default_height )
		        ->setDefaultRange( 0 )
		        ->setLabel( esc_html__( 'Top', 'grida' ) )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSlider( 'left_mask', $default_width )
		        ->setDefaultRange( 0 )
		        ->setLabel( esc_html__( 'Left', 'grida' ) )
		        ->get();

		$control->addSlider( 'margin_top_mask', $default_height )
		        ->setDefaultRange( 0 )
		        ->setLabel( esc_html__( 'Margin Top', 'grida' ) )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSlider( 'margin_left_mask', $default_width )
		        ->setDefaultRange( 0 )
		        ->setLabel( esc_html__( 'Margin Left', 'grida' ) )
		        ->get();


		$this->end_controls_section();

		$this->styleTab();

	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'opacity',
			[
				'label'     => __( 'Opacity', 'elementor' ),
				'type'      => \Elementor\Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dsn-bg-mask ' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => __( 'Border Radius', 'elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}} .dsn-bg-mask  ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);


		$this->end_controls_section();


	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		echo grida_shortcode_render_group( 'bg-mask', array( 'widget-base' => $this ) );

	}

	protected function content_template() {
		echo grida_shortcode_js_group( 'bg-mask', array( 'widget-base' => $this ) );
	}


}
