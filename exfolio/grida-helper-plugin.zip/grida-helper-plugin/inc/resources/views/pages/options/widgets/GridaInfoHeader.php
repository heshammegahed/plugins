<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class GridaInfoHeader extends \Elementor\Widget_Base {

	use \Dsn\Element\Grida_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_info_header';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Information Header', 'grida' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-info-circle-o';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'information', 'header' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();

		$control->startRepeater();

		$control->addText( 'title' )
		        ->setLabel( esc_html__( 'Title', 'grida' ), true )
		        ->get();


		$control->addTextarea( 'content' )
		        ->setLabel( esc_html__( 'Content', 'grida' ), true )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( esc_html__( 'Items', 'grida' ) )
		        ->setTitle_field( 'title' )
		        ->setDefault( grida_default_info_header() )
		        ->get();


		$this->end_controls_section();

		$this->styleTitle();

	}


	private function styleTitle() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_title_section',
			[
				'label' => esc_html__( 'Style Title', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addColor( 'color_content_title' )
		        ->setLabel( esc_html__( "Color", 'grida' ) )
		        ->setSelectors( 'h5', 'color:{{VALUE}};' )
		        ->get();
		$control->addTypography( 'title_typography', 'h5' )->getGroup();
		$control->addTextShadow( 'text_content_shadow_title', 'h5' )
		        ->getGroup();


		$this->end_controls_section();


		$this->start_controls_section(
			'style_content_section',
			[
				'label' => esc_html__( 'Style Content', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addColor( 'color_content_span' )
		        ->setLabel( esc_html__( "Color", 'grida' ) )
		        ->setSelectors( 'span', 'color:{{VALUE}};' )
		        ->get();
		$control->addTypography( 'span_typography', 'span' )->getGroup();
		$control->addTextShadow( 'text_content_shadow_span', 'span' )
		        ->getGroup();
		$this->end_controls_section();

	}


	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {


		$items_key = $this->getKeys( 'items', [ 'title', 'content' => 'none' ] );
		echo grida_shortcode_render_group( 'info_header', array( 'widget-base' => $this ), $items_key );

	}


}
