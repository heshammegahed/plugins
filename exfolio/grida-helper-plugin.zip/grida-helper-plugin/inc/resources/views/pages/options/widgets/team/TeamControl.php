<?php

namespace Dsn\Element;


trait  TeamControl {

	public function __content_controller( \GridaControl $control ) {
		$control->addImageSzie()->getGroup();
		$control->startRepeater();
		$control->addImage()->get();


		$control->addText( 'name' )
		        ->setLabel( esc_html__( 'name', 'grida' ), true )
		        ->setDefault( 'Design Grid' )
		        ->setDynamicActive( true )
		        ->get();


		$control->addText( 'position' )
		        ->setLabel( esc_html__( 'Position', 'grida' ), true )
		        ->setDefault( 'Web Developer' )
		        ->setDynamicActive( true )
		        ->get();

		$control->start_popover( 'social_popup' )
		        ->setLabel( esc_html__( "Social", 'grida' ) )
		        ->get_popover();

		$control->get_element_base()->add_control(
			'social_note',
			[
				'label'           => __( 'Social Note', 'plugin-name' ),
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => __( '<p style="margin-top: 10px;padding-top: 10px; border-top: 1px solid">You can control this icons from <a href="https://fontawesome.com/icons?d=gallery&m=free" target="_blank" >This Page </a> copy Element</p>', 'grida' ),
				'content_classes' => 'dsn-team-social-raw pt-10 mt-10 border-top',
			]
		);

		for ( $x = 1; $x <= 5; $x ++ ):
			$control->addText( 'icon_' . $x )
			        ->setSeparator( "before" )
			        ->setDynamicActive( true )
			        ->setLabel( esc_html__( 'Social Label (' . $x . ')', 'grida' ) )
			        ->get();

			$control->addText( 'link_social_' . $x )
			        ->setLabel( esc_html__( 'link (' . $x . ')', 'grida' ), true )
			        ->setDynamicActive( true )
			        ->get();

		endfor;
		$control->end_popover();


		$control->endRepeater( 'items' )
		        ->setLabel( "Items" )
		        ->setTitle_field( 'name' )
		        ->get();

	}

	public function __style_controller( \GridaControl $control ) {

		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Service', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Service', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-transparent' )
		        ->get();


	}

	public function __style_content_controller( \GridaControl $control ) {
		$args = array(
			'text-name'     => esc_html__( 'Name', 'grida' ),
			'text-position' => esc_html__( 'Position', 'grida' )
		);

		foreach ( $args as $id => $value ):

			$this->start_controls_section(
				'style_content_service_' . $id,
				[
					'label' => $value,
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);


			$control->addColor( 'color_content_' . $id )
			        ->setLabel( esc_html__( "Color", 'grida' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content_' . $id, '.' . $id )
			        ->getGroup();

			$control->addTextShadow( 'text_content_shadow_' . $id, '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;
	}

}