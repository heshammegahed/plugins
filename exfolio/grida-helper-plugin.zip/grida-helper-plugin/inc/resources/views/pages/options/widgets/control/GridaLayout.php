<?php

namespace Dsn\Element;


class GridaLayout extends \Elementor\Widget_Base {

	use \Dsn\Element\Grida_Widget_Base;

	private $swiper_option = array();


	/**
	 * @var null|\gridaShortCode
	 */
	private $shortcode = null;

	protected $style_item = '.dsn-grid-layout';
	protected $style_layout = '.dsn-grid-layout';

	protected $range_col = 30;
	protected $range_row = 50;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_layouts';
	}


	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'grid' ] );
	}

	/**
	 * @return array
	 */
	protected function getLayoutStyle() {
		return array(
			'dsn-grid'                                        => esc_html__( "Grid", 'grida' ),
			'dsn-isotope'                                     => esc_html__( "Masonry", 'grida' ),
			'dsn-masonry-grid dsn-isotope'                    => esc_html__( "Masonry Grid", 'grida' ),
			'dsn-masonry-grid dsn-masonry-grid-2 dsn-isotope' => esc_html__( "Masonry Grid 2", 'grida' ),
		);
	}

	public function add_parallax_attributes( $element, $id, \gridaShortCode $shortcode ) {
		$this->shortcode = $shortcode;
		if ( ! $this->shortcode->getVal( 'parallax' ) ) {
			return $this;
		}

		$parallax = $this->shortcode->getVal( 'parallax_' . $id, array( 'unit' => '%', 'size' => 0 ) );
		$size     = $this->shortcode->getOptionArray( $parallax, 'size' );
		if ( $size ):
			$unit = $this->shortcode->getOptionArray( $parallax, 'unit', '%' );
			if ( $unit !== '%' ) {
				$unit = '';
			}

			$this->add_render_attribute( $element, 'data-swiper-parallax', $size . $unit );
		endif;
		$scale = $this->shortcode->getValueNumberSlide( 'scale_' . $id, 1 );

		if ( $scale !== 1 && $scale !== '' ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-scale', $scale );
		}

		$opacity = $this->shortcode->getValueNumberSlide( 'opacity_' . $id, 1 );
		if ( $opacity < 1 && $opacity !== '' ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-opacity', $opacity );
		}

		if ( $duration_ = $this->shortcode->getValueNumberSlide( 'duration_' . $id ) ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-duration', $duration_ );
		}


		$this->add_render_attribute( $element, 'class', 'dsn-swiper-parallax-transform' );

		return $this;
	}


	protected function addPrefixClass( $elment, \gridaShortCode $shortcode ) {
//
//		$style = sprintf( '--dsn-width-item:%1$s;--dsn-col-item:%2$spx;--dsn-row-item:%3$spx;',
//			$shortcode->getValueNumberSlide( 'number_grid', 1 ),
//			$shortcode->getValueNumberSlide( 'col_layout_gap', 30 ),
//			$shortcode->getValueNumberSlide( 'row_layout_gap', 50 )
//		);
		$this->add_render_attribute( $elment, [
			'class'        => [
				'dsn-grid-layout',
				$shortcode->getVal( 'layout_style', 'dsn-grid' ),
//				$shortcode->getVal( 'layout_style_metro', 'metro-1' ),
				$shortcode->getVal( 'full_width_last_item', '' ),
			],
//			'style'        => $style,
			'data-dsn-iso' => $this->get_id(),
//			'data-isotope' => '{ "itemSelector": ".grid-item"}'

		] );


	}

	protected function addAnimateFade( $elment, \gridaShortCode $shortcode ) {
		if ( $shortcode->getVal( 'use_animate_fade' ) ) {
			$this->add_render_attribute( $elment, 'class', 'dsn-up' );
		}
	}


	protected function getLayout() {

		$control = $this->getControl();

		$control->addSelect( 'layout_style', $this->getLayoutStyle() )
		        ->setLabel( esc_html__( "Layout Style", 'grida' ) )
		        ->setDefault( "dsn-grid" )
		        ->setSeparator( "before" )
		        ->get();

//		$control->addSelect( 'layout_style_metro', [
//			'metro-1' => esc_html__( 'Style 1', 'grida' ),
//			'metro-2' => esc_html__( 'Style 2', 'grida' ),
//			'metro-3' => esc_html__( 'Style 3', 'grida' ),
//		] )
//		        ->setLabel( esc_html__( "Layout Metro Style", 'grida' ) )
//		        ->setDefault( "metro-1" )
//		        ->setConditions( 'layout_style', 'dsn-masonry-metro dsn-isotope' )
//		        ->get();

		$control->addNumberSlider( 'number_grid', 1, 9, 1 )
		        ->setLabel( esc_html__( "Columns", 'grida' ) )
		        ->setDefaultRange( 1 )
		        ->setSelectors( $this->style_layout, '--dsn-width-item: {{SIZE}};' )
		        ->getResponsive();

		$control->addSwitcher( 'full_width_last_item' )
		        ->setLabel( esc_html__( "full width last item", 'grida' ) )
		        ->setReturn_value( "full-width-last-item" )
		        ->setConditions( 'layout_style', '!=', 'dsn-isotope' )
		        ->get();

		$control->addSwitcher( 'use_animate_fade' )
		        ->setLabel( esc_html__( "use Animate Fade", 'grida' ) )
		        ->setReturn_value( "1" )
		        ->get();

//
//		$control->addHidden( 'col-hidden-style' )
//		        ->setLabel( esc_html__( "hidden", 'grida' ) )
//		        ->setDefault( "over-hidden" )
//		        ->setPrefix_class()
//		        ->get();

	}

	protected function getGridSpace() {
		$control = $this->getControl();
		$control->addNumberSlider( 'col_layout_gap', 0, 100, 1 )
		        ->setLabel( esc_html__( "Columns Gap", 'grida' ) )
		        ->setSelectors( $this->style_layout, '--dsn-col-item: {{SIZE}}px;' )
		        ->setDefaultRange( $this->range_col )
		        ->getResponsive();

		$control->addNumberSlider( 'row_layout_gap', 0, 100, 1 )
		        ->setLabel( esc_html__( "Row Gap", 'grida' ) )
		        ->setSelectors( $this->style_layout, '--dsn-row-item: {{SIZE}}px;' )
		        ->setDefaultRange( $this->range_row )
		        ->getResponsive();


	}

}