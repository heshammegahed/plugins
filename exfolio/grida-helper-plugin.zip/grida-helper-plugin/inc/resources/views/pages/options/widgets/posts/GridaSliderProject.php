<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class GridaSliderProject extends \Dsn\Element\GridaSlider {


	protected $parallax = null;

	protected const DISTORTION_SLIDER = 'dsn-webgl';
	protected string $effect_slider = 'effect_slider';
	protected array $condition_parallax = [
		'effect_slider' => ''
	];

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_slider_project';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Grida Slider Portfolio', 'grida' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-post-slider';

	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'slider', 'portfolio', 'work' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls_content() {


		$this->parallax = array(
			'parallax_image' => esc_html__( "Image", 'grida' ),
		);


		$control = $this->getControl();
		$control->addSelect( 'effect_slider', [
			''          => esc_html__( 'Swiper Slider', 'grida' ),
			'dsn-webgl' => esc_html__( 'Distortion Slider', 'grida' )
		] )
		        ->setDefault( '' )
		        ->setLabel( esc_html__( 'Effect Slider', 'grida' ) )
		        ->get();


		$control->addSelect( 'layout_style', [
			'v-dark-head'                    => esc_html__( 'Full', 'grida' ),
			'v-dark-head-mobile half-slider' => esc_html__( 'Half', 'grida' )

		] )
		        ->setDefault( 'v-dark-head' )
		        ->setPrefix_class()
		        ->setLabel( esc_html__( 'Layout', 'grida' ) )
		        ->get();


		$control->addSwitcher( 'dsn_views' )
		        ->setLabel( esc_html__( "Custom Slider", 'grida' ) )
		        ->get();


		$control->addNumberSlider( 'blog_pages_show_at_most', - 1, 100, 1 )
		        ->setDefaultRange( get_option( 'posts_per_page' ) )
		        ->setLabel( esc_html__( 'blog_pages_show_at_most', 'grida' ) )
		        ->setConditions( 'dsn_views', '' )
		        ->get();

		$control->addText( 'text_link' )
		        ->setLabel( esc_html__( "Text Link ", 'grida' ), true )
		        ->setDefault( esc_html__( "VIEW CASE", 'grida' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'dsn_views', '' )
		        ->get();

		$this->getSliderCustom();


	}


	private function getSliderCustom() {
		$control = $this->getControl();
		$control->startRepeater();
		$control->addImage()->get();
		$control->addImageSzie()->get();
		$this->getOverlay( null );

		$control->addText( 'post_title' )
		        ->setLabel( esc_html__( "title", 'grida' ), true )
		        ->setDynamicActive( true )
		        ->setLabelBlock()
		        ->setSeparator( "before" )
		        ->setDefault( esc_html__( "Enter Your Title", 'grida' ) )
		        ->get();

		$control->addText( 'subtitle' )
		        ->setLabel( esc_html__( "Subtitle", 'grida' ), true )
		        ->setDynamicActive( true )
		        ->setLabelBlock()
		        ->get();


		$control->addTextarea( 'description_header' )
		        ->setLabel( esc_html__( "Description", 'grida' ), true )
		        ->setDynamicActive( true )
		        ->setDefault( "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias maiores molestias nisi officiis perferendis possimus qui voluptates. Accusantium beatae consequuntur dolorem nam quod reiciendis, tempore!" )
		        ->setLabelBlock()
		        ->get();


		$control->addLink( 'link1' )
		        ->setLabel( esc_html__( 'URL 1', 'cobe' ) )
		        ->setPlaceholder( esc_html__( "www.your-site.com", 'grida' ) )
		        ->setDynamicActive( true )
		        ->setSeparator( "before" )
		        ->get();

		$control->addText( "text_link1" )
		        ->setLabel( esc_html__( "Text Link 1", 'grida' ), true )
		        ->setDefault( esc_html__( "VIEW CASE", 'grida' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'link1[url]', '!=', '' )
		        ->get();

		$control->addLink( 'link2' )
		        ->setLabel( esc_html__( 'URL 2', 'cobe' ) )
		        ->setPlaceholder( esc_html__( "www.your-site.com", 'grida' ) )
		        ->setDynamicActive( true )
		        ->setSeparator( "before" )
		        ->get();

		$control->addText( "text_link2" )
		        ->setLabel( esc_html__( "Text Link 2", 'grida' ), true )
		        ->setDefault( esc_html__( "VIEW CASE", 'grida' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'link2[url]', '!=', '' )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( esc_html__( "Items", 'grida' ) )
		        ->setConditions( 'dsn_views', '1' )
		        ->setSeparator( "before" )
		        ->setTitle_field( 'post_title' )
		        ->get();


		$control->addNumberSlider( 'spaceBetween', 0, 100, 10 )
		        ->setLabel( esc_html__( 'Space Between', 'grida' ) )
		        ->setDescription( esc_html__( 'Distance between slides in px.', 'grida' ) )
		        ->setDefaultDesktopRange( 0 )
		        ->setDefaultTabletRange( 0 )
		        ->setDefaultMobileRange( 0 )
		        ->setSeparator( "before" )
		        ->setConditions( $this->effect_slider, '' )
		        ->getResponsive();


	}


	private function styleWebGel() {
		$control = $this->getControl();
		$style   = [];
		for ( $x = 1; $x <= 16; $x ++ ):
			$style[ $x . '.jpg' ] = "Style " . $x;
		endfor;

		$this->start_controls_section(
			'setting_webgel_swiper_section',
			[
				'label' => esc_html__( 'Slides Option', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS
			]
		);

		$control->addSelect( 'direction_webgl', [
			'horizontal' => esc_html__( 'horizontal', 'grida' ),
			'vertical'   => esc_html__( 'Vertical', 'grida' ),
		] )
		        ->setDefault( 'horizontal' )
		        ->setLabel( esc_html__( 'Direction', 'grida' ) )
				->setConditions( $this->effect_slider, '!=', '' )
		        ->setDescription( esc_html__( "Can be 'horizontal' or 'vertical' (for vertical slider).", 'grida' ) )
		        ->get();


		$control->addSelect( 'transition_slider', $style )
		        ->setLabel( esc_html__( "Transition Slider", 'grida' ) )
		        ->setDefault( '8.jpg' )
		        ->setConditions( $this->effect_slider, '!=', '' )
		        ->get();

		$control->addNumberSlider( 'intensity', - 5, 5, 1 )
		        ->setLabel( esc_html__( "Intensity", 'grida' ) )
		        ->setDefaultRange( - 2 )
		        ->setConditions( $this->effect_slider, '!=', '' )
		        ->get();

		$control->addNumberSlider( 'speed_in', 0, 5, 1 )
		        ->setLabel( esc_html__( "Speed In", 'grida' ) )
		        ->setDefaultRange( 1.2 )
		        ->setConditions( $this->effect_slider, '!=', '' )
		        ->get();

		$control->addNumberSlider( 'speed_out', 0, 5, 1 )
		        ->setLabel( esc_html__( "Speed Out", 'grida' ) )
		        ->setDefaultRange( 1.2 )
		        ->setConditions( $this->effect_slider, '!=', '' )
		        ->get();

		$this->end_controls_section();


	}

	protected function _register_controls_content_after() {
		$control = $this->getControl();


		$this->end_controls_section();


		$this->styleWebGel();


		$this->start_controls_section(
			'content_display_content_area',
			[
				'label' => esc_html__( 'Display Content Area', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addSelect2( 'show_title_area', [
			'link_with_title'  => esc_html__( 'Link With Title', 'grida' ),
			'show_sub_title'   => esc_html__( 'SubTitle', 'grida' ),
			'show_category'    => esc_html__( 'Category', 'grida' ),
			'show_description' => esc_html__( 'Description', 'grida' ),
			'show_Button1'     => esc_html__( 'Button 1', 'grida' ),
			'show_Button2'     => esc_html__( 'Button 2', 'grida' )
		] )
		        ->setMultiple()
		        ->setLabelBlock()
		        ->setDefault( array( 'link_with_title', 'show_category' ) )
		        ->setLabel( esc_html__( 'Display Content Area', 'grida' ) )
		        ->get();


		$control->addNumberSlider( 'excerpt_length', 15, 300, 5 )
		        ->setLabel( esc_html__( 'Excerpt length', 'grida' ) )
		        ->setDefaultRange( 25 )
		        ->setSeparator( "before" )
		        ->setCondition( [ 'show_title_area' => 'show_description' ] )
		        ->get();

		$this->start_controls_tabs( 'tab_button' );

		foreach ( [ 'tab_btn-1', 'tab_btn-2' ] as $index => $btn ):

			$key = $index + 1;
			$this->start_controls_tab( $btn . '_' . $key, [
				'label'     => esc_html__( "Button" ) . ' ' . $key,
				'condition' => [ 'show_title_area' => 'show_Button' . $key ],
			] );


			$control->addSelect( 'bg_ver_button-' . $key, $control->getOptionVerBackground() )
			        ->setLabel( esc_html__( 'BG Button', 'grida' ) . ' ' . $key )
			        ->setCondition( [ 'show_title_area' => 'show_Button' . $key ] )
			        ->get();

			$control->addSelect( 'bg_button-' . $key, $control->getOptionBackground() )
			        ->setLabel( esc_html__( 'BG Button', 'grida' ) . ' ' . $key )
			        ->setDefault( 'background-main' )
			        ->setCondition( [ 'show_title_area' => 'show_Button' . $key ] )
			        ->get();


			$this->end_controls_tab();

		endforeach;


		$this->end_controls_tabs();


		$control->addSelect( 'style_button_bg', $control->getStyleButton() )
		        ->setLabel( esc_html__( 'Background button 1', 'grida' ) )
		        ->setDefault( 'btn-2' )
		        ->setSeparator( "before" )
		        ->setCondition( [ 'show_title_area' => 'show_Button' ] )
		        ->get();


		$this->end_controls_section();
		$this->start_controls_section(
			'content_query',
			[
				'label' => esc_html__( 'Query', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addNumber( 'offset', 0, null, 1 )
		        ->setDefault( 0 )
		        ->setLabel( esc_html__( 'Offset', 'grida' ), true )
		        ->setDescription( esc_html__( 'offset Display posts from the 4th one', 'grida' ) )
		        ->get();

		$control->addSelect( 'orderby', [
			'none'       => esc_html__( 'No order', 'grida' ),
			'ID'         => esc_html__( 'post id', 'grida' ),
			'author'     => esc_html__( 'author', 'grida' ),
			'menu_order' => esc_html__( 'Menu Order', 'grida' ),
			'title'      => esc_html__( 'title', 'grida' ),
			'name'       => esc_html__( 'name', 'grida' ),
			'date'       => esc_html__( 'date', 'grida' ),
			'modified'   => esc_html__( 'last modified date', 'grida' ),
			'rand'       => esc_html__( 'Random order', 'grida' ),
		] )
		        ->setLabel( esc_html__( 'Order By', 'grida' ) )
		        ->setDescription( esc_html__( 'Sort retrieved posts.', 'grida' ) )
		        ->setDefault( "date" )
		        ->get();

		$control->addSelect( 'order', [
			'DESC' => esc_html__( 'descending', 'grida' ),
			'ASC'  => esc_html__( 'ascending', 'grida' )
		] )
		        ->setLabel( esc_html__( 'Order', 'grida' ) )
		        ->setDescription( esc_html__( 'Designates the ascending or descending order of the ‘orderby‘ parameter', 'grida' ) )
		        ->setDefault( "DESC" )
		        ->get();


	}


	protected function getStyleOption() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_swiper_slides',
			[
				'label' => esc_html__( 'slides', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->getAlign()
		        ->setDefault( "left" )
		        ->getResponsive();
		$control->getJustifyContent( 'justify_content_slider' )
		        ->setDefault( 'justify-content-start' )
		        ->get();
		$control->getAlignmentItem( 'alignment_item' )->get();

		$control->addColor( 'bg_color_item' )
		        ->setLabel( esc_html__( "background Color", 'grida' ) )
		        ->setSeparator( "before" )
		        ->setSelectors( $this->style_item, 'background-color:{{VALUE}};' )
		        ->get();

		$control->addSelect( 'bg_ver_item', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Slide', 'grida' ) )
		        ->setLabelBlock()
		        ->setConditions( 'bg_color_item', '' )
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_item', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Slide', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-transparent' )
		        ->setConditions( 'bg_color_item', '' )
		        ->setSeparator( "after" )
		        ->get();


		$this->add_responsive_control(
			'item_padding',
			[
				'label'      => __( 'Padding', 'elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ' . $this->style_item => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => $this->condition_parallax,

				'separator'  => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'      => 'border',
				'selector'  => '{{WRAPPER}} ' . $this->style_item,
				'separator' => 'before',
				'condition' => $this->condition_parallax
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label'      => __( 'Border Radius', 'elementor' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'selectors'  => [
					'{{WRAPPER}} ' . $this->style_item => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition' => $this->condition_parallax
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'button_box_shadow',
				'selector' => '{{WRAPPER}} ' . $this->style_item,
				'condition' => $this->condition_parallax
			]
		);


		$this->end_controls_section();
		$this->getStyleContent();
	}


	private function getStyleContent() {
		$control = $this->getControl();


		$args = array(
			'title'         => esc_html__( 'Title', 'grida' ),
			'description'   => esc_html__( 'Description', 'grida' ),
			'sub-meta'      => esc_html__( 'Metas', 'grida' ),
			'sub-meta-head' => esc_html__( 'SubTitle', 'grida' ),
		);

		foreach ( $args as $id => $value ):

			$this->start_controls_section(
				'style_content_slides-' . $id,
				[
					'label' => $value,
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);


			$control->addColor( 'color_content-' . $id )
			        ->setLabel( esc_html__( "Color", 'grida' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content-' . $id, '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;


	}

	protected function _content_pagination_Navigation() {
		$control = $this->getControl();

		$this->start_controls_section(
			'paginate_swiper_section',
			[
				'label' => esc_html__( 'Pagination & Navigation', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addSwitcher( 'show_navigation' )
		        ->setLabel( esc_html__( "Navigation (Arrow)", 'grida' ) )
		        ->get();


		$control->addChose( 'dir_nav_slider_arrow' )
		        ->setLabel( esc_html__( "Direction", 'coba' ) )
		        ->setConditions( 'show_navigation', '1' )
		        ->setOptionChoose( '', __( 'Bottom', 'elementor' ), 'eicon-h-align-left' )
		        ->setOptionChoose( 'controller-right', __( 'Right', 'elementor' ), 'eicon-h-align-right' )
		        ->get();

		$control->addSwitcher( 'show_pagination' )
		        ->setLabel( esc_html__( 'Show Progressbar', 'grida' ) )
		        ->get();


		$control->getJustifyContent( 'justify_content' )
		        ->setDefault( 'justify-content-between' )
		        ->get();


		$this->end_controls_section();

	}


	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$items_key = $this->getKeys( 'items', [
			'post_title' => 'none',
			'subtitle'   => 'none',
			'text_link1' => 'none',
			'text_link2' => 'none',
			'description_header',
		] );

		$this->add_inline_editing_attributes( 'prev_text', 'none' );
		$this->add_inline_editing_attributes( 'next_text', 'none' );

		echo grida_shortcode_render_group( 'slider-project', array( 'widget-base' => $this ), $items_key );

	}


}
