<?php

namespace Dsn\Element;


trait  Grida_Widget_Base {


	private $coba_control = null;

	/**
	 * @return null
	 */
	public function getControl() {
		if ( $this->coba_control === null ) {
			$this->coba_control = new \GridaControl( $this );
		}

		return $this->coba_control;
	}

	/**
	 * @param null $coba_control
	 */
	public function setControl( $coba_control ): void {
		$this->coba_control = $coba_control;
	}


	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function dsn_keywords() {
		return [ 'dsn', 'grida' ];
	}


	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @return array Widget categories.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_categories() {
		return [ 'grida_cat' ];
	}


	/**
	 * @param $options
	 * @param $id
	 * @param false|Array $default
	 *
	 * @return false|mixed
	 */
	private function getValueArray( $options, $id, $default = false ) {
		return grida_get_option_array( $options, $id, $default );
	}


	/**
	 * @param $id
	 * @param array $name_element
	 *  `advanced`, `basic` or `none`
	 *
	 * @return array
	 */
	protected function getKeys( $id, array $name_element ) {
		$settings = $this->get_settings_for_display();
		$items    = $this->getValueArray( $settings, $id, array() );
		$keys     = array();

		if ( ! count( $items ) ) {
			return $keys;
		}

		foreach ( $items as $index => $item ) :
			$array_tab = array();
			foreach ( $name_element as $key => $value ) {
				if ( is_numeric( $key ) ) {
					$toolbar     = 'basic';
					$setting_key = $value;
				} else {
					$toolbar     = $value;
					$setting_key = $key;
				}

				$tab_key = $this->get_repeater_setting_key( $setting_key, $id, $index );
				$this->add_inline_editing_attributes( $tab_key, $toolbar );
				$array_tab[ $setting_key ] = $tab_key;
			}

			$keys[ $index ] = $array_tab;
		endforeach;

		return $keys;
	}


}