<?php

namespace Dsn\Element;


trait GridaRenderSectionElement {


	public function registerRenderSection() {
		/**
		 * Render For Element
		 */
		add_action( 'elementor/frontend/section/before_render', [ $this, 'render_before_section' ], 100, 2 );
		add_action( 'elementor/frontend/column/before_render', [ $this, 'render_before_section' ] );
	}


	public function render_before_section( \Elementor\Element_Base $element ) {

		$settings = $element->get_settings();


		$is_section = $element->get_name() === 'section';
		$is_column  = $element->get_name() === 'column';


		if ( $is_column ) {
			$this->getColumn( $element );
		}

		if ( $is_section ) {
			$this->getSection( $element );
			$this->addPaginate( $element );
		}


		if ( $this->getOptionArray( $settings, 'dsn_change_color' ) ) {
			$element->add_render_attribute( '_wrapper', 'data-dsn', 'color' );
			$element->add_render_attribute( '_wrapper', 'data-dsn-triggerhook', $this->getOptionArray( $settings, 'triggerhook_change_color', 'top' ) );
		}


	}


	private function addPaginate( \Elementor\Element_Base $element ) {
		$settings             = $element->get_settings();
		$use_section_paginate = $this->getOptionArray( $settings, 'use_section_paginate' );
		$text_paginate        = $this->getOptionArray( $settings, 'text_paginate' );

		if ( $use_section_paginate && $text_paginate ) {
			$element->add_render_attribute( '_wrapper', 'data-dsn-title', $text_paginate );
		}

	}


	private function getOptionArray( $options, $id, $default = false ) {
		return grida_get_option_array( $options, $id, $default );
	}


	private function getColumn( \Elementor\Element_Base $element ) {
		$settings = $element->get_settings();


		if ( $this->getOptionArray( $settings, 'data_animation_section' ) ) {

			$element->add_render_attribute( '_wrapper', 'data-dsn-animate', 'section' );
//			$element->add_render_attribute( '_wrapper', 'data-dsn-triggerhook-section', $this->getOptionArray( $settings, 'triggerhook_section' ) );
		}

	}

	private function getSection( \Elementor\Element_Base $element ) {
		$element->add_render_attribute( 'parallax', 'class', 'h-100' );
		if ( $img = grida_shortcode_render_group( 'image', array( 'widget-base' => $element ) ) ) {
			printf( '<div class="dsn-bg-section p-absolute w-100 h-100 over-hidden hidden top-0 right-0 left-0 bottom-0" data-dsn="bg_section">%s</div>', $img );
		}


	}
}