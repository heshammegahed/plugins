<?php

namespace Dsn\Element;


trait  PostControl {

	public function __content_controller( \GridaControl $control ) {
		$control->addSelect( 'style_post', [
			'classic' => esc_html__( "classic", 'grida' ),
			'cards'   => esc_html__( "Cards", 'grida' ),
			'list'    => esc_html__( "List", 'grida' ),

		] )
		        ->setLabel( esc_html__( "Skin", 'grida' ) )
		        ->setDefault( "classic" )
		        ->setPrefix_class( 'dsn-style-' )
		        ->get();

		$control->addSelect( 'style_cards_post', [
			''                  => esc_html__( "Normal", 'grida' ),
			'box-image-hover'   => esc_html__( "Box Image Hover", 'grida' ),
			'box-content-hover' => esc_html__( "Box Content Hover", 'grida' ),
		] )
		        ->setLabel( esc_html__( "Style Cards", 'grida' ) )
		        ->setDefault( '' )
		        ->setPrefix_class()
		        ->setConditions( 'style_post', 'cards' )
		        ->get();

		$control->addSelect( 'style_list_post', [
			''                => esc_html__( "Image Left", 'grida' ),
			'dsn-image-right' => esc_html__( "Image Right", 'grida' ),
			'dsn-image-odd'   => esc_html__( "Image Reverse", 'grida' ),

		] )
		        ->setLabel( esc_html__( "Style List", 'grida' ) )
		        ->setDefault( '' )
		        ->setConditions( 'style_post', 'list' )
		        ->setPrefix_class()
		        ->get();

		$control->addSelect( 'query_post', [
			'post'               => esc_html__( 'post', 'grida' ),
			grida_project_slug() => esc_html__( 'grida Portfolio', 'grida' ),
		] )
		        ->setLabel( esc_html__( "Query", 'grida' ) )
		        ->setDefault( "post" )
		        ->get();

		$control->addNumber( 'post_per_page', - 1, null, 1 )
		        ->setLabel( esc_html__( 'Post Per Page', 'grida' ) )
		        ->setDescription( esc_html__( 'number of posts to show per page , (-1 or 0) (show all posts) is used.', 'grida' ) )
		        ->setDefault( 6 )
		        ->get();

		$control->addImageSzie()
		        ->getGroup();

	}

	public function __title_content_controller( \GridaControl $control ) {
		$control->addHtmlTag( 'dsn_html_tag' )->setSeparator( "before" )->get();

		$control->addSize( 'font_size' )->setDefault( 'title-block' )->get();

		$control->addSwitcher( 'title_with_box' )
		        ->setLabel( esc_html__( 'Title With Box', 'grida' ) )
		        ->get();


	}

	public function __excerpt_content_controller( \GridaControl $control ) {

		$control->addSwitcher( 'show_excerpt' )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( "Excerpt", 'grida' ) )
		        ->get();

		$control->addNumberSlider( 'excerpt_length', 15, 300, 5 )
		        ->setLabel( esc_html__( 'Excerpt length', 'grida' ) )
		        ->setDefaultRange( 25 )
		        ->setCondition( [ 'show_excerpt' => '1' ] )
		        ->get();


	}


	public function __link_content_controller( \GridaControl $control ) {

		$control->addSwitcher( 'show_link' )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( "Read More", 'grida' ) )
		        ->setDefault( '1' )
		        ->get();

		$control->addText( 'text_link' )
		        ->setLabel( esc_html__( 'Read More Text', 'grida' ) )
		        ->setDefault( esc_html__( "Read More", 'grida' ) )
		        ->setConditions( 'show_link', '1' )
		        ->get();

	}

	public function __meta_content_controller( \GridaControl $control ) {
		$control->addSelect2( 'meta_data', [
			'date'     => esc_html__( 'Date', 'grida' ),
			'category' => esc_html__( 'Category', 'grida' ),
		] )->setMultiple()->setDefault( array() )->setSeparator( "before" )->setLabel( esc_html__( 'Meta Data', 'grida' ) )->get();

		$control->addText( 'separator_between' )->setLabel( esc_html__( 'Separator Between', 'grida' ) )->setDefault( '||' )->setConditions( 'meta_data', 'contains', 'date' )->setConditions( 'meta_data', 'contains', 'category' )->setRelation( 'and' )->get();

		$control->addText( 'separator_between_cat' )->setLabel( esc_html__( 'Separator Between Category', 'grida' ) )->setDefault( ', ' )->setConditions( 'meta_data', 'contains', 'category' )->get();


		$control->addSelect( 'position_date', [
			''      => esc_html__( 'Before Title', 'grida' ),
			'after' => esc_html__( 'After Title', 'grida' ),
		] )->setDefault( '' )->setSeparator( "before" )->setLabel( esc_html__( 'Position Date', 'grida' ) )->get();


		$control->addSelect( 'position_cat', [
			''      => esc_html__( 'Before Title', 'grida' ),
			'after' => esc_html__( 'After Title', 'grida' ),
		] )->setDefault( '' )->setLabel( esc_html__( 'Position Category', 'grida' ) )->get();

	}


	public function __card_controller( \GridaControl $control ) {
		$this->start_controls_section(
			'style_card_section',
			[
				'label' => esc_html__( 'Card', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$control->addSelect( 'bg_ver_btn',
			$control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-main' )
		        ->get();

		$control->addPaddingGroup( 'item_padding', '.root-posts .dsn-posts .box-content .post-content' )
		        ->setSeparator( "before" )
		        ->getResponsive();

		$control->addMarginGroup( 'item_margin', '.root-posts .dsn-posts .box-content .post-content' )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.root-posts .dsn-posts .box-content .post-content' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.root-posts .dsn-posts .box-content .post-content' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.root-posts .dsn-posts .box-content .post-content' )->getGroup();


		$this->end_controls_section();


	}

	public function __image_style_controller( \GridaControl $control ) {
		$this->start_controls_section(
			'style_image_section',
			[
				'label' => esc_html__( 'Image', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->Spacing( 'image_space', '.dsn-post-type-classic .box-image-bg' )
		     ->setConditions( 'style_post', 'classic' )
		     ->setConditions( 'style_post', 'list' )
		     ->getResponsive();

		$control->addSelect( 'animate_image', [
			''                    => esc_html__( 'Default', 'grida' ),
			'box-image-transform' => esc_html__( 'Transform', 'grida' ),
			'box-image-parallax'  => esc_html__( 'Parallax', 'grida' ),
		] )
		        ->setLabel( esc_html__( 'Animate Image', 'grida' ) )
		        ->setDefault( '' )
		        ->setPrefix_class()
		        ->get();

		$this->end_controls_section();
	}


	public function __style_controller( \GridaControl $control ) {
		$args = array(
			'post-title'          => esc_html__( 'Title', 'grida' ),
			'entry-meta a'        => esc_html__( 'Meta Data', 'grida' ),
			'section_description' => esc_html__( 'Description', 'grida' ),
			'dsn-post-link'       => esc_html__( 'Link', 'grida' ),
		);

		foreach ( $args as $id => $value ):


			$this->start_controls_section(
				'style_content_post_' . sanitize_title( $id ),
				[
					'label' => $value,
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);

			if ( $id !== 'post-title' ) {
				$this->Spacing( 'spacing_content_' . sanitize_title( $id ), '.' . ( $id === 'post-meta a' ? 'post-meta' : $id ), $id === 'post-meta a' ? 'bottom' : 'top' )
				     ->getResponsive();
			}

			if ( $id === 'section_description' ) {
				$control->addSwitcher( 'border_left' )
				        ->setLabel( "Border Left" )
				        ->setReturn_value( 'border-before' )
				        ->get();
			}

			$control->addColor( 'color_content_' . sanitize_title( $id ) )
			        ->setLabel( esc_html__( "Color", 'grida' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content_' . sanitize_title( $id ), '.' . $id )
			        ->getGroup();

			$control->addTextShadow( 'text_content_shadow_' . sanitize_title( $id ), '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;
	}


}