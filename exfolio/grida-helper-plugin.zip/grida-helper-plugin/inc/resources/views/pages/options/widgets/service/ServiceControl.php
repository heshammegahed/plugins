<?php

namespace Dsn\Element;


trait  ServiceControl {

	public function __content_controller( \GridaControl $control ) {

		$control->addSwitcher( 'style_service' )
		        ->setLabel( esc_html__( 'With Corner', 'grida' ) )
		        ->setReturn_value( 'dsn-with-Corner' )
		        ->setPrefix_class()
		        ->get();

		$control->addSwitcher( 'with_number' )
		        ->setLabel( esc_html__( 'With Number', 'grida' ) )
		        ->setReturn_value( 'dsn-with-number' )
		        ->setPrefix_class()
		        ->get();


		$control->addChose( 'position_icon' )
		        ->setOptionChoose( 'icon-left', __( 'Left', 'elementor' ), 'eicon-h-align-left' )
		        ->setOptionChoose( 'icon-top', __( 'Top', 'elementor' ), 'eicon-v-align-top' )
		        ->setOptionChoose( 'icon-right', __( 'Right', 'elementor' ), 'eicon-h-align-right' )
		        ->setDefault( 'icon-top' )
		        ->setLabel( esc_attr__( 'Position Icon', 'grida' ) )
		        ->setPrefix_class()
		        ->get();

		$control->addChose( 'position_align' )
		        ->setOptionChoose( 'start', __( 'Start', 'elementor' ), 'eicon-v-align-top' )
		        ->setOptionChoose( 'center', __( 'Center', 'elementor' ), 'eicon-v-align-middle' )
		        ->setOptionChoose( 'end', __( 'End', 'elementor' ), 'eicon-v-align-bottom' )
		        ->setDefault( 'start' )
		        ->setSelectors( '.service-item .service-item-inner', 'align-items:{{VALUE}}' )
		        ->setConditions( 'position_icon', '!=', 'icon-top' )
		        ->setLabel( esc_attr__( 'Align Item', 'grida' ) )
		        ->getResponsive();


		$control->startRepeater();

		$control->get_element_base()->add_control(
			'icon',
			[
				'label'   => __( 'Icon', 'grida' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);


		$control->addText( "title" )
		        ->setLabelBlock()
		        ->setLabel( esc_html__( 'Title', 'grida' ), true )
		        ->setDefault( esc_html__( 'Title Service', 'grida' ) )
		        ->setDynamicActive( true )
		        ->get();

		$control->addTextareaEditor( "description" )
		        ->setLabel( esc_html__( 'Description', 'grida' ), true )
		        ->setDefault( '<p>Te qui alii inermis vivendum, an decore libris eum. Te mel dico alia wisi, cu vitae noluisse <a href="#0" target="_blank">phaedrum</a> .</p>' )
		        ->setDynamicActive( true )
		        ->get();

		$control->addLink( 'link' )
		        ->setLabel( esc_html__( 'Link', 'grida' ), true )
		        ->setDynamicActive( true )
		        ->setDefault_url()
		        ->setDefault_is_external( true )
		        ->setDefault_is_nofollow( true )
		        ->get();

		$control->addTextarea( 'text_link' )
		        ->setLabel( esc_html__( 'Text Link', 'grida' ), true )
		        ->setDefault( esc_html__( "Read More", 'grida' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'link[url]', '!=', '' )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( "Item Service" )
		        ->setTitle_field( 'title' )
		        ->get();


	}


	public function __style_controller( \GridaControl $control ) {
		$control->getAlign()
		        ->setDefault( "left" )
		        ->getResponsive();

		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Service', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Service', 'grida' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-main' )
		        ->get();

		$control->addPaddingGroup( 'item_padding_service', '.service-item-inner' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.service-item' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.service-item' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.service-item' )->getGroup();
	}

	public function __style_content_controller( \GridaControl $control ) {
		$args = array(
			'service_title'       => esc_html__( 'Title', 'grida' ),
			'service_description' => esc_html__( 'Description', 'grida' )
		);

		foreach ( $args as $id => $value ):

			$this->start_controls_section(
				'style_content_service_' . $id,
				[
					'label' => $value,
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);


			$control->addColor( 'color_content_' . $id )
			        ->setLabel( esc_html__( "Color", 'grida' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content_' . $id, '.' . $id )
			        ->getGroup();

			if ( $id === 'service_title' ) {
				$control->addSize()
				        ->setDefault( 'title-block' )
				        ->get();
				$control->addSelect( 'line_service_item', [
					''                                           => esc_html__( 'Default', '' ),
					'border-top pt-20'                           => esc_html__( 'Border Top', 'grida' ),
					'border-bottom pb-20 mb-20'                  => esc_html__( 'Border Bottom', 'grida' ),
					'border-top pt-20 border-bottom pb-20 mb-20' => esc_html__( 'Both Border Bottom', 'grida' ),
					'border-section-bottom'                      => esc_html__( 'Border Bottom Line', 'grida' ),
					'border-section-bottom border-top pt-20 '    => esc_html__( 'Both Border Bottom Line', 'grida' ),
				] )
				        ->setDefault( 'border-top pt-20' )
				        ->setLabel( __( 'Line Text', 'grida' ) )
				        ->get();
			} else {
				$control->addSpacing( 'space_' . $id, '.' . $id, 'top' )
				        ->get();
			}


			$control->addTextShadow( 'text_content_shadow_' . $id, '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;


		$this->start_controls_section(
			'style_content_service_icon',
			[
				'label' => esc_html__( "icon", 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-service .dsn-icon i', 'font-size: {{SIZE}}{{UNIT}};' )
		        ->setSelectors( '.dsn-icon svg', 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};' )
		        ->setSelectors( '.dsn-icon svg path', 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addPaddingGroup( 'item_padding_icon', '.dsn-icon i ,{{WRAPPER}} .dsn-icon  svg' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius_icon', '.dsn-icon i ,{{WRAPPER}} .dsn-icon svg' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style_icon', '.dsn-icon i ,{{WRAPPER}} .dsn-icon  svg' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow_icon', '.dsn-icon i ,{{WRAPPER}} .dsn-icon  svg' )->getGroup();

		$this->end_controls_section();
	}

}