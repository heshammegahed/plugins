<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
};

/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class GridaList extends \Dsn\Element\GridaLayout {

	use \Dsn\Element\Grida_Widget_Base;


	protected $range_col = 15;
	protected $range_row = 15;

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_list';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Grida List', 'grida' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-bullet-list';

	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'list' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Accordion', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();

		$this->getLayout();
		$control->addSwitcher( 'list_with_number' )
		        ->setLabel( esc_html__( "List With Number", 'grida' ) )
		        ->setDescription( esc_html__( "if Us this feature can't us icon with list" ) )
		        ->get();


		$control->startRepeater();


		$control->get_element_base()->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'elementor' ),
				'type'  => \Elementor\Controls_Manager::ICONS,
			]
		);

		$control->addTextarea( 'text' )
		        ->setDefault( 'Web Design' )
		        ->setLabel( esc_html__( "Text", 'grida' ) )
		        ->setLabelBlock()
		        ->setDynamicActive( true )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( esc_html__( 'List Items', 'grida' ) )
		        ->setTitle_field( 'text' )
		        ->get();

		$control->addSize()
		        ->setSeparator( "before" )
		        ->get();
		$control->addHtmlTag()->setDefault('p')->get();


		$this->end_controls_section();

		$this->styleTab();
	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'grida' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->getGridSpace();

		$this->end_controls_section();


	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$control = new gridaShortCode( array( 'widget-base' => $this ) );

		$items_key = $this->getKeys( 'items', [ 'text' ] );

		$this->addPrefixClass( 'dsn-list', $control );
		$this->addAnimateFade( 'list-item', $control );
		$this->add_render_attribute( 'dsn-list', 'class', 'dsn-list' );

		echo '<ul ' . $this->get_render_attribute_string( 'dsn-list' ) . '>';
		echo grida_shortcode_render_group( 'list', array( 'widget-base' => $this ), $items_key );
		echo '</ul>';

	}


}
