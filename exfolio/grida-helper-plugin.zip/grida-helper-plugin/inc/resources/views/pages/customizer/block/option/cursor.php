<?php
Kirki::add_section( $dsn_section, array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Cursor Follower', 'grida' ),
    'icon'  => 'dashicons-remove',

) );

Kirki::add_field( $dsn_customize, [
    'type'     => 'toggle',
    'settings' => 'effect_cursor',
    'label'    => esc_html__( 'Effect Cursor', 'grida' ),
    'section'  => $dsn_section,
    'default'  => 0,
] );

Kirki::add_field( $dsn_customize, [
    'type'            => 'slider',
    'settings'        => 'cursor_drag_speed',
    'label'           => esc_html__( 'Cursor Drag Speed', 'grida' ),
    'description'     => esc_html__( 'The lower the value is, the faster virtual mouse follower will attract to the native cursor pointer.', 'grida' ),
    'section'         => $dsn_section,
    'default'         => 0.3,
    'choices'         => [
        'min'  => 0.1,
        'max'  => 0.5,
        'step' => 0.1,
    ],
    'active_callback' => [
        [
            'setting'  => 'effect_cursor',
            'operator' => '==',
            'value'    => '1',
        ]
    ],
] );

