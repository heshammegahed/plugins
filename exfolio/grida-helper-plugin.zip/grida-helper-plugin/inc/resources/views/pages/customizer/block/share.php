<?php


Kirki::add_section( $dsn_section , array(
    'panel' => $dsn_panel ,
    'title' => esc_html__( 'Share Links' , 'daro' ),
    'icon'=>'dashicons-share'

) );



daro_custom_Label( $dsn_section , 'Share Links' );

Kirki::add_field( $dsn_customize , [
    'type'        => 'toggle' ,
    'settings'    => 'share_link' ,
    'label'       => esc_html__( 'Sharing Buttons' , 'daro' ) ,
    'description' => esc_html__( 'enable you to add social share buttons to WordPress' , 'daro' ) ,
    'section'     => $dsn_section ,
    'default'     => false ,
] );


Kirki::add_field( $dsn_customize , [
    'type'            => 'sortable' ,
    'settings'        => 'show_hide_share_link' ,
    'label'           => esc_html__( 'This is Share Buttons' , 'daro' ) ,
    'section'         => $dsn_section ,
    'default'         => [
        'facebook' ,
        'twitter' ,
        'google-plus' ,
        'pinterest' ,
    ] ,
    'choices'         => [
        'facebook'    => esc_html__( 'Facebook' , 'daro' ) ,
        'twitter'     => esc_html__( 'Twitter' , 'daro' ) ,
        'google-plus' => esc_html__( 'Google+' , 'daro' ) ,
        'pinterest'   => esc_html__( 'Pinterest' , 'daro' ) ,
        'get-pocket'  => esc_html__( 'Get Pocket' , 'daro' ) ,
        'telegram'    => esc_html__( 'Telegram' , 'daro' ) ,
    ] ,
    'active_callback' => [
        [
            'setting'  => 'share_link' ,
            'operator' => '==' ,
            'value'    => true ,
        ]
    ] ,
] );