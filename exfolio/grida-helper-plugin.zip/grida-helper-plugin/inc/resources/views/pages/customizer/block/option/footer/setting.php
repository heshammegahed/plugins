<?php
/**
 * Normal Static Setting
 */
Kirki::add_section( $dsn_section, array(
	'panel'       => $dsn_panel,
	'title'       => esc_html__( 'Footer Default', 'eremia' ),
	'description' => esc_html__( 'When you create a page, it\'s going to be default.', 'eremia' )
) );

Kirki::add_field( $dsn_customize, [
	'type'      => 'radio',
	'settings'  => 'footer_setting_pages',
	'label'     => esc_html__( 'Footer Default Setting ( Pages )', 'eremia' ),
	'section'   => $dsn_section,
	'default'   => 'static',
	'priority'  => 10,
	'choices'   => [
		'static'  => esc_html__( 'Footer Static', 'eremia' ),
		'normal'  => esc_html__( 'Footer Normal Widget', 'eremia' ),
		'feature' => esc_html__( 'Footer Feature Widget', 'eremia' ),
	],
	'transport' => 'auto',
] );

Kirki::add_field( $dsn_customize, [
	'type'      => 'radio',
	'settings'  => 'footer_setting_portfolio',
	'label'     => esc_html__( 'Footer Default Setting ( eremia Portfolio )', 'eremia' ),
	'tooltip'   => esc_html__( 'It will activate this feature when you deactivate the next project', 'eremia' ),
	'section'   => $dsn_section,
	'default'   => 'static',
	'priority'  => 10,
	'choices'   => [
		'static'  => esc_html__( 'Footer Static', 'eremia' ),
		'normal'  => esc_html__( 'Footer Normal Widget', 'eremia' ),
		'feature' => esc_html__( 'Footer Feature Widget', 'eremia' ),
	],
	'transport' => 'auto',
] );