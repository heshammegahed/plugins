<?php
/**
 *  Home Page
 */

Kirki::add_section( $dsn_section, array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Production', 'eremia' ),
    'icon'=>'dashicons-admin-home'
) );


eremia_custom_Label( $dsn_section, 'Product' );


Kirki::add_field( $dsn_customize, [
    'type'     => 'select',
    'settings' => 'product_show_sidebar',
    'label'    => esc_html__( 'Sidebar', 'eremia' ),
    'section'  => $dsn_section,
    'default'  => 'show',
    'multiple' => 1,
    'choices'  => [
        'show' => esc_html__( 'Show', 'eremia' ),
        'hide' => esc_html__( 'Hide', 'eremia' )
    ]
] );

Kirki::add_field( $dsn_customize, [
    'type'     => 'radio-buttonset',
    'settings' => 'product_style_setting',
    'label'    => esc_html__( 'Background Color', 'eremia' ),
    'section'  => $dsn_section,
    'default'  => 'v-light',
    'priority' => 10,
    'choices'  => [
        'v-dark'  => esc_html__( 'Dark', 'eremia' ),
        'v-light' => esc_html__( 'Light', 'eremia' ),
    ],
] );
