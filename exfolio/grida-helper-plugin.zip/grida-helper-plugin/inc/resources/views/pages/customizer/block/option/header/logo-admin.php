<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Logo Admin', 'grida' )

) );
Kirki::add_field( $dsn_customize, [
	'type'     => 'image',
	'settings' => 'admin_custom_logo',
	'label'    => esc_html__( 'Admin Login Logo', 'grida' ),
	'section'  => $dsn_section,
	'default'  => '',

] );


Kirki::add_field( $dsn_customize, [
	'type'        => 'number',
	'settings'    => 'admin_width_number',
	'label'       => esc_html__( 'Admin Logo Width', 'grida' ),
	'description' => esc_html__( '0 for auto width', 'grida' ),
	'section'     => $dsn_section,
	'default'     => 80,
	'choices'     => [
		'min'  => 0,
		'step' => 10,
	],
] );


Kirki::add_field( $dsn_customize, [
	'type'        => 'number',
	'settings'    => 'admin_height_number',
	'label'       => esc_html__( 'Admin Logo Height', 'grida' ),
	'description' => esc_html__( '0 for auto Height', 'grida' ),
	'section'     => $dsn_section,
	'default'     => 80,
	'choices'     => [
		'min'  => 0,
		'step' => 10,
	],
] );


