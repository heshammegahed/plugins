<?php

Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Footer Static Option', 'eremia' ),
) );


Kirki::add_field( $dsn_customize, [
	'type'              => 'textarea',
	'settings'          => 'footer_cr',
	'label'             => esc_attr__( 'Footer Credits Text', 'eremia' ),
	'description'       => esc_attr__( 'Allowed HTML Tags: a, em, br, strong, img, i. and you can use year dynamic add :y', 'eremia' ),
	'section'           => $dsn_section,
	'sanitize_callback' => 'eremia_sanitize_minimal_decoration',
	'default'           => '<p>:y &copy; ' . get_bloginfo( 'name' ) . '</p>',
	'transport'         => 'postMessage',
	'js_vars'           => [
		[
			'element'  => 'footer.footer.footer-static',
			'function' => 'html',
		]
	]
] );