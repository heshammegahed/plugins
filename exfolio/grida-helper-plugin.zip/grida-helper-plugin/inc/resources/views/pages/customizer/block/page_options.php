<?php


$panels = $dsn_panel . "-pages-option";

Kirki::add_panel( $panels, array(
    'title'       => esc_html__( 'Pages Settings', 'grida' ),
    'description' => esc_html__( 'Options Pages Theme', 'grida' ),
    'panel'       => $dsn_panel,
    'icon'        => 'dashicons-screenoptions'
) );


grida_resources_customize( 'option/page/home', array(
    'dsn_panel'     => $panels,
    'dsn_customize' => $dsn_customize,
    'dsn_section'   => $dsn_section . '-home',
) );

grida_resources_customize( 'option/page/archive', array(
    'dsn_panel'     => $panels,
    'dsn_customize' => $dsn_customize,
    'dsn_section'   => $dsn_section . '-archive',
) );

//grida_resources_customize( 'option/page/production', array(
//    'dsn_panel'     => $panels,
//    'dsn_customize' => $dsn_customize,
//    'dsn_section'   => $dsn_section . '-production',
//) );

grida_resources_customize( 'option/page/404', array(
    'dsn_panel'     => $panels,
    'dsn_customize' => $dsn_customize,
    'dsn_section'   => $dsn_section . '-404',
) );



grida_custom_Label( $dsn_section, 'Code Html' );

Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'html_head_code',
    'label'     => esc_html__( 'Code HTML Header', 'grida' ),
    'section'   => $dsn_section,
    'default'   => '',
    'transport' => 'postMessage',
    'choices'   => [
        'language' => 'html',
    ],
    'priority'  => 160,
] );


Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'html_footer_code',
    'label'     => esc_html__( 'Code HTML Footer', 'grida' ),
    'section'   => $dsn_section,
    'default'   => '',
    'transport' => 'postMessage',
    'choices'   => [
        'language' => 'html',
    ],
    'priority'  => 161,
] );


