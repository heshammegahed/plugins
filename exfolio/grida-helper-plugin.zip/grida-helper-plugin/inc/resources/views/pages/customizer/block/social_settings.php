<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Social Settings', 'grida' ),
	'icon'  => 'dashicons-networking'

) );






Kirki::add_field( $dsn_customize, [
	'type'      => 'repeater',
	'label'     => esc_html__( 'All Social', 'grida' ),
	'section'   => $dsn_section,
	'transport' => 'postMessage',

	'row_label'    => [
		'type'  => 'field',
		'value' => esc_html__( 'Social Settings', 'grida' ),
		'field' => 'name',
	],
	'button_label' => esc_html__( '"Add new" (Social) ', 'grida' ),
	'settings'     => 'dsn_socials',
	'fields'       => [

		'init_name'      => [
			'type'      => 'text',
			'label'     => esc_html__( 'initial Social Name', 'grida' ),
			'default'   => '',
			'transport' => 'postMessage',

		],
		'icon'           => [
			'type'        => 'text',
			'label'       => esc_html__( 'Icon Social', 'grida' ),
			'description' => __( 'You can control this icons from <a href="https://fontawesome.com/icons?d=gallery&m=free" target="_blank" >This Page </a> copy into class like fab fa-500px', 'grida' ),
			'default'     => '',
			'transport'   => 'postMessage',


		],
		'link'           => [
			'type'    => 'textarea',
			'label'   => esc_html__( 'URL', 'grida' ),
			'default' => '',

		]
	],
	'default'      => grida_default_social()
] );