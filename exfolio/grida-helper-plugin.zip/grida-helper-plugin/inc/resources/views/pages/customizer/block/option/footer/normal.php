<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Footer Normal Option', 'eremia' ),
) );

/**
 * Footer Layout and Order
 */
eremia_custom_Label( $dsn_section,
	esc_html__( 'Number of Columns', 'eremia' ),
	esc_html__( 'This setting creates a widget area per each column. You can edit your widgets in WordPress admin panel.', 'eremia' )
);


Kirki::add_field( $dsn_customize, [
	'type'     => 'sortable',
	'settings' => 'footer-normal-columns',
	'section'  => $dsn_section,
	'default'  => [
		'footer-1',
		'footer-2',
		'footer-3',
	],
	'choices'  => [
		'footer-1' => esc_html__( 'Footer Normal Column 1', 'eremia' ),
		'footer-2' => esc_html__( 'Footer Normal Column 2', 'eremia' ),
		'footer-3' => esc_html__( 'Footer Normal Column 3', 'eremia' ),
		'footer-4' => esc_html__( 'Footer Normal Column 4', 'eremia' ),
	]
] );


Kirki::add_field( $dsn_customize, [
	'type'     => 'radio-buttonset',
	'settings' => 'footer-normal-bg',
	'label'    => esc_html__( 'Background Section', 'eremia' ),
	'section'  => $dsn_section,
	'default'  => 'background-main',
	'priority' => 10,
	'choices'  => [
		'background-main'    => esc_html__( 'Main Color', 'eremia' ),
		'background-section' => esc_html__( 'Section Color', 'eremia' ),
		'background-theme'   => esc_html__( 'Theme Color', 'eremia' ),
	],
] );

Kirki::add_field( $dsn_customize, [
	'type'     => 'radio-buttonset',
	'settings' => 'footer-normal-width',
	'label'    => esc_html__( 'Width Footer', 'eremia' ),
	'section'  => $dsn_section,
	'default'  => 'container',
	'priority' => 10,
	'choices'  => [
		'container'     => esc_html__( 'Container', 'eremia' ),
		'dsn-container' => esc_html__( 'Wide Container', 'eremia' )
	],
] );
