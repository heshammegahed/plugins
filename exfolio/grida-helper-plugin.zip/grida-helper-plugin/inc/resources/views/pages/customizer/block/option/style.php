<?php
Kirki::add_section( $dsn_section, array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Style', 'grida' ),
    'icon'  => 'dashicons-admin-customizer',

) );


Kirki::add_field( $dsn_customize, [
    'type'     => 'toggle',
    'settings' => 'button_style_theme',
    'label'    => esc_html__( 'Show Button Style Theme', 'grida' ),
    'section'  => $dsn_section,
    'default'  => 0,

] );


Kirki::add_field( $dsn_customize, [
    'type'     => 'toggle',
    'settings' => 'dsn_lazy_image',
    'label'    => esc_html__( 'Lazy Load Image', 'grida' ),
    'description'    => esc_html__( 'This feature stops offscreen images from loading until a visitor scrolls to them. Make your page load faster, use less bandwidth and fix the “defer offscreen images” recommendation from a Google PageSpeed test.', 'grida' ),
    'section'  => $dsn_section,
    'default'  => 0,

] );