<?php

$panels = $dsn_panel . "-header-option";
Kirki::add_panel( $panels, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Header', 'grida' ),
	'icon'  => 'dashicons-welcome-widgets-menus'


) );

grida_resources_customize( 'option/header/logo', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-logo',
) );
grida_resources_customize( 'option/header/logo-admin', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-logo-admin',
) );


add_action( 'wp_head', function () {
	$width_logo       = get_theme_mod( 'width_number', 0 );
	$width_logo       = ( (int) $width_logo === 0 ) ? 'auto' : $width_logo . 'px';
	$height_logo      = get_theme_mod( 'height_number', 0 );
	$height_logo      = ( (int) $height_logo === 0 ) ? 'auto' : $height_logo . 'px';
	$logo_size_number = get_theme_mod( 'logo_size_number', 30 );

	printf( '<style>.site-header .inner-header .main-logo img{width:%s !important;height: %s !important}.main-logo h4{font-size:%s}</style>', $width_logo, $height_logo, $logo_size_number . 'px' );
	printf( '<style id="grida_code_css">%s</style>', get_theme_mod( 'css_head_code' ) );
	printf( '<script id="grida_code_js_head">%s</script>', get_theme_mod( 'js_head_code' ) );


} );

grida_resources_customize( 'option/header/code', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-code',
) );


add_action( 'wp_footer', function () {
	printf( '<script>%s</script>', get_theme_mod( 'js_footer_code' ) );
} );

add_action( 'grida_add_code_header', function () {
	printf( '<div class="grida_acht">%s</div>', get_theme_mod( 'html_head_code' ) );
} );
return ;