<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Preload', 'grida' ),
	'icon'  => 'dashicons-welcome-view-site',

) );

Kirki::add_field( $dsn_customize, [
	'type'        => 'toggle',
	'settings'    => 'page_preloader',
	'label'       => esc_html__( 'Page Preloader', 'grida' ),
	'description' => esc_html__( 'Enable preloader mask while the page is loading.', 'grida' ),
	'section'     => $dsn_section,
	'default'     => '1',
] );

Kirki::add_field( $dsn_customize, [
	'type'            => 'text',
	'settings'        => 'title-load-page',
	'label'           => esc_html__( 'Title Load Page', 'grida' ),
	'section'         => $dsn_section,
	'default'         => get_bloginfo( 'name' ),
	'active_callback' => [
		[
			'setting'  => 'page_preloader',
			'operator' => '==',
			'value'    => '1',
		]
	],

] );

Kirki::add_field( $dsn_customize, [
	'type'            => 'toggle',
	'settings'        => 'typography_preloader',
	'label'           => esc_html__( 'typography Preloader', 'grida' ),
	'description'     => esc_html__( 'Enable preloader mask while the page is loading.', 'grida' ),
	'section'         => $dsn_section,
	'default'         => false,
	'active_callback' => [
		[
			'setting'  => 'page_preloader',
			'operator' => '==',
			'value'    => '1',
		]
	],
] );

Kirki::add_field( $dsn_customize, array(
	'type'     => 'typography',
	'settings' => 'loading_text',
	'section'  => $dsn_section,
	'label'    => esc_html__( 'Loading Title', 'droow' ),

	'choices' => [
		'fonts' => [
			'standard' => [ 'sans-serif' ],
		],
	],

	'default'         => array(
		'font-family'    => 'Poppins',
		'font-weight'    => '500',
		'font-size'      => '65px',
		'letter-spacing' => '10px',

	),
	'output'          => array(
		array(
			'element' => '.preloader .title',
		),
	),
	'active_callback' => [
		[
			'setting'  => 'page_preloader',
			'operator' => '==',
			'value'    => '1',
		],
		[
			'setting'  => 'typography_preloader',
			'operator' => '==',
			'value'    => true,
		]
	],

) );