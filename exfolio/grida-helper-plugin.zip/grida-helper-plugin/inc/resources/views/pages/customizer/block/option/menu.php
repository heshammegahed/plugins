<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Menu', 'grida' ),
	'icon'  => 'dashicons-menu-alt3',

) );


Kirki::add_field( $dsn_customize, [
	'type'      => 'background',
	'settings'  => 'background_setting_menu',
	'label'     => esc_html__( 'Background Menu', 'grida' ),
	'section'   => $dsn_section,
	'default'   => [
		'background-image'      => '',
		'background-repeat'     => 'repeat',
		'background-position'   => 'center center',
		'background-size'       => 'cover',
		'background-attachment' => 'scroll',
	],
	'transport' => 'auto',
	'output'    => [
		[
			'element' => 'body:not(.classic-menu) .site-header .extend-container .main-navigation',
		],
	],
] );


Kirki::add_field( $dsn_customize, [
	'type'     => 'toggle',
	'settings' => 'custom_color_menu',
	'label'    => esc_html__( 'Custom Color Menu', 'grida' ),
	'section'  => $dsn_section,
	'default'  => false
] );


Kirki::add_field( $dsn_customize, [
	'type'            => 'color',
	'settings'        => 'color_setting_rgba_menu',
	'label'           => __( 'Color Control (Hamburger Menu)', 'grida' ),
	'section'         => $dsn_section,
	'default'         => '#fff',
	'choices'         => [
		'alpha' => true,
	],
	'transport'       => 'auto',
	'output'          => [
		[
			'element'  => 'body:not(.classic-menu) .site-header .extend-container .main-navigation ul.extend-container li',
			'property' => 'color',
		],
	],
	'active_callback' => [
		[
			'setting'  => 'custom_color_menu',
			'operator' => '==',
			'value'    => true,
		]
	],

] );

Kirki::add_field( $dsn_customize, [
	'type'     => 'color',
	'settings' => 'color_setting_rgba_menu_active',
	'label'    => __( 'Color Control (Active Hamburger Menu)', 'grida' ),
	'section'  => $dsn_section,
	'default'  => get_theme_mod( 'assistant-body-color', '#65bc7b' ),
	'choices'  => [
		'alpha' => true,
	],


	'transport' => 'auto',
	'output'    => [
		[
			'element'  => 'body:not(.classic-menu) .site-header .extend-container .main-navigation ul.extend-container li.dsn-active,body:not(.classic-menu) .site-header .extend-container .main-navigation ul.extend-container li:hover ',
			'property' => 'color',
		],
	],

	'active_callback' => [
		[
			'setting'  => 'custom_color_menu',
			'operator' => '==',
			'value'    => true,
		]
	],
] );


grida_custom_Label( $dsn_section, "Menu Right Description" );
Kirki::add_field( $dsn_customize, [
	'type'      => 'editor',
	'settings'  => 'editor_setting_menu',
	'label'     => esc_html__( 'Description', 'grida' ),
	'section'   => $dsn_section,
	'default'   => '',
	'transport' => 'postMessage',
	'js_vars'   => [
		[
			'element'  => '.site-header .container-content',
			'function' => 'html',
		]
	],

] );


