<?php

Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Color', 'eremia' ),
	'icon'  => 'dashicons-admin-customizer',
) );

$dsn_color = [
	'bg-color'        => [
		'label'   => __( 'background Color Dark', 'eremia' ),
		'default' => '#000',
	],
	'assistant-color' => [
		'label'   => __( 'The assistant background Color Dark', 'eremia' ),
		'default' => '#101010',
	],
	'heading-color'   => [
		'label'   => __( 'Heading Color Dark', 'eremia' ),
		'default' => '#fff',
	],
	'font-color'      => [
		'label'   => __( 'Body Color Dark', 'eremia' ),
		'default' => '#bbb',
	],
	'theme-color'     => [
		'label'   => __( 'Theme Color Dark', 'eremia' ),
		'default' => '#14bfb5',
	],
	'border-color'    => [
		'label'   => __( 'Border Color Dark', 'eremia' ),
		'default' => '#ffffff0a',
	],
];

$dsn_color_light = [
	'bg-color'        => [
		'label'   => __( 'background Color Light', 'eremia' ),
		'default' => '#f9f9f9',
	],
	'assistant-color' => [
		'label'   => __( 'The assistant background Color Light', 'eremia' ),
		'default' => '#e6e6e6',
	],
	'heading-color'   => [
		'label'   => __( 'Heading Color Light', 'eremia' ),
		'default' => '#000',
	],
	'font-color'      => [
		'label'   => __( 'Body Color Light', 'eremia' ),
		'default' => '#0009',
	],
	'theme-color'     => [
		'label'   => __( 'Theme Color Light', 'eremia' ),
		'default' => '#d90a2c',
	],
	'border-color'    => [
		'label'   => __( 'Border Color Light', 'eremia' ),
		'default' => '#bebebe',
	],
];

Kirki::add_field( $dsn_section, [
	'type'     => 'switch',
	'settings' => 'dsn_custom_color',
	'label'    => esc_html__( 'Custom Color Theme', 'eremia' ),
	'section'  => $dsn_section,
	'default'  => '',


	'choices' => [
		'on'  => esc_html__( 'Enable', 'eremia' ),
		'off' => esc_html__( 'Disable', 'eremia' ),
	],
] );

foreach ( $dsn_color as $key => $value ):
	Kirki::add_field( $dsn_section, [
		'type'     => 'color',
		'settings' => $key,
		'label'    => $value['label'],
		'section'  => $dsn_section,
		'default'  => $value['default'],

		'active_callback' => [
			[
				'setting'  => 'dsn_custom_color',
				'operator' => '==',
				'value'    => '1',
			],
		],
	] );
endforeach;

eremia_custom_Label( $dsn_section, __( 'Version Light', 'eremia' ), '', [
	[
		'setting'  => 'dsn_custom_color',
		'operator' => '==',
		'value'    => '1',
	],
] );


foreach ( $dsn_color_light as $key => $value ):
	Kirki::add_field( $dsn_section, [
		'type'     => 'color',
		'settings' => $key . '-light',
		'label'    => $value['label'],
		'section'  => $dsn_section,
		'default'  => $value['default'],

		'active_callback' => [
			[
				'setting'  => 'dsn_custom_color',
				'operator' => '==',
				'value'    => '1',
			],
		],
	] );
endforeach;


if ( get_theme_mod( 'dsn_custom_color' ) ) {
	add_action( 'wp_head', function () use ( $dsn_color, $dsn_color_light ) { ?>
        <style id="eremia_style_color">
            :root, :root .v-light, :root .v-light-head {
            <?php
				foreach ($dsn_color_light as $key => $value):
			printf('--%s:%s;' , $key , get_theme_mod($key. '-light' , $value['default']));
		 endforeach;
			?>

            }

            :root .v-light.background-theme, :root .v-light-head.background-theme,
            :root .v-light .background-theme, :root .v-light-head .background-theme,
            :root .v-light .calendar_wrap table tr td#today, :root .v-light-head .calendar_wrap table tr td#today {
                --heading-color: #fff;
                --font-color: #fff;
                color: var(--font-color);
            }


            :root .v-dark, :root .v-dark-head {
            <?php
				foreach ($dsn_color as $key => $value):

                printf('--%s:%s;' , $key , get_theme_mod($key , $value['default']));
             endforeach;
			?>

            }

            :root .v-dark.background-theme, :root .v-dark-head.background-theme,
            :root .v-dark .background-theme, :root .v-dark-head .background-theme {
                --font-color: #fff;
            }

        </style>
	<?php }, 100 );
}