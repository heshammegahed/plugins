<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Portfolio', 'grida' ),
	'icon'  => 'dashicons-portfolio',

) );

Kirki::add_field( $dsn_customize, [
	'type'        => 'text',
	'settings'    => 'grida-project-slug',
	'label'       => esc_html__( 'Portfolio custom slug', 'grida' ),
	'description' => esc_html__( 'if you want your portfolio post type to have a custom slug in the url.', 'grida' ),
	'section'     => $dsn_section,
	'default'     => grida_project_slug(),


] );

Kirki::add_field( $dsn_customize, [
	'type'        => 'text',
	'settings'    => 'grida-category-slug',
	'label'       => esc_html__( 'Category Portfolio custom slug', 'grida' ),
	'description' => esc_html__( 'if you want your Category portfolio post type to have a custom slug in the url.', 'grida' ),
	'section'     => $dsn_section,
	'default'     => grida_category_slug(),

] );
Kirki::add_field( $dsn_customize, [
	'type'     => 'toggle',
	'settings' => 'hide_next_project',
	'label'    => esc_html__( 'Hide Next Project', 'grida' ),
	'section'  => $dsn_section,
	'default'  => false,
] );