<?php
Kirki::add_section( $dsn_section . '_html', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Code HTml', 'grida' )

) );

Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'html_head_code',
    'label'     => esc_html__( 'Add Code HTML', 'grida' ),
    'section'   => $dsn_section . '_html',
    'default'   => '',
    'choices'   => [
        'language' => 'html',
    ],
    'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => 'body > .grida_acht',
            'function' => 'html',

        ]
    ]
] );


Kirki::add_section( $dsn_section . '_css', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Add Code CSS', 'grida' )

) );


Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'css_head_code',
    'label'     => esc_html__( 'Code CSS Header', 'grida' ),
    'section'   => $dsn_section . '_css',
    'default'   => '',
    'choices'   => [
        'language' => 'css',
    ],
    'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => '#grida_code_css',
            'function' => 'html',
        ]
    ]
] );

Kirki::add_section( $dsn_section . '_js', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Add Code JS', 'grida' )

) );
Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'js_head_code',
    'label'     => esc_html__( 'Code JS Header', 'grida' ),
    'section'   => $dsn_section . '_js',
    'default'   => '',
    'choices'   => [
        'language' => 'js',
    ],
    'transport' => 'auto',
    
] );
