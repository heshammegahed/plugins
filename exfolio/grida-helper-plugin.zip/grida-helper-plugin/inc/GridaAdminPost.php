<?php


class GridaAdminPost {

	private  $workSlug, $workCatSlug, $storySlug, $storyCatSlug ;

	public function __construct() {
		/**
		 * Work
		 */
		$this->workSlug    = grida_project_slug();
		$this->workCatSlug = grida_category_slug();
		add_theme_support( 'post-thumbnails', $this->workSlug );

		/**
		 * Story
		 */
		$this->storySlug    = grida_story_slug();
		$this->storyCatSlug = grida_category_story_slug();
		add_theme_support( 'post-thumbnails', $this->storySlug );


		add_action( 'init', [ $this, 'adminPost' ] );

	}


	public function adminPost() {
		$this->createWork();
		$this->createStory();
		flush_rewrite_rules();

	}

	private function createWork() {
		register_post_type( $this->workSlug, array(
			'menu_icon'       => GRIDA__PLUGIN_DIR_URL . '/assets/img/portfolio.svg',
			'hierarchical'    => true,
			'capability_type' => 'post',
			'supports'        => array( 'title', 'editor', 'author', 'thumbnail', 'revisions', 'excerpt' ),
			'labels'          => array(
				'name'         => esc_html__( 'Works', 'grida' ),
				'new_item'     => esc_html__( 'New Work', 'grida' ),
				'add_new'      => esc_html__( 'Add Work', 'grida' ),
				'add_new_item' => esc_html__( 'Add New Work', 'grida' ),
			),
			'rewrite'         => array( 'slug' => grida_custom_project_slug(), 'with_front' => false ),
			'show_in_rest'    => true,
			'public'          => true,

		) );
		$this->createCategory( $this->workCatSlug, $this->workSlug, grida_custom_category_slug() );
	}


	private function createStory() {
		register_post_type( $this->storySlug, array(
			'menu_icon'           => 'dashicons-images-alt',
			'hierarchical'        => true,
			'capability_type'     => 'post',
			'supports'            => array( 'title', 'thumbnail', 'revisions' ),
			'labels'              => array(
				'name'         => esc_html__( 'Stories', 'grida' ),
				'new_item'     => esc_html__( 'New story', 'grida' ),
				'add_new'      => esc_html__( 'Add story', 'grida' ),
				'add_new_item' => esc_html__( 'Add New story', 'grida' ),
			),
			'rewrite'             => array( 'slug' => grida_custom_story_slug(), 'with_front' => false ),
			'publicly_queryable'  => false,
			'show_in_rest'        => false,
			'exclude_from_search' => true,
			'public'              => true,
		) );

		$this->createCategory( $this->storyCatSlug, $this->storySlug, grida_custom_category_story_slug() );

	}



	private function createCategory( string $catSlug, string $postType, string $custSlug ) {


		register_taxonomy( $catSlug, $postType, array(
			'hierarchical' => true,
			'labels'       => array(
				'name'                       => esc_html__( 'Categories', 'grida' ),
				'singular_name'              => esc_html__( 'Categories', 'grida' ),
				'search_items'               => esc_html__( 'Search Categories', 'grida' ),
				'popular_items'              => esc_html__( 'Popular Categories', 'grida' ),
				'all_items'                  => esc_html__( 'All Categories', 'grida' ),
				'parent_item'                => null,
				'parent_item_colon'          => null,
				'edit_item'                  => esc_html__( 'Edit Categories', 'grida' ),
				'update_item'                => esc_html__( 'Update Categories', 'grida' ),
				'add_new_item'               => esc_html__( 'Add New Categories', 'grida' ),
				'new_item_name'              => esc_html__( 'New Categories Name', 'grida' ),
				'separate_items_with_commas' => esc_html__( 'Separate Categories with commas', 'grida' ),
				'add_or_remove_items'        => esc_html__( 'Add or remove Categories', 'grida' ),
				'choose_from_most_used'      => esc_html__( 'Choose from the most used Categories', 'grida' ),
				'not_found'                  => esc_html__( 'No Categories found.', 'grida' ),
				'menu_name'                  => esc_html__( 'Categories', 'grida' ),
			),
			'show_ui'      => true,
			'query_var'    => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => $custSlug, 'with_front' => false ),
		) );
	}

}


new GridaAdminPost();