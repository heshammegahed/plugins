<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );

if ( ! $shortcode->getVal( 'image', [ 'id' => 0 ] )['id'] ) {
	return;
}

$widget = $shortcode->getWidgetBase();

$has_caption           = $shortcode->getCaption();
$color_overlay         = $shortcode->getVal( 'color_overlay' );
$use_scrolling_effects = $shortcode->getVal( 'use_scrolling_effects', '1' );
$mouse_effects         = $shortcode->getVal( 'mouse_effects' );

$caption_render = $shortcode->getOptionArray( $items_key, 'caption', 'caption' );


$widget->add_render_attribute( 'parallax', 'class', 'img-box-parallax before-z-index' );
if ( $use_scrolling_effects ) {
	$widget->add_render_attribute( 'parallax',
		[
			'data-dsn-triggerhook' => $shortcode->getVal( 'animate_image_triggerhook', "bottm" ),
			'data-dsn-grid'        => 'move-up',
		]
	);
}


if ( $mouse_effects ) {
	$widget->add_render_attribute( 'parallax', [
		'data-dsn' => 'parallax',
		'class'    => $shortcode->getVal( 'zoom' ),
	] );
}


if ( $color_overlay ) {
	$widget->add_render_attribute( 'parallax', 'style', '--bg-overlay:' . $color_overlay . ';' );
}

$is_popup = $shortcode->getVal( 'use_as_popup' );
if ( $is_popup ) {
	$widget->add_render_attribute( 'parallax', 'class', 'has-popup' )
	       ->add_render_attribute( 'popup', [
		       'class'        => 'effect-popup before-z-index h-100',
		       'data-mfp-src' => $shortcode->getImageSrc(),
		       'data-cursor'  => 'open',
		       'data-overlay' => $shortcode->getValueNumberSlide( 'opacity_overlay', 0 ),
		       'data-title'   => esc_attr( $has_caption ),
	       ] );
} else {
	$widget->add_render_attribute( 'parallax', 'data-overlay', $shortcode->getValueNumberSlide( 'opacity_overlay', 0 ) );
}


$src_img = $shortcode->getImageParallax();



?>


<div <?php echo $widget->get_render_attribute_string( 'parallax' ) ?>>

	<?php
	if ( $is_popup ) {
		printf( '<div %s>%s</div>', $widget->get_render_attribute_string( 'popup' ), $src_img );
	} else {
		echo $src_img;
	}

	if ( $has_caption )
		printf( '<div class="cap"><span %s>%s</span></div>', $widget->get_render_attribute_string( $caption_render ), $has_caption )
	?>

</div>

