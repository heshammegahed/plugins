<#
var title = settings.title;
var fill_text = settings.fill_text;

if ( '' !== settings.link.url ) {
    view.addRenderAttribute('link' , {
            'href' : settings.link.url ,
            'class' : 'init-color' ,
    });

        if(fill_text){
            view.addRenderAttribute('link' , 'data-fill-text' , title);
            fill_text = false ;
        }

    title = `<a ${view.getRenderAttributeString( 'link' )} >${title}</a>`;



}


if(settings.use_as_title_cover){
    view.addRenderAttribute('title' , {
    'class'                : 'title-cover',
    'data-dsn-grid'        : 'move-section',
    'data-dsn-opacity'     : settings.optcity_to,
    'data-dsn-duration'    : settings.duration_title,
    'data-dsn-move'        : settings.move_to_duration,
    'data-dsn-triggerhook' : settings.triggerhook_duration,
    'style' : 'transform: translateY(' + settings.move_from_duration + ');'
    });
}

if(fill_text){
    view.addRenderAttribute('title' , 'data-fill-text' , title);
}

view.addRenderAttribute( 'title', 'class', [ 'dsn-heading-title d-inline-block',  settings.font_size , settings.dsn_line_text , settings.title_color , settings.use_as_troke ] );

view.addInlineEditingAttributes( 'title' );

var title_html = '<' + settings.dsn_html_tag  + ' ' + view.getRenderAttributeString( 'title' ) + '>' + title + '</' + settings.dsn_html_tag + '>';

print( title_html );
#>