<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new gridaShortCode( $attr );

if ( is_array( $items_key ) ) {
	$shortcode->set_items( $items_key );
}


$widget = $shortcode->getWidgetBase();

$title_color   = $shortcode->getVal( 'title_color' );
$content_color = $shortcode->getVal( 'content_color' );

$items = $shortcode->getVal( 'items', grida_default_info_header() );

if ( ! count( $items ) ) {
	return '';
}


$widget->add_render_attribute( 'list-project', 'class', 'project-info intro-project-list' );


?>


<ul <?php $widget->print_render_attribute_string( 'list-project' ) ?>>

	<?php
	foreach ( $items as $index => $value ):
		$shortcode->setSubBlock( $value );
		$title_key   = $shortcode->getItemKey( 'title', $index );
		$content_key = $shortcode->getItemKey( 'content', $index );


		?>
        <li class="p-relative">
            <h5 <?php $widget->print_render_attribute_string( $title_key ) ?>><?php $shortcode->printSubVal( 'title' ); ?></h5>
            <span><?php $shortcode->printSubVal( 'content' ); ?></span>
        </li>

	<?php endforeach; ?>

</ul>