<?php
$attr    = get_query_var( 'attr' );
$myposts = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );
$shortcode->setSubBlock( [ 'id_post' => get_the_ID() ] );

$widget = $shortcode->getWidgetBase();


$shortcode->add_parallax_attributes( 'dsn-item-content', 'box' );
$widget->add_render_attribute( 'dsn-item-content', 'class', 'box-content d-flex ' );


if ( $myposts->have_posts() ) :
	while ( $myposts->have_posts() ) :
		$myposts->the_post();
		$widget->add_render_attribute( 'dsn-item-post', 'class', [
			'dsn-item-story  grid-item over-hidden p-relative box-hover-image dsn-stories-gallery dsn-hover-text v-dark-head',
			'post-' . get_the_ID(),
			DesignGrid\gridaOption::PostCategorySlug(grida_category_story_slug()),
		], true );


		?>

        <article <?php $widget->print_render_attribute_string( 'dsn-item-post' ) ?> >

            <div class="story-content p-relative">

                <div class="link-pop effect-popup has-image" data-overlay="4"
                     data-mfp-src="<?php echo esc_url( get_the_post_thumbnail_url( null, 'full' ) ) ?>"
                     data-title="<?php echo esc_attr( get_the_title() ) ?>">
					<?php the_post_thumbnail( $shortcode->getVal( 'image_size', 'large' ), array( 'class' => 'cover-bg-img' ) ); ?>
                </div>
				<?php
				if ( $images = grida_get_option_pages( 'stroies' ) ):
					foreach ( $images as $image ):
						$img = wp_get_attachment_image_src( $image, 'full' );
						if ( isset( $img[0] ) ) {
							printf( '<div class="link-pop effect-popup" data-mfp-src="%s"></div>', esc_url( $img[0] ) );
						}

					endforeach;
				endif;
				?>

            </div>

			<?php
			$widget->add_render_attribute( 'title', [
				'class'          => [
					'has-box-mod move-circle post-title word-wrap',
					$shortcode->getVal( 'font_size', 'title-block' )
				],
				'data-dsn'       => 'parallax',
				'data-dsn-split' => 'chars',
				'style'          => '--mod-color:#FFFFFF; '
			], null, true );
			printf( '<%1$s %2$s>%3$s</%1$s>', $shortcode->getHtmlTag(), $widget->get_render_attribute_string( 'title' ), get_the_title() )
			?>


        </article>

	<?php endwhile;
endif;
wp_reset_postdata();
?>

