<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );


$widget = $shortcode->getWidgetBase();


$widget->add_render_attribute( 'skills-item', 'class', 'dsn-skills-item' );

$style_skill = $shortcode->getVal( 'style_skill', 'p' );


$widget->add_render_attribute( 'skills-inner', 'class', 'skills-inner' );
$widget->add_render_attribute( 'number', 'class', 'dsn-number-award number ' . $shortcode->getVal( 'dsn-number-skills', 'font-number' ) );
$widget->add_render_attribute( 'title', 'class', 'dsn-title-award ' . $shortcode->getVal( 'dsn-title-skills', 'sm-title-block' ) );
?>

<div <?php $widget->print_render_attribute_string( 'skills-item' ) ?>>
    <div <?php $widget->print_render_attribute_string( 'skills-inner' ) ?>>

		<?php
		if ( $style_skill === 'p' ):
			if ( $title = $shortcode->getVal( 'title', esc_html__( 'Enter Text Skills', 'grida' ) ) ) {
				$widget->add_render_attribute( 'title', 'class', 'mb-15' );
				printf( '<h6 %1$s>%2$s</h6>', $widget->get_render_attribute_string( 'title' ), $title );
			}

			if ( $num = $shortcode->getVal( 'number', '50' ) ) :


				$widget->add_render_attribute( 'fill', [
					'class' => [
						'fill dsn-animate-skill box-shadow',
						$shortcode->getVal( 'bg_item', 'background-transparent' ),
						$shortcode->getVal( 'bg_ver_item', '' )
					],
					'style' => 'width:' . $num . '%;'

				] );


				printf( '<div class="bar-progress"><span %3$s data-width="%2$s" ><span %1$s>%2$s</span></span></div>', $widget->get_render_attribute_string( 'number' ), $num . "%", $widget->get_render_attribute_string( 'fill' ) );
			endif;
        elseif ( $style_skill === 'c' ):

			?>

            <div class="bar-svg">
				<?php
				if ( $num = $shortcode->getVal( 'number', '50' ) ) :
					$widget->add_render_attribute( 'number', 'class', 'v-middle' );

					$widget->add_render_attribute( 'fill', [
						'class' => [
							'fill-bar p-relative',
							$shortcode->getVal( 'bg_item', 'background-transparent' ),
							$shortcode->getVal( 'bg_ver_item', '' )
						],

					] );

					$widget->add_render_attribute( 'fill-bar', [
						'class'      => 'progress-bar__progress js-progress-bar dsn-animate-skill',
						'style'      => 'stroke-dashoffset:' . ( 100 - $num ) . ';',
						'data-width' => ( 100 - $num )

					] );
					?>
                    <div <?php $widget->print_render_attribute_string( 'fill' ) ?>>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="-1 -1 34 34">
                            <circle cx="16" cy="16" r="15.9155" class="progress-bar__background"/>
                            <circle cx="16" cy="16"
                                    r="15.9155" <?php $widget->print_render_attribute_string( 'fill-bar' ) ?> />
                        </svg>
						<?php printf( '<span %1$s>%2$s</span>', $widget->get_render_attribute_string( 'number' ), $num . "%" ) ?>

                    </div>
				<?php endif; ?>

				<?php
				if ( $title = $shortcode->getVal( 'title', esc_html__( 'Enter Text Skills', 'grida' ) ) ) {
					$widget->add_render_attribute( 'title', 'class', 'mt-15' );
					printf( '<h5 %1$s>%2$s</h5>', $widget->get_render_attribute_string( 'title' ), $title );
				}
				?>


            </div>

		<?php endif; ?>


    </div>
</div>


