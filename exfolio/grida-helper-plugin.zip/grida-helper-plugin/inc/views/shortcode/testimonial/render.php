<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new gridaShortCode( $attr, $items_key );


$items = $shortcode->getVal( 'items', array() );

if ( ! count( $items ) || ! is_array( $items ) ) {
	return;
}


$widget = $shortcode->getWidgetBase();

/**
 * testimonials
 */
$widget->add_render_attribute( 'testimonials', [
	'class'           => 'dsn-testimonials grida-swiper-slider dsn-swiper p-relative has-parallax-image',
	'data-dsn-option' => json_encode( $shortcode->getSwiperOption() )
] );

/**
 * testimonials-content
 */
$widget->add_render_attribute( 'swiper-slide', [
	'class' => [
		'swiper-slide',
		$shortcode->getVal( 'bg_ver_item', '' ),
		$shortcode->getVal( 'bg_item', 'background-transparent' )
	]
] );


$widget->add_render_attribute( 'box-text', 'class', 'label box-text' );
$shortcode->add_parallax_attributes( 'box-text', 'content' );

$widget->add_render_attribute( 'image', 'class', 'avatar box-img' );
$shortcode->add_parallax_attributes( 'image', 'image' );


$widget->add_render_attribute( 'quote', 'class', 'quote' );
$shortcode->add_parallax_attributes( 'quote', 'description' );


?>

<div <?php $widget->print_render_attribute_string( 'testimonials' ) ?>>

    <div class="testimonials-content">


        <div class="testimonial-inner">
            <div class="swiper-container">
                <div class="swiper-wrapper">
					<?php foreach ( $items as $index => $item ) : $shortcode->setSubBlock( $item ); ?>
                        <div <?php $widget->print_render_attribute_string( 'swiper-slide' ) ?> >
                            <div class="testimonial-item">
                                <i class="fas fa-quote-left"></i>
                                <div class="testimonial-content mb-25">
									<?php
									$content_key = $shortcode->getItemKey( 'description', $index );
									$widget->add_render_attribute( $content_key, 'class', 'max-w750 testimonial-content p-large' );
									$content = $shortcode->getSubVal( 'description' );
									if ( $content ) {
										printf( '<div %s><p %s>%s</p></div>', $widget->get_render_attribute_string( 'quote' ), $widget->get_render_attribute_string( $content_key ), $content );
									}
									?>
                                </div>
                                <div class="avatar-inner">
                                    <div class="d-flex align-items-center">
										<?php

										if ( $image = $shortcode->getAttachImage( $shortcode->getSubVal( 'image' ), $shortcode->getVal( 'image_size', 'thumbnail' ), array( 'class' => 'cover-bg-img' ) ) ) {
											printf( '<div %s>%s</div>', $widget->get_render_attribute_string( 'image' ), $image );
										}

										if ( $name = $shortcode->getSubVal( 'name', 'The Name' ) ) {
											$name_key = $shortcode->getItemKey( 'name', $index );
											$widget->add_render_attribute( $name_key, 'class', 'testimonial-name' );
											$name = sprintf( '<h4 %s>%s</h4>', $widget->get_render_attribute_string( $name_key ), $name );
										}


										if ( $position = $shortcode->getSubVal( 'position', 'The Position' ) ) {
											$position_key = $shortcode->getItemKey( 'position', $index );
											$widget->add_render_attribute( $position_key, 'class', 'testimonial-position' );
											$position = sprintf( '<h5 %s>%s</h5>', $widget->get_render_attribute_string( $position_key ), $position );
										}

										if ( $name || $position ) {
											printf( '<div %s>%s</div>', $widget->get_render_attribute_string( 'box-text' ), $name . $position );
										}

										?>

                                    </div>
                                </div>

                            </div>

                        </div>
					<?php endforeach; ?>
                </div>
            </div>
        </div>

		<?php if ( $shortcode->getVal( 'show_navigation' ) ):

			$widget->add_render_attribute( 'dsn_swiper_paginate', [
				'class' => [
					$shortcode->getVal( 'justify_content', 'justify-content-between' ),
					'control-nav p-absolute w-100  d-flex dsn-container align-items-center '
				]
			] );
			?>
            <div <?php $widget->print_render_attribute_string( 'dsn_swiper_paginate' ) ?>>
                <div class="prev-container image-zoom move-circle background-theme" data-dsn="parallax">
                    <svg viewBox="0 0 40 40">
                        <path class="path circle" d="M20,2A18,18,0,1,1,2,20,18,18,0,0,1,20,2">
                        </path>
                        <polyline class="path" points="14.6 17.45 20 22.85 25.4 17.45">
                        </polyline>
                    </svg>
                </div>
                <div class="next-container image-zoom move-circle background-theme" data-dsn="parallax">
                    <svg viewBox="0 0 40 40">
                        <path class="path circle" d="M20,2A18,18,0,1,1,2,20,18,18,0,0,1,20,2">
                        </path>
                        <polyline class="path" points="14.6 17.45 20 22.85 25.4 17.45">
                        </polyline>
                    </svg>
                </div>
            </div>
		<?php endif; ?>
    </div>
</div>
