<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );
$widget    = $shortcode->getWidgetBase();


$widget->add_render_attribute( 'dsn-gallery', 'class', 'section-image section-move-image ' );

$gallery       = $shortcode->getVal( 'gallery' );
$position_move = $shortcode->getVal( 'position_move', '' );

?>


<div <?php $widget->print_render_attribute_string( 'dsn-gallery' ) ?>>

	<?php
	if ( count( $gallery ) ): ?>


        <div class="image-container">
            <div class="swiper-container ">
                <div class="swiper-wrapper transform-move-section <?php echo esc_attr( $position_move ) ?>">
					<?php foreach ( $gallery as $img ): ?>
                        <div class="swiper-slide">
                            <div class="image-item">
								<?php echo wp_get_attachment_image( $img['id'], $shortcode->getVal( 'gallery_size' ), false, [ 'class' => 'cover-bg-img' ] ) ?>
                            </div>
                        </div>
					<?php endforeach; ?>

                </div>
            </div>

        </div>

	<?php endif; ?>
</div>
