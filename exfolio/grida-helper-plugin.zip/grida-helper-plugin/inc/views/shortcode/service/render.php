<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new gridaShortCode( $attr, $items_key );


$items = $shortcode->getVal( 'items', array() );

if ( ! count( $items ) || ! is_array( $items ) ) {
	return;
}

$widget = $shortcode->getWidgetBase();

$use_overlay_hover = $shortcode->getVal( 'use_overlay_hover', '1' );
$bg_ver_btn        = $shortcode->getVal( 'bg_ver_btn', '' );
$bg_btn            = $shortcode->getVal( 'bg_btn', 'background-main' );


$swiper_item = $shortcode->get_render_swiper_slide_attribute();

$title_size        = $shortcode->getSize( 'title-block' );
$line_service_item = $shortcode->getVal( 'line_service_item', 'border-top pt-20' );


$widget->add_render_attribute( 'service-item', 'class', [
	'service-item p-relative grid-item style-box',
	$bg_ver_btn,
	$bg_btn
] );
$widget->add_render_attribute( 'service-item', $swiper_item );


$widget->add_render_attribute( 'service-item-inner', 'class', [ 'service-item-inner h-100' ] );
$shortcode->add_parallax_attributes( 'service-item-inner', 'content' );


foreach ( $items as $index => $item ) :
	$shortcode->setSubBlock( $item );


	$title_key = $shortcode->getItemKey( 'title', $index );
	$title     = $shortcode->getSubVal( 'title' );
	$widget->add_render_attribute( $title_key, 'class', [ 'service_title', $title_size, $line_service_item ] );
	if ( $title ) {
		$title = sprintf( '<h4 %1$s>%2$s</h4>', $widget->get_render_attribute_string( $title_key ), $title );
	}

	$description_key = $shortcode->getItemKey( 'description', $index );
	$description     = $shortcode->getSubVal( 'description' );
	$widget->add_render_attribute( $description_key, 'class', [ 'service_description', 'mt-20 max-w750 dsn-auto' ] );
	if ( $description ) {
		$description = sprintf( '<div %1$s>%2$s</div>', $widget->get_render_attribute_string( $description_key ), $description );
	}

	$icon = $shortcode->getIcon( $shortcode->getSubVal( 'icon' ) );


	$link_key = $shortcode->getItemKey( 'link', $index );
	$is_link  = $shortcode->getOptionArray( $shortcode->getSubVal( 'link' ), 'url' );

	$link = '';
	if ( $is_link && ! empty( $is_link ) ) {
		$widget->add_link_attributes( $link_key, $shortcode->getSubVal( 'link', array() ) )
		       ->add_render_attribute( $link_key, 'class', [ 'link-visit p-relative dsn-btn-link body-color dsn-hover-char', ] );
		$text_link_key = $shortcode->getItemKey( 'text_link', $index );
		$widget->add_render_attribute( $text_link_key, 'class', 'info-content heading-color dsn-hover-show heading-font' );
		$widget->add_render_attribute( $text_link_key, 'data-dsn-split', 'chars' );
		$link_text = $shortcode->getSubVal( 'text_link', esc_html__( "Read More", 'grida' ) );

		$text_link_key_hide = $shortcode->getItemKey( 'text_link_hide', $index );
		$widget->add_render_attribute( $text_link_key_hide, 'class', 'info-content body-color dsn-hover-hide p-absolute heading-font' );
		$widget->add_render_attribute( $text_link_key_hide, 'data-dsn-split', 'chars' );


		$link = sprintf( '<div class="w-100 pt-20 mt-20 border-top"><a %1$s><span %2$s>%3$s</span><span %4$s>%3$s</span></a></div>',
			$widget->get_render_attribute_string( $link_key ),
			$widget->get_render_attribute_string( $text_link_key ),
			$link_text,
			$widget->get_render_attribute_string( $text_link_key_hide ),

		);
	}

	?>


    <div <?php $widget->print_render_attribute_string( 'service-item' ) ?> >

        <div <?php $widget->print_render_attribute_string( 'service-item-inner' ) ?>>
			<?php if ( $icon ) {
				printf( '<div class="dsn-icon">%1$s</div>', $icon );
			}
			printf( '<div class="service-content p-relative">%1$s %2$s %3$s</div>', $title, $description, $link );

			?>

        </div>
    </div>
<?php endforeach; ?>


