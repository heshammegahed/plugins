<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );


$widget = $shortcode->getWidgetBase();


$widget->add_render_attribute( 'bg-mask', [
	'class' => 'dsn-bg-mask ' . $shortcode->getVal( 'background_mask', 'background-section' ),
	'style' => sprintf( '--width-mask:%1$s;--width-calc-mask:%2$s;--height-mask:%3$s;--height-calc-mask:%4$s;--top-mask:%5$s;--left-mask:%6$s;--margin-left-mask:%7$s;--margin-top-mask:%8$s;',
		$shortcode->getValStyleRange( 'width_mask', 100, '%' ),
		$shortcode->getValStyleRange( 'calc_width_mask' ),
		$shortcode->getValStyleRange( 'height_mask', 100, '%' ),
		$shortcode->getValStyleRange( 'calc_height_mask' ),
		$shortcode->getValStyleRange( 'top_mask' ),
		$shortcode->getValStyleRange( 'left_mask' ),
		$shortcode->getValStyleRange( 'margin_left_mask' ),
		$shortcode->getValStyleRange( 'margin_top_mask' ),

	),
] );

printf( '<div %s></div>', $widget->get_render_attribute_string( 'bg-mask' ) );