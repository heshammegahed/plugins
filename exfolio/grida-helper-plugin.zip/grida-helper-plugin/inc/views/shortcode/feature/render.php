<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );


$widget = $shortcode->getWidgetBase();

$items = $shortcode->getVal( 'items', array() );


if ( ! count( $items ) ) {
	return;
}

$widget->add_render_attribute( 'list', 'class', 'dsn-list' );


$widget->add_render_attribute( 'list-item', 'class', [
	'list-item p-30',
	$shortcode->getVal( 'bg_ver_btn', '' ),
	$shortcode->getVal( 'bg_btn', 'background-section' )
] );

foreach ( $items as $index => $item ):
	$shortcode->setSubBlock( $item );
	$ren_text = $shortcode->getItemKey( 'text', $index );
	$text     = $shortcode->getSubVal( 'text' );

	$isIcon = ! empty( $shortcode->getSubVal( 'icon', array( 'library' => '' ) )['library'] );
	?>
    <li <?php $widget->print_render_attribute_string( 'list-item' ) ?> >
		<?php if ( $isIcon ) : ?>
            <span class="dsn-icon"><?php $shortcode->printIcon( $shortcode->getSubVal( 'icon' ) ) ?></span>
		<?php endif;

		if ( $text ) {
			printf( '<span class="sm-title-block heading-color">%s</span>', $text );
		} ?>
    </li>


<?php endforeach; ?>