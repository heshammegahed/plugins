<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );


$items = $shortcode->getVal( 'items', array() );

$widget = $shortcode->getWidgetBase();

$options = $shortcode->getSwiperOption();


if ( ! count( $items ) ) {
	return;
}


$widget->add_render_attribute( 'item-img', [
	'class' => 'item-img',
] );

$shortcode->add_parallax_attributes( 'item-img', 'parallax_image' );


$widget->add_render_attribute( 'dsn-swiper', [
	'class'           => 'grida-swiper-slider grida-media-swiper dsn-swiper',
	'data-dsn-option' => json_encode( $options ),
] );

$widget->add_render_attribute( 'swiper-slide', [
	'class' => [
		'swiper-slide over-hidden',
		$shortcode->getVal( 'bg_ver_item', '' ),
		$shortcode->getVal( 'bg_item', 'background-transparent' ),
	],
] );


$swiper_slide = $widget->get_render_attribute_string( 'swiper-slide' );
$item_image   = $widget->get_render_attribute_string( 'item-img' );

?>
<div <?php $widget->print_render_attribute_string( 'dsn-swiper' ) ?>>
    <div class="swiper-container">
        <div class="swiper-wrapper">
			<?php foreach ( $items as $index => $item ):
				$img                           = new gridaShortCode( $attr );
				$item['use_scrolling_effects'] = false;
				$img->setBlock( $item );


				$link = '';
				if ( $img->getVal( 'type_slide' ) === 'video' ) {
					$widget->add_link_attributes( 'link', $img->getVal( 'link' ) )
					       ->add_render_attribute( 'link', [
						       'class'    => 'vid play-btn zoom-image background-theme init-color',
						       'data-dsn' => 'parallax',
					       ] );
					$shortcode->add_parallax_attributes( 'link', 'parallax_video' );


					$link = sprintf( '<div class="content v-middle z-index-3"><a %1$s>%2$s</a></div>', $widget->get_render_attribute_string( 'link' ), '<svg xmlns="http://www.w3.org/2000/svg" width="512" height="512" viewBox="0 0 512 512">
    <g>
        <path d="M176,464.7a7.982,7.982,0,0,1-2.963-.571A224.077,224.077,0,0,1,32,256a8,8,0,0,1,16,0A208.073,208.073,0,0,0,178.965,449.271,8,8,0,0,1,176,464.7Z"/>
        <path d="M216.009,476.305a8.072,8.072,0,0,1-1.482-.138c-5.557-1.041-11.141-2.309-16.595-3.77a8,8,0,1,1,4.136-15.455c5.063,1.355,10.245,2.533,15.405,3.5a8,8,0,0,1-1.464,15.865Z"/>
    </g>
    <path d="M208.538,352a8,8,0,0,1-8-8V168a8,8,0,0,1,12.131-6.851l145.924,88a8,8,0,0,1,0,13.7l-145.924,88A8,8,0,0,1,208.538,352Zm8-169.833V329.833L338.971,256Z"/>
</svg>' );
				}


				printf( '<div  %1$s ><div %2$s>%3$s</div>%4$s</div>',
					$swiper_slide, $item_image,
					grida_shortcode_render_group( 'image', array( 'widget-base' => $img ), array( 'caption' => $shortcode->getItemKey( 'caption', $index ) ) ),
					$link
				);
				foreach ( $img->getWidgetBase()->get_render_attributes() as $key => $attrs ):
					$img->getWidgetBase()->remove_render_attribute( $key );
				endforeach;

			endforeach; ?>
        </div>

		<?php $shortcode->print_content_paginate_render( array(
			'class' => 'hesham',
		) ); ?>

    </div>
</div>