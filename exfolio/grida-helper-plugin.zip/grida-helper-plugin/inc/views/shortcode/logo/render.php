<div class="dsn-logo main-logo">
	<?php grida_get_template_header( 'site', 'logo' ); ?>
</div>
