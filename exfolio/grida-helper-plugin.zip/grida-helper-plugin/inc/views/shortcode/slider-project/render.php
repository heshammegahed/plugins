<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );


$widget        = $shortcode->getWidgetBase();
$effect_slider = $shortcode->getVal( 'effect_slider', '' );

if ( $effect_slider === '' ) {
	$option = $shortcode->getSwiperOption();
} else {
	$option = [
		'displacement' => GRIDA__PLUGIN_DIR_URL . 'assets/img/displacement/' . $shortcode->getVal( 'transition_slider', '8.jpg' ),
		'intensity'    => $shortcode->getValueNumberSlide( 'intensity', - 2 ),
		'speed_in'     => $shortcode->getValueNumberSlide( 'speed_in', 1.2 ),
		'speed_out'    => $shortcode->getValueNumberSlide( 'speed_out', 1.2 ),
		'vertical'    => $shortcode->getVal( 'direction_webgl', 'horizontal' ),
	];
}


$direction  = $shortcode->getVal( "direction", 'horizontal' ) === 'horizontal' ? 'has-horizontal' : '';
$next_slide = [];

$show_navigation = $shortcode->getVal( 'show_navigation' );
$show_number     = $shortcode->getVal( 'show_pagination' );

$hr = $shortcode->getVal( 'show_line' );

if ( $hr && ( $show_navigation || $show_number ) ) {
	$widget->add_render_attribute( 'main-slider', 'class', 'has-hr' );
}


$widget->add_render_attribute( 'main-slider', [
	'class'           => [
		'main-slider',
		$direction,
		$effect_slider,
		$shortcode->getVal( 'bg_ver_item', '' ),
		$shortcode->getVal( 'bg_item', 'background-transparent' ),
		$shortcode->getVal( 'dir_nav_slider_arrow', '' ),
	],
	'data-dsn-option' => json_encode( $option ),
] );

$is_custom = $shortcode->getVal( 'dsn_views' );


$myposts = $shortcode->getVal( 'items', array() );

if ( ! $is_custom ):


	$myposts = get_posts( array(
		'posts_per_page' => $shortcode->getValueNumberSlide( 'blog_pages_show_at_most', get_option( 'posts_per_page' ) ),
		'post_type'      => grida_project_slug(),
		'offset'         => $shortcode->getVal( 'offset', 0 ),
		'orderby'        => $shortcode->getVal( 'orderby', 'date' ),
		'order'          => $shortcode->getVal( 'order', 'DESC' ),
	) );
endif;


$content = '';

$show_title_area  = $shortcode->getVal( 'show_title_area', array( 'link_with_title', 'show_category' ) );
$link_with_title  = in_array( 'link_with_title', $show_title_area );
$show_sub_title   = in_array( 'show_sub_title', $show_title_area );
$show_category    = in_array( 'show_category', $show_title_area );
$show_description = in_array( 'show_description', $show_title_area );
$show_info        = in_array( 'show_info', $show_title_area );
$show_button1     = in_array( 'show_Button1', $show_title_area );
$show_button2     = in_array( 'show_Button2', $show_title_area );
$show_number      = in_array( 'show_number', $show_title_area );

$show_button = $shortcode->getVal( 'show_button' );
$text_button = $shortcode->getVal( 'text_button' );
$html_tag    = $shortcode->getHtmlTag();

?>


<!-- ========== Slider Parallax ========== -->
<div <?php $widget->print_render_attribute_string( 'main-slider' ) ?>>


    <div class="content-slider slide-inner h-100 over-hidden">
        <div class="bg-container p-absolute  dsn-hero-parallax-img  w-100 h-100 z-index-1">
            <div class="swiper-container h-100">
                <div class="swiper-wrapper">
					<?php
					foreach ( $myposts as $index => $the_p ):
						$shortcode->setSubBlock( $the_p );
						$id = $shortcode->getSubVal( 'ID' );

						$slider_item = $shortcode->getItemKey( 'slide-item', $index );
						$widget->add_render_attribute( $slider_item, [
							'class'       => 'slide-item swiper-slide over-hidden',
							'data-dsn-id' => $index,
						] );


						$slider_image = $shortcode->getItemKey( 'slide-image', $index );

						$widget->add_render_attribute( $slider_image, [
							'class' => 'image-bg cover-bg w-100 h-100 before-z-index',
						] );
						$shortcode->add_parallax_attributes( $slider_image, 'parallax_image' );

						$shortcode->add_overlay_attributes( $slider_image, $id, $is_custom );

						printf( '<div %s>', $widget->get_render_attribute_string( $slider_item ) );


						/**
						 * Image
						 */
						if ( ! $is_custom ):
							$next_slide[ $index ] = sprintf( '<div %1$s>%2$s</div>',
								$widget->get_render_attribute_string( $slider_image ),
								grida_the_post_thumbnail( 'large', array(
									'class'             => 'cover-bg-img dsn-swiper-parallax-transform',
									'data-dsn-position' => esc_attr( grida_position_image( '50', $id ) ),
								), $id, false )
							);
							grida_get_img( array(
								'before'   => sprintf( '<div %1$s>', $widget->get_render_attribute_string( $slider_image ) ),
								'after'    => '</div>',
								'before_v' => sprintf( '<div %1$s> %2$s', $widget->get_render_attribute_string( $slider_image ), '<div data-dsn="video">' ),
								'after_v'  => '</div></div>',
								'type'     => 'img',
								'size'     => grida_get_option_pages( 'image_size', 'post-thumbnail', $id ),


								'attr' => array(
									'class'             => 'cover-bg-img dsn-swiper-parallax-transform',
									'data-dsn-position' => esc_attr( grida_position_image( '50', $id ) ),
								),
							), $id );
						else:
							printf( '<div %1$s>%2$s</div>',
								$widget->get_render_attribute_string( $slider_image ),
								$shortcode->getAttachImage( $shortcode->getSubVal( 'image' ), $shortcode->getSubVal( 'image_size' ), [ 'class' => 'cover-bg-img' ] ) );
							$next_slide[ $index ] = sprintf( '<div %1$s>%2$s</div>',
								$widget->get_render_attribute_string( $slider_image ),
								$shortcode->getAttachImage( $shortcode->getSubVal( 'image' ), $shortcode->getSubVal( 'image_size' ), [ 'class' => 'cover-bg-img' ] )
							);

						endif;
						/**
						 * End Image
						 */


						$subtitle_tag = '<div class="metas mb-30 swiper-animate-head">%s</div>';

						$subtitle = '';
						if ( $show_sub_title && $subtitle = $shortcode->getSubVal( 'subtitle', '', $id ) ) {
							$subtitle = sprintf( $subtitle_tag, $subtitle );
						}


						//--> Category
						$category = '';
						if ( ! $is_custom && $show_category && $category = \DesignGrid\gridaOption::PostCategory( '', grida_category_slug(), false, $id, '<span >', '</span>' ) ) {
							$category = sprintf( $subtitle_tag, $category );
						}


						/**
						 * Title
						 */
						$tag_link = $shortcode->getItemKey( 'post_title', $index );
						$title    = $shortcode->getSubVal( 'post_title' );
						$widget->add_render_attribute( $tag_link, 'data-dsn-split', 'chars' );
						$widget->add_render_attribute( $tag_link, 'class', 'init-color' );

						if ( $link_with_title ):
							if ( $is_custom ):
								$widget->add_link_attributes( $tag_link, $shortcode->getSubVal( 'link', array() ) );
							else:
								$widget->add_render_attribute( $tag_link, [
									'href'          => get_the_permalink( $id ),
									'class'         => 'effect-ajax',
									'data-dsn-ajax' => 'slider',
								] );
							endif;
							$title = sprintf( '<a %s>%s</a>', $widget->get_render_attribute_string( $tag_link ), $title );
						else:
							$title = sprintf( '<div %s>%s</div>', $widget->get_render_attribute_string( $tag_link ), $title );
						endif;
						$title_tag = $shortcode->getItemKey( 'title_tag', $index );
						$widget->add_render_attribute( $title_tag, [
							'class'    => 'title has-box-mod p-relative move-circle',
							'data-dsn' => 'parallax',
							'style'    => '--mod-color: ' . grida_get_option_pages( 'style_box', '#FFFFFF', $id ) . '; '
						] );

						$title = sprintf( '<%1$s %2$s>%3$s</%1$s>', $html_tag, $widget->get_render_attribute_string( $title_tag ), $title );


						/**
						 * End Title
						 */


						$description = '';
						if ( $show_description ) {
							$description_tag = $shortcode->getItemKey( 'description_header', $index );
							$widget->add_render_attribute( $description_tag, [
								'class' => 'description swiper-animate-head max-w570 mt-30',
							] );
							$description = $shortcode->getSubVal( 'description_header', '', $id );
							if ( ! $is_custom && ! $description ) {
								$description = get_the_excerpt( $id );
							}

							if ( $description ) {
								$description = sprintf( '<p %1$s>%2$s</p>', $widget->get_render_attribute_string( $description_tag ), $shortcode->excerpt( $shortcode->getValueNumberSlide( 'excerpt_length', 25 ), strip_tags( $description ) ) );
							}
						}


						$link_tag   = $shortcode->getItemKey( 'link1', $index );
						$link_tag_2 = $shortcode->getItemKey( 'link2', $index );

						if ( ! $is_custom ) {
							$widget->add_render_attribute( $link_tag, [
								'href'          => get_the_permalink( $id ),
								'class'         => 'effect-ajax ',
								'data-dsn-ajax' => 'slider',
							] );
						} else {

							$widget->add_link_attributes( $link_tag, $shortcode->getSubVal( 'link1', array() ) );
							$widget->add_link_attributes( $link_tag_2, $shortcode->getSubVal( 'link2', array() ) );
						}

						$button1 = '';
						$button2 = '';


						$args_btn = [
							'class'    => [ 'dsn-btn move-circles text-center  swiper-animate-head  mr-15' ],
							'data-dsn' => 'parallax',
						];

						$widget->add_render_attribute( $link_tag, $args_btn );
						$widget->add_render_attribute( $link_tag_2, $args_btn );

						if ( $show_button1 ) {
							$widget->add_render_attribute( $link_tag, [
								'class' => [
									'btn-slider-1 border-color-default',
									$shortcode->getVal( 'bg_ver_button-1', '' ),
									$shortcode->getVal( 'bg_button-1', 'background-main' ),
								],
							] );
							$text_link = $shortcode->getItemKey( 'text_link1', $index );
							$button1   = sprintf( '<a %1$s><span %2$s>%3$s</span></a>',
								$widget->get_render_attribute_string( $link_tag ),
								$widget->get_render_attribute_string( $text_link ),
								$is_custom ? $shortcode->getSubVal( 'text_link1', esc_html__( "VIEW CASE", 'grida' ) ) : $shortcode->getVal( 'text_link', esc_html__( "VIEW CASE", 'grida' ) )

							);
						}

						if ( $is_custom && $show_button2 ) {
							$widget->add_render_attribute( $link_tag_2, [
								'class' => [
									'btn-slider-2 border-color-default',
									$shortcode->getVal( 'bg_ver_button-2', '' ),
									$shortcode->getVal( 'bg_button-2', 'background-main' ),
								],
							] );

							$text_link = $shortcode->getItemKey( 'text_link2', $index );
							$button2   = sprintf( '<a %1$s><span %2$s>%3$s</span></a>',
								$widget->get_render_attribute_string( $link_tag_2 ),
								$widget->get_render_attribute_string( $text_link ),
								$shortcode->getSubVal( 'text_link2', esc_html__( "VIEW CASE", 'grida' ) )

							);
						}

						$tag_button_start = '';
						$tag_button_end   = '';
						if ( $show_button1 || $show_button2 ) {
							$tag_button_start = '<div class="d-block mt-30 dsn-def-btn dsn-border-style">';
							$tag_button_end   = '</div>';
						}


						/**
						 * Content
						 */
						$slid_content = $shortcode->getItemKey( 'slid_content', $index );
						$widget->add_render_attribute( $slid_content, [
							'class'       => [ 'slide-content', 'p-absolute', ( $index === 0 ? 'dsn-active' : '' ) ],
							'data-dsn-id' => $index,
						] );
						$content .= sprintf( '<div %1$s>%2$s %3$s %4$s %5$s %6$s </div>',
							$widget->get_render_attribute_string( $slid_content ),
							$subtitle,
							$category,
							$title,
							$description,
							$tag_button_start . $button1 . $button2 . $tag_button_end
						);

						/**
						 * End Content
						 */

						echo '</div>';


					endforeach;
					?>

                </div>
            </div>
        </div>

		<?php
		$widget->add_render_attribute( 'dsn-slider-content', [
			'class' => [
				'dsn-slider-content  p-relative h-100 w-100 dsn-container d-flex w-100 h-100 z-index-2 section-padding',
				$shortcode->getVal( 'alignment_item', 'align-items-center' ),
				$shortcode->getVal( 'justify_content_slider', 'justify-content-center' ),

			],
		] );

		printf( '<div %1$s>%2$s</div>', $widget->get_render_attribute_string( 'dsn-slider-content' ), $content )
		?>


    </div>

	<?php if ( $shortcode->getVal( 'show_nav_slider' ) ): ?>
        <div class="next-paginate swiper-container box-shadow p-absolute <?php echo esc_attr( $shortcode->getVal( 'dir_nav_slider', '' ) ) ?>">
            <div class="swiper-wrapper">
				<?php if ( count( $next_slide ) ):
					for ( $x = 1; $x < count( $next_slide ); $x ++ ):
						printf( '<div class="swiper-slide">%s</div>', $next_slide[ $x ] );
					endfor;
					printf( '<div class="swiper-slide">%s</div>', $next_slide[0] );
				endif;
				?>
            </div>
        </div>
	<?php endif; ?>




	<?php

	$justify          = $shortcode->getVal( 'justify_content', 'justify-content-between' );
	$show_progressbar = $shortcode->getVal( 'show_pagination' );


	if ( $show_progressbar || $show_navigation ): ?>
        <div class="control-nav w-100  d-flex dsn-container  align-items-center <?php echo esc_attr( $justify ); ?> ">

			<?php if ( $show_progressbar ): ?>
                <div class="dsn-pagination p-relative w-50">
                    <div class="slider-current-index">01</div>
                    <div class="swiper-pagination-control swiper-pagination-progressbar">
                        <span class="swiper-pagination-progressbar-fill"></span>
                    </div>
                    <div class="slider-total-index"></div>
                </div>


			<?php endif; ?>
			<?php if ( $show_navigation ): ?>
                <div class="dsn-paginate-arrow p-relative d-flex">
                    <div class="prev-container">
                        <div class="container-inner">
                            <div class="triangle"></div>
                            <svg class="circle" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                <g class="circle-wrap" fill="none" stroke-width="1" stroke-linejoin="round"
                                   stroke-miterlimit="10">
                                    <circle cx="12" cy="12" r="10.5"></circle>
                                </g>
                            </svg>
                        </div>
                    </div>
                    <div class="next-container">
                        <div class="container-inner">
                            <div class="triangle"></div>
                            <svg class="circle" xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                 viewBox="0 0 24 24">
                                <g class="circle-wrap" fill="none" stroke-width="1" stroke-linejoin="round"
                                   stroke-miterlimit="10">
                                    <circle cx="12" cy="12" r="10.5"></circle>
                                </g>
                            </svg>
                        </div>
                    </div>
                </div>

			<?php endif; ?>


        </div>

	<?php endif; ?>


</div>
<!-- ========== End Slider Parallax ========== -->
