<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new gridaShortCode( $attr, $items_key );


$items = $shortcode->getVal( 'items', array() );

if ( ! count( $items ) || ! is_array( $items ) ) {
	return;
}

$widget = $shortcode->getWidgetBase();


?>

<ul class="team-socials box-social">
	<?php foreach ( $items as $index => $item ) :

		$shortcode->setSubBlock( $item );

		$title = $shortcode->getItemKey( 'title', $index );
		$title = $shortcode->getSubVal( 'title', 'FB' );
		$widget->add_render_attribute( $title, 'class', 'social-title' );

		$link = $shortcode->getSubVal( 'link' );

		printf( '<li data-dsn="parallax"><a href="%1$s" target="_blank" rel="nofollow" class="init-color">%2$s</a></li>', $link, $title );

	endforeach; ?>

</ul>

