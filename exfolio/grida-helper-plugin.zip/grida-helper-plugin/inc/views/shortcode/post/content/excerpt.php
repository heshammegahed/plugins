<?php

/**
 * @var $shortcode gridaShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

$show_excerpt = $shortcode->getVal( 'show_excerpt' );

if ( ! $show_excerpt ) {
	return;
}


if ( $ex = grida_excerpt( $shortcode->getValueNumberSlide( 'excerpt_length', 25 ) ) ) {
	printf( '<p class="section_description mt-20 max-w570 %1$s">%2$s</p>', $shortcode->getVal( 'border_left' ), $ex );
}