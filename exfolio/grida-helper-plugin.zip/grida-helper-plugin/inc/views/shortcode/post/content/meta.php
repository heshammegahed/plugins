<?php

/**
 * @var $shortcode gridaShortCode
 */
$shortcode = get_query_var( 'attr' );

$meta_data     = $shortcode->getVal( 'meta_data', array() );
$show_date     = in_array( 'date', $meta_data );
$show_category = in_array( 'category', $meta_data );
$position_date = $shortcode->getVal( 'position_date' ) !== 'after';
$position_cat  = $shortcode->getVal( 'position_cat' ) !== 'after';
$separator_between     = $shortcode->getVal( 'separator_between', '||' );


if ( ( !$show_date && !$show_category ) ) return;
if ( !$position_cat && !$position_date ) return;


?>


<div class="post-meta mb-5 max-w750">
	<?php if ( $position_date ) echo grida_shortcode_render( 'post/content/date', $shortcode ); ?>
	<?php if ($show_date&& $show_category && $separator_between && $position_cat && $position_date ) printf( '<span class="mr-5 ml-5 separator-between">%s</span>', $separator_between ) ?>
	<?php if ( $position_cat ) echo grida_shortcode_render( 'post/content/category', $shortcode ); ?>
</div>