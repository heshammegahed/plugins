<?php

/**
 * @var $shortcode gridaShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

if ( !$title = get_the_title() ) return;

$array_ajax     = [ 'data-dsn-ajax' => 'work' ];
$title_with_box = $shortcode->getVal( 'title_with_box' );


$widget->add_render_attribute( 'title_link', [
	'href'  => esc_url( get_the_permalink() ),
	'class' => 'effect-ajax init-color'
],                             null, true );
$widget->add_render_attribute( 'title_link', $array_ajax, null, true );


if ( $title_with_box ) {
	$widget->add_render_attribute( 'title', [
		'class'    => [
			'has-box-mod p-relative move-circle',
			'post-title word-wrap',
			$shortcode->getVal( 'font_size', 'title-block' )
		],
		'data-dsn' => 'parallax',
		'style'    => '--mod-color: ' . grida_get_option_pages( 'style_box', '#FFFFFF' ) . '; '
	],                             null, true );
} else {
	$widget->add_render_attribute( 'title', [
		'class' => [
			'post-title word-wrap',
			$shortcode->getVal( 'font_size', 'title-block' )
		],
	],                             null, true );
}


printf( '<%1$s %2$s><a %3$s>%4$s</a></%1$s>', $shortcode->getHtmlTag(), $widget->get_render_attribute_string( 'title' ), $widget->get_render_attribute_string( 'title_link' ), $title );
