<?php

/**
 * @var $attr gridaShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

$meta_data             = $shortcode->getVal( 'meta_data', array() );
$show_date             = in_array( 'date', $meta_data );
$show_category         = in_array( 'category', $meta_data );


if ( !$show_date )
    return ;

?>

    <div class="entry-date d-inline-block entry-meta">
        <a class="effect-ajax init-color heading-color"
           href="<?php echo DesignGrid\gridaOption::dateLink(); ?>"
           title="<?php the_time( 'F d, Y' ) ?>">
             <?php echo esc_html( get_the_date() ) ?>
        </a>
    </div>


