<?php

/**
 * @var $attr gridaShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

$meta_data             = $shortcode->getVal( 'meta_data', array() );
$show_category         = in_array( 'category', $meta_data );
$separator_between_cat = $shortcode->getVal( 'separator_between_cat', ', ' );


if ( !$show_category ) {
	return;
}

?>

<div class="p-relative d-inline-block dsn-category metas entry-meta">
	<?php echo \DesignGrid\gridaOption::PostCategory( '', false, true, false, '<span data-separator="' . esc_attr( $separator_between_cat ) . '">', '</span>' ) ?>
</div>