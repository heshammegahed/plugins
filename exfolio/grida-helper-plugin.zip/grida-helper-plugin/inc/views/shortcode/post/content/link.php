<?php

/**
 * @var $shortcode gridaShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();


$show_link = $shortcode->getVal( 'show_link', '1' );
$text_link = $shortcode->getVal( 'text_link', esc_html__( "Read More", 'grida' ) );


if ( !$show_link ) {
	return;
}


$widget->add_render_attribute( "link", [
	'href'          => esc_url( get_the_permalink() ),
	'class'         => [ 'effect-ajax dsn-post-link' ],
	'data-dsn-ajax' => 'work',
],                             null, true );

printf( '<a %1$s>%2$s</a>',
        $widget->get_render_attribute_string( "link" ),
        $text_link
);
