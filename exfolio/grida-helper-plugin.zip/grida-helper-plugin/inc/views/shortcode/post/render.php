<?php
$attr    = get_query_var( 'attr' );
$myposts = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );
$shortcode->setSubBlock( [ 'id_post' => get_the_ID() ] );


$widget = $shortcode->getWidgetBase();


$swiper_item = $shortcode->get_render_swiper_slide_attribute();

$shortcode->add_parallax_attributes( 'dsn-item-content', 'box' );
$widget->add_render_attribute( 'dsn-item-content', 'class', 'box-content d-flex ' );
$shortcode->add_parallax_attributes( 'dsn-post-content', 'content' );

$widget->add_render_attribute( 'dsn-post-content', 'class', 'post-content p-relative z-index-1' );

$shortcode->add_parallax_attributes( 'slide-image', 'image' );


if ( $myposts->have_posts() ) :
	while ( $myposts->have_posts() ) :
		$myposts->the_post();


		$widget->add_render_attribute( 'dsn-item-post', 'class', [
			'dsn-item-post  grid-item over-hidden p-relative box-hover-image',
			'post-' . get_the_ID(),
			$shortcode->getVal( 'show_link', '1' ) ? 'dsn-show-link' : '',
			DesignGrid\gridaOption::PostCategorySlug(),
			$shortcode->getVal( 'bg_ver_btn', '' ),
			$shortcode->getVal( 'bg_btn', 'background-main' )
		], true );


		$widget->add_render_attribute( 'dsn-item-post', $swiper_item );


		?>

        <article <?php $widget->print_render_attribute_string( 'dsn-item-post' ) ?> >

            <div <?php $widget->print_render_attribute_string( 'dsn-item-content' ) ?>>

				<?php echo grida_shortcode_render( 'post/content/image', $shortcode ); ?>

                <div <?php $widget->print_render_attribute_string( 'dsn-post-content' ) ?>>

                    <div class="post-title-info">
						<?php echo grida_shortcode_render( 'post/content/meta', $shortcode ); ?>
						<?php echo grida_shortcode_render( 'post/content/title', $shortcode ); ?>
						<?php if ( $shortcode->getVal( 'position_date' ) === 'after' ) {
							echo grida_shortcode_render( 'post/content/date', $shortcode );
						} ?>
                    </div>
                    <div class="post-description-info">
						<?php echo grida_shortcode_render( 'post/content/excerpt', $shortcode ); ?>
						<?php if ( $shortcode->getVal( 'position_cat' ) === 'after' ) {
							echo grida_shortcode_render( 'post/content/category', $shortcode );
						} ?>
						<?php echo grida_shortcode_render( 'post/content/link', $shortcode ); ?>
                    </div>


                </div>
            </div>


        </article>

	<?php endwhile;
endif;
wp_reset_postdata();
?>

