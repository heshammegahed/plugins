<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new gridaShortCode( $attr );


$widget = $shortcode->getWidgetBase();

$items = $shortcode->getVal( 'items', array() );


if ( ! count( $items ) ) {
	return;
}

$size     = $shortcode->getSize('p');
$html_tag = $shortcode->getHtmlTag();

$list_with_number = $shortcode->getVal( 'list_with_number' );
$widget->add_render_attribute( 'list', 'class', 'dsn-list' );


$widget->add_render_attribute( 'list-item', 'class', 'list-item d-flex align-items-center' );

foreach ( $items as $index => $item ):
	$shortcode->setSubBlock( $item );
	$ren_text = $shortcode->getItemKey( 'text', $index );
	$text     = $shortcode->getSubVal( 'text' );

	$isIcon = ! empty( $shortcode->getSubVal( 'icon', array( 'library' => '' ) )['library'] );
	?>
    <li <?php $widget->print_render_attribute_string( 'list-item' ) ?> >
		<?php if ( $isIcon && ! $list_with_number ) : ?>
            <span class="dsn-icon mr-15"><?php $shortcode->printIcon( $shortcode->getSubVal( 'icon' ) ) ?></span>
		<?php elseif ( $list_with_number ) : printf( '<span class="number">%s</span>', $index + 1 ); endif;

		if ( $text ) {
			printf( '<%1$s class="%2$s">%3$s</%1$s>', $html_tag, $size, $text );
		} ?>


    </li>


<?php endforeach; ?>