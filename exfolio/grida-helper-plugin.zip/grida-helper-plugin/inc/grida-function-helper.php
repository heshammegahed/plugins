<?php

/**
 *
 *  ============================
 *        Custom Slug Project
 *  ============================
 *
 *  - Retrieves an option value based on an Slug Work name.
 *
 */

/**
 *
 * Enqueue scripts for all admin pages.
 *  Custom CSS , JS For Admin
 */


add_action( 'admin_enqueue_scripts', function ( $hook ) {
	wp_enqueue_style( 'grida-admin-style', GRIDA__PLUGIN_DIR_URL . '/assets/css/style.css' );
}, 20 );


if ( ! function_exists( 'grida_custom_project_slug' ) ) :

	function grida_custom_project_slug() {
		return get_theme_mod( 'grida-project-slug', grida_project_slug() );
	}

endif;

if ( ! function_exists( 'grida_custom_story_slug' ) ) :

	function grida_custom_story_slug() {
		return get_theme_mod( 'grida-story-slug', grida_story_slug() );
	}

endif;


if ( ! function_exists( 'grida_shortcode_render' ) ) :

	function grida_shortcode_render( $target, $att, $content = null, $is_render = true ) {
		return grida_view( 'shortcode/' . $target, array( 'attr' => $att, 'content' => $content ), $is_render );
	}

endif;

if ( ! function_exists( 'grida_shortcode_render_group' ) ) :

	function grida_shortcode_render_group( $target, $att, $content = null, $is_render = true ) {
		return grida_view( 'shortcode/' . $target . '/render', array(
			'attr'    => $att,
			'content' => $content,
		), $is_render );
	}

endif;

if ( ! function_exists( 'grida_shortcode_js_group' ) ) :

	function grida_shortcode_js_group( $target, $att = array(), $content = null, $is_render = true ) {
		return grida_view( 'shortcode/' . $target . '/js', array(
			'attr'    => $att,
			'content' => $content
		), $is_render );
	}

endif;


if ( ! function_exists( 'grida_get_template_render' ) ) :

	function grida_get_template_render( $slug, array $param = array(), $is_render = true ) {

		if ( ! file_exists( plugin_dir_path( __FILE__ ) . '/' . $slug . '.php' ) ) {
			return "";
		}

		if ( count( $param ) ):
			foreach ( $param as $key => $value ):
				set_query_var( $key, $value );
			endforeach;
		endif;

		if ( $is_render ):
			ob_start();
		endif;
		extract( $param );
		include plugin_dir_path( __FILE__ ) . '/' . $slug . '.php';
		if ( $is_render ):
			return ob_get_clean();
		endif;

	}

endif;
if ( ! function_exists( 'grida_resources' ) ) :

	function grida_resources( $slug, array $param = array(), $is_render = false ) {

		grida_get_template_render( 'resources/' . $slug, $param, $is_render );
	}

endif;

if ( ! function_exists( 'grida_resources_block' ) ) :

	function grida_resources_block( $slug, array $param = array(), $is_render = false ) {

		grida_get_template_render( 'resources/views/pages/options/blocks/' . $slug, $param, $is_render );
	}

endif;

if ( ! function_exists( 'grida_templete_part' ) ) :

	function grida_templete_part( $slug, array $param = array(), $is_render = false ) {

		return grida_get_template_render( 'views/template-parts/' . $slug, $param, $is_render );
	}

endif;

if ( ! function_exists( 'grida_view' ) ) :

	function grida_view( $slug, array $param = array(), $is_render = true ) {

		return grida_get_template_render( 'views/' . $slug, $param, $is_render );
	}

endif;

if ( ! function_exists( 'grida_resources_customize' ) ) :

	function grida_resources_customize( $slug, array $param = array(), $is_render = false ) {

		grida_get_template_render( 'resources/views/pages/customizer/block/' . $slug, $param, $is_render );
	}

endif;
/**
 *
 * you can fill in defaults when needed.
 *
 * @param array $pairs The list of supported attributes and their defaults.
 * @param array $att User defined attributes .
 *
 * @return array .
 */
if ( ! function_exists( 'grida_set_attr' ) ) :

	function grida_set_attr( array $pairs, array $att ) {

		foreach ( $att as $key => $value ) {

			if ( ! array_key_exists( $key, $pairs ) ) {

				$pairs[ $key ] = $value;

			}

		}

		return $pairs;
	}

endif;

/**
 *
 * you can fill in defaults when needed.
 *
 * @param array $pairs The list of supported attributes and their defaults.
 * @param array $att User defined attributes .
 *
 * @return string .
 */
if ( ! function_exists( 'grida_get_attr' ) ) :

	function grida_get_attr( $att ) {

		$out = '';

		if ( empty( $att ) ) {

			return $out;

		} elseif ( ! is_array( $att ) ) {

			return $att;

		} elseif ( count( $att ) ) {

			foreach ( $att as $key => $value ) {
				$out .= $key . '="' . $value . '" ';
			}

		}

		return $out;
	}

endif;


/**
 * @return string  - Share Blog in Social media
 */
if ( ! function_exists( 'grida_share_links' ) ) :

	function grida_share_links( $befor = '', $after = '' ) {

		$share_link = get_theme_mod( 'share_link' );
		if ( ! $share_link ) {
			return '';
		}

		$share_links = get_theme_mod( 'show_hide_share_link', array(
			'facebook',
			'twitter',
			'google-plus',
			'pinterest',
		) );

		$url = get_the_permalink();

		$share_buttons = array(
			'facebook'    => grida_set_share_links( esc_html__( 'Facebook', 'grida' ), array( 'href' => 'https://www.facebook.com/sharer/sharer.php?u=' . esc_url( $url ) ) ),
			'twitter'     => grida_set_share_links( esc_html__( 'Twitter', 'grida' ), array( 'href' => 'https://twitter.com/share?url=' . esc_url( $url ) ) ),
			'google-plus' => grida_set_share_links( esc_html__( 'Google+', 'grida' ), array( 'href' => 'https://plus.google.com/share?url=' . esc_url( $url ) ) ),
			'pinterest'   => grida_set_share_links( esc_html__( 'Pinterest', 'grida' ), array( 'href' => 'https://www.pinterest.com/pin/create/button/?url=' . esc_url( $url ) ) ),
			'get-pocket'  => grida_set_share_links( esc_html__( 'Get Pocket', 'grida' ), array( 'href' => 'https://getpocket.com/save?url=' . esc_url( $url ) ) ),
			'telegram'    => grida_set_share_links( esc_html__( 'Telegram', 'grida' ), array( 'href' => 'https://t.me/share/url?url=' . esc_url( $url ) ) ),
		);
		$out           = '';
		foreach ( $share_links as $link ):
			$out .= $befor . $share_buttons[ $link ] . $after;
		endforeach;


		return $out;
	}

endif;

if ( ! function_exists( 'grida_set_share_links' ) ) :

	function grida_set_share_links( $content, $att = array() ) {

		$att = grida_set_attr( $att, array(
			'rel'     => 'nofollow',
			'href'    => '',
			'onclick' => 'window.open(\'' . $att['href'] . '\' , \'share-dialog\', \'width=626,height=436\'); return false;',
		) );

		$att = grida_get_attr( $att );


		return '<a ' . $att . ' >' . $content . '</a>';
	}

endif;


/**
 * Get attachment image HTML.
 *
 * Retrieve the attachment image HTML code.
 *
 * Note that some widgets use the same key for the media control that allows
 * the image selection and for the image size control that allows the user
 * to select the image size, in this case the third parameter should be null
 * or the same as the second parameter. But when the widget uses different
 * keys for the media control and the image size control, when calling this
 * method you should pass the keys.
 *
 * @param array $settings Control settings.
 * @param string $image_size_key Optional. Settings key for image size.
 *                               Default is `image`.
 * @param string $image_key Optional. Settings key for image. Default
 *                               is null. If not defined uses image size key
 *                               as the image key.
 *
 * @return string Image HTML.
 * @since 1.0.0
 * @access public
 * @static
 *
 */


if ( ! function_exists( 'grida_attachment_image_html' ) ) :

	function grida_attachment_image_html( $settings, $image_size_key = 'image', $image_key = null, $class = '' ) {

		if ( ! class_exists( 'Elementor\Control_Media' ) ) {
			return '';
		}
		if ( ! class_exists( 'Elementor\Group_Control_Image_Size' ) ) {
			return '';
		}
		if ( ! function_exists( 'get_intermediate_image_sizes' ) ) {
			return '';
		}

		if ( ! $image_key ) {
			$image_key = $image_size_key;
		}

		$image = $settings[ $image_key ];

		// Old version of image settings.
		if ( ! isset( $settings[ $image_size_key . '_size' ] ) ) {
			$settings[ $image_size_key . '_size' ] = '';
		}

		$size = $settings[ $image_size_key . '_size' ];

		$image_class = ! empty( $settings['hover_animation'] ) ? 'elementor-animation-' . $settings['hover_animation'] : '';

		$html = '';

		// If is the new version - with image size.
		$image_sizes = get_intermediate_image_sizes();

		$image_sizes[] = 'full';

		if ( ! empty( $image['id'] ) && ! wp_attachment_is_image( $image['id'] ) ) {
			$image['id'] = '';
		}

		if ( ! empty( $image['id'] ) && in_array( $size, $image_sizes ) ) {
			$image_class .= " attachment-$size size-$size " . grida_get_option_array( $settings, 'animate_image_style', 'has-top-bottom' );
			$image_attr  = [
				'class'             => trim( $image_class ) . ' ' . trim( $class ),
				'data-dsn-position' => esc_attr( grida_position_image_settings( $settings ) ),

			];

			$html .= wp_get_attachment_image( $image['id'], $size, false, $image_attr );
		}

//        else {
//
//            $image_src = \Elementor\Group_Control_Image_Size::get_attachment_image_src( $image[ 'id' ], $image_size_key, $settings );
//
//            if ( !$image_src && isset( $image[ 'url' ] ) ) {
//                $image_src = $image[ 'url' ];
//            }
//
//            if ( !empty( $image_src ) ) {
//                $image_class_html = !empty( $image_class ) ? ' class="' . $image_class . '"' : '';
//
//                $html .= sprintf( '<img src="%s" title="%s" alt="%s"%s />', esc_attr( $image_src ), \Elementor\Control_Media::get_image_title( $image ), \Elementor\Control_Media::get_image_alt( $image ), $image_class_html );
//            }
//        }

		/**
		 * Get Attachment Image HTML
		 *
		 * Filters the Attachment Image HTML
		 *
		 * @param string $html the attachment image HTML string
		 * @param array $settings Control settings.
		 * @param string $image_size_key Optional. Settings key for image size.
		 *                               Default is `image`.
		 * @param string $image_key Optional. Settings key for image. Default
		 *                               is null. If not defined uses image size key
		 *                               as the image key.
		 *
		 * @since 2.4.0
		 */
		return apply_filters( 'elementor/image_size/get_attachment_image_html', $html, $settings, $image_size_key, $image_key );
	}
endif;

/**
 * Get the caption for current widget.
 *
 * @access private
 *
 * @param $settings
 *
 * @return string
 * @since 2.3.0
 */
if ( ! function_exists( 'grida_get_caption' ) ) :

	function grida_get_caption( $settings ) {
		if ( ! isset( $settings['image'] ) ) {
			return '';
		}

		$caption = '';
		if ( ! class_exists( 'Elementor\Utils' ) ) {
			return $caption;
		}
		if ( ! empty( $settings['caption_source'] ) ) {
			switch ( $settings['caption_source'] ) {
				case 'attachment':
					$caption = wp_get_attachment_caption( $settings['image']['id'] );
					break;
				case 'custom':
					$caption = ! \Elementor\Utils::is_empty( $settings['caption'] ) ? $settings['caption'] : '';
			}
		}

		return $caption;
	}
endif;


if ( ! function_exists( 'grida_get_space' ) ) :

	function grida_get_space( $settings ) {
		$out = '';
		if ( grida_get_option_array( $settings, 'use_space_top' ) ) {
			$out .= 'mt-30';
		}
		if ( grida_get_option_array( $settings, 'use_space_bottom' ) ) {
			$out .= ' mb-30';
		}

		return $out;
	}
endif;

if ( ! function_exists( 'grida_parse_text_editor' ) ) :

	function grida_parse_text_editor( $content, $settings ) {
		/** This filter is documented in wp-includes/widgets/class-wp-widget-text.php */
		$content = apply_filters( 'widget_text', $content, $settings );

		$content = shortcode_unautop( $content );
		$content = do_shortcode( $content );
		$content = wptexturize( $content );

		if ( $GLOBALS['wp_embed'] instanceof \WP_Embed ) {
			$content = $GLOBALS['wp_embed']->autoembed( $content );
		}

		return $content;
	}
endif;

if ( ! function_exists( 'grida_excerpt' ) ) :

	function grida_excerpt( $limit, $post = null, $content = null ) {
		if ( $content != null ) {
			$excerpt = explode( ' ', $content, $limit );
		} else {
			$excerpt = explode( ' ', get_the_excerpt( $post ), $limit );
		}

		if ( count( $excerpt ) >= $limit ) {
			array_pop( $excerpt );
			$excerpt = implode( " ", $excerpt );
		} else {
			$excerpt = implode( " ", $excerpt );
		}

		$excerpt = preg_replace( '`\[[^\]]*\]`', '', $excerpt );

		return $excerpt;
	}
endif;


if ( ! function_exists( 'grida_custom_category_slug' ) ) :

	function grida_custom_category_slug() {
		$cat = get_theme_mod( 'grida-category-slug', grida_category_slug() );
		if ( $cat === 'category' ) {
			return 'categories';
		} else {
			return get_theme_mod( 'grida-category-slug', grida_category_slug() );
		}
	}

endif;

if ( ! function_exists( 'grida_custom_category_story_slug' ) ) :

	function grida_custom_category_story_slug() {
		$cat = get_theme_mod( 'grida-category_story-slug', grida_category_story_slug() );
		if ( $cat === 'category' ) {
			return 'categories';
		} else {
			return $cat;
		}
	}

endif;

if ( ! function_exists( 'grida_default_social' ) ) :

	function grida_default_social() {
		return [
			[
				'name'           => esc_html__( 'Facebook.', 'grida' ),
				'init_name'      => esc_html__( 'Fb', 'grida' ),
				'icon'           => 'fab fa-facebook-f',
				'link'           => esc_html__( '#0', 'grida' ),
				'show_in_header' => 1,
				'show_in_footer' => 1,
			],
			[
				'name'           => esc_html__( 'Instagram.', 'grida' ),
				'init_name'      => esc_html__( 'Instagram', 'grida' ),
				'icon'           => 'fab fa-instagram',
				'link'           => esc_html__( '#0', 'grida' ),
				'show_in_header' => 1,
				'show_in_footer' => 1,
			],
			[
				'name'           => esc_html__( 'Twitter.', 'grida' ),
				'init_name'      => esc_html__( 'Tw', 'grida' ),
				'icon'           => 'fab fa-twitter',
				'link'           => esc_html__( '#0', 'grida' ),
				'show_in_header' => 1,
				'show_in_footer' => 1,
			],
			[
				'name'           => esc_html__( 'Linkedin.', 'grida' ),
				'init_name'      => esc_html__( 'Linkedin', 'grida' ),
				'icon'           => 'fab fa-linkedin-in',
				'link'           => esc_html__( '#0', 'grida' ),
				'show_in_header' => 1,
				'show_in_footer' => 1,
			],

		];
	}

endif;


if ( ! function_exists( 'grida_default_info_header' ) ) :

	function grida_default_info_header() {
		return array(
			array( 'title' => 'Service', 'content' => 'grida' ),
			array( 'title' => 'Industry', 'content' => 'dsnGrid' ),
			array( 'title' => 'Year', 'content' => 'May 27th 2020' )
		);
	}

endif;


if ( ! function_exists( 'grida_get_filter_categories' ) ) :

	/**
	 * @return array
	 */
	function grida_get_filter_categories( WP_Query $myposts, $category = 'category' ) {
		$terms = array();
		foreach ( $myposts->posts as $mypost ):
			if ( $categories = get_the_terms( $mypost->ID, $category ) ) {
				foreach ( $categories as $cat ):
					$terms[ $cat->slug ] = $cat->name;
				endforeach;
			}
		endforeach;

		return $terms;
	}

endif;

add_action( 'grida_social', function ( $args ) {
	echo grida_shortcode_render( 'widget/social-' . $args['type'], $args );
} );