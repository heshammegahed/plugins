<?php

/**
 * Plugin Name: Grida Functionality Plugins
 * Plugin URI: https://themeforest.net/user/design_grid
 * Description: Core Plugin for Grida WordPress Theme
 * Version: 1.0.1
 * Author URI: https://themeforest.net/user/design_grid
 * Text Domain: grida
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

define( 'GRIDA__PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'GRIDA__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'GRIDA__PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'GRIDA_BLOCK_BOXES', 'dsn-block-boxes' );


class GridaHelperPlugin {


	public function __construct() {


		$this->include_helper_files();

	}

	public function include_files( $files, $suffix = '' ) {
		foreach ( $files as $file ) {
			$filepath = GRIDA__PLUGIN_DIR . $suffix . $file . '.php';
			if ( ! file_exists( $filepath ) ) :
				trigger_error( sprintf( esc_html__( 'Error locating %s for inclusion', 'grida' ), $file ), E_USER_ERROR );
			endif;
			require_once $filepath;
		}
		unset( $file, $filepath );
	}


	public function include_helper_files() {
		$files = array(
			'grida-function-helper',

			'GridaAdminPost',
			'views/shortcode/gridaShortCode',
//			'eremia-required-plugins',
			'GridaSession',
			'GridaStyle',

			'resources/views/pages/options/widgets/control/GridaRenderSectionElement',
			'resources/views/pages/options/widgets/control/GridaRegisterElement',
			'resources/views/pages/options/widgets/control/Grida_Widget_Base',
			'resources/views/pages/options/widgets/control/GridaSwiper',
//			'eremia-function-widget',


		);
		$this->include_files( $files, 'inc/' );

	}


}


function gridaDev() {
	return new GridaHelperPlugin();
}

add_action( 'grida_developer', function ( $array = array() ) {
	gridaDev();

	foreach ( $array as $value ):
		grida_resources( $value );
	endforeach;
} );