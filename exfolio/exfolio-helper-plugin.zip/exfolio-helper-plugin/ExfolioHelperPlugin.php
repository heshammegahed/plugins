<?php

/**
 * Plugin Name: Exfolio Functionality Plugins
 * Plugin URI: https://themeforest.net/user/design_grid
 * Description: Core Plugin for Exfolio WordPress Theme
 * Version: 1.2.6
 * Author URI: https://themeforest.net/user/design_grid
 * Text Domain: exfolio
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

define( 'EXFOLIO__PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'EXFOLIO__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'EXFOLIO__PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'EXFOLIO_MODULES_PATH', plugin_dir_url( __FILE__ ) . '/modules' );


global $exfolioPostMetas;

class ExfolioHelperPlugin {


	public function __construct() {

		$this->include_helper_files();

	}

	public function include_files( $files, $suffix = '' ) {
		foreach ( $files as $file ) {
			$filepath = EXFOLIO__PLUGIN_DIR . $suffix . $file . '.php';
			if ( ! file_exists( $filepath ) ) :
				trigger_error( sprintf( esc_html__( 'Error locating %s for inclusion', 'exfolio' ), $file ),
					E_USER_ERROR );
			endif;
			require_once $filepath;
		}
		unset( $file, $filepath );
	}

	public function include_helper_files() {

		$files = array(
			'ExfolioGlobalSetting',

			'function-filter',
			'swiper-helper',
			'function-helper',
			'exfolioFrontEnd',
			'exfolioBootstrapTemplate',
			'function-widget',
			'ExfolioAdminPost',
			'views/shortcode/exfolioShortCode',
			'exfolioStyle',


			'resources/views/pages/options/inc/notices',
			'resources/views/pages/options/widgets/control/ExfolioRenderSectionElement',
			'resources/views/pages/options/widgets/control/ExfolioRegisterElement',
			'resources/views/pages/options/widgets/control/Exfolio_Widget_Base',
			'resources/views/pages/options/widgets/control/ExfolioSwiper',


		);
		$this->include_files( $files, 'inc/' );


	}


}


function exfolioDev(): ExfolioHelperPlugin {

	if ( defined( 'EXFOLIO_DIRECTORY' ) && file_exists( EXFOLIO_DIRECTORY . '/inc/classes/exfolioTemplate.php' ) ) {
		require_once EXFOLIO_DIRECTORY . '/inc/classes/ExfolioTemplate.php';
	}


	return new ExfolioHelperPlugin();
}

add_action( 'exfolio_developer', function ( $array = array() ) {

	exfolioDev();

	foreach ( $array as $value ):
		exfolio_resources( $value );
	endforeach;
} );
