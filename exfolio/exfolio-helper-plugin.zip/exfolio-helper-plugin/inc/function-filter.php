<?php


add_filter('upload_mimes', function ($mimes) {
	$mimes['svg'] = 'image/svg+xml';
	$mimes['webp'] = 'image/webp'; // webp files
	return $mimes;
});


add_filter('wp_prepare_attachment_for_js', function ($response) {
	if ($response['mime'] === 'image/svg+xml') {
		$response['sizes'] = [
			'thumbnail' => [
				'url' => $response['url'],
				'width' => $response['width'],
				'height' => $response['height'],
			],
		];
	}
	return $response;
}, 10, 3);