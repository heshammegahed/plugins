<?php

if ( ! function_exists( 'exfolio_effect_coverflow' ) ) :

	function exfolio_effect_coverflow() {
		return [
			'name'  => 'effect_coverflow',
			'items' => [
				'depth'        => [
					'label'       => esc_html__( 'Depth', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 1,
					'step'        => 5,
					'default'     => 100,
					'description' => esc_html__( 'Depth offset in px (slides translate in Z axis)', 'exfolio' )
				],
				'modifier'     => [
					'label'       => esc_html__( 'Modifier', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 1,
					'step'        => 1,
					'default'     => 1,
					'description' => esc_html__( 'Effect multiplier', 'exfolio' )
				],
				'rotate'       => [
					'label'       => esc_html__( 'Rotate', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 0,
					'step'        => 5,
					'default'     => 0,
					'description' => esc_html__( 'Slide rotate in degrees', 'exfolio' )
				],
				'scale'        => [
					'label'       => esc_html__( 'Scale', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 0,
					'step'        => 0.1,
					'default'     => 1,
					'description' => esc_html__( 'Slide scale effect', 'exfolio' )
				],
				'slideShadows' => [
					'label'        => esc_html__( 'Slide Shadows', 'exfolio' ),
					'description'  => esc_html__( 'Enables slides shadows', 'exfolio' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'exfolio' ),
					'label_off'    => esc_html__( 'Hide', 'exfolio' ),
					'return_value' => '1',
					'default'      => '1',
				],
				'stretch'      => [
					'label'       => esc_html__( 'Stretch', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 0,
					'step'        => 1,
					'default'     => 0,
					'description' => esc_html__( 'Stretch space between slides (in px)', 'exfolio' )
				],

			]

		];
	}

endif;

if ( ! function_exists( 'exfolio_effect_cards' ) ) :

	function exfolio_effect_cards() {
		return [
			'name'  => 'cardsEffect',
			'items' => [
				'perSlideOffset' => [
					'label'       => esc_html__( 'perSlide Offset', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 1,
					'step'        => 1,
					'default'     => 8,
					'description' => esc_html__( 'Offset distance per slide (in px)', 'exfolio' )
				],
				'perSlideRotate' => [
					'label'       => esc_html__( 'perSlide Rotate', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 1,
					'step'        => 1,
					'default'     => 2,
					'description' => esc_html__( 'Rotate angle per slide (in degrees)', 'exfolio' )
				],
				'slideShadows'   => [
					'label'        => esc_html__( 'Slide Shadows', 'exfolio' ),
					'description'  => esc_html__( 'Enables slides shadows', 'exfolio' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'exfolio' ),
					'label_off'    => esc_html__( 'Hide', 'exfolio' ),
					'return_value' => '1',
					'default'      => '1',
				],
				'rotate'         => [
					'label'        => esc_html__( 'Rotate', 'exfolio' ),
					'description'  => esc_html__( 'Enables cards rotation', 'exfolio' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'exfolio' ),
					'label_off'    => esc_html__( 'Hide', 'exfolio' ),
					'return_value' => '1',
					'default'      => '1',
				],


			]

		];
	}

endif;


if ( ! function_exists( 'exfolio_effect_creative' ) ) :

	function exfolio_effect_creative() {
		return [
			'name'  => 'creativeEffect',
			'items' => [
				'limitProgress' => [
					'label'       => esc_html__( 'Limit Progress', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 0,
					'step'        => 1,
					'default'     => 8,
					'description' => esc_html__( 'Limit progress/offset to amount of side slides. If 1, then slides all slides after prev/next will have same state. If 2, then all slides after 2nd before/after active will have same state, etc.', 'exfolio' )
				],

				'perspective'        => [
					'label'        => esc_html__( 'perspective', 'exfolio' ),
					'description'  => esc_html__( 'Enables slides shadows', 'exfolio' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'exfolio' ),
					'label_off'    => esc_html__( 'Hide', 'exfolio' ),
					'return_value' => '1',
					'default'      => '1',
				],
				'progressMultiplier' => [
					'label'       => esc_html__( 'Progress Multiplier', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 0,
					'step'        => 1,
					'default'     => 1,
					'description' => esc_html__( 'Allows to multiply slides transformations and opacity.', 'exfolio' )
				],

				'shadowPerProgress' => [
					'label'        => esc_html__( 'Shadow PerProgress', 'exfolio' ),
					'description'  => esc_html__( 'Splits shadow "opacity" per slide based on limitProgress (only if transformation shadows enabled). E.g. setting limitProgress: 2 and enabling shadowPerProgress, will set shadow opacity to 0.5 and 1 on two slides next to active. With this parameter disabled, all slides beside active will have shadow with 1 opacity', 'exfolio' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'exfolio' ),
					'label_off'    => esc_html__( 'Hide', 'exfolio' ),
					'return_value' => '1',
				],


			],
			'np'    => [
				'translate' => [
					'label'       => esc_html__( 'Translate', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::TEXTAREA,
					'default'     => "[-500, 50, -200]",
					'label_block' => true,
					'rows' => 2,
					'description' => esc_html__( 'Array with translate X, Y and Z values', 'exfolio' )
				],
				'rotate'    => [
					'label'       => esc_html__( 'Rotate', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 2,

					'default'     => "[-7, -7, -7]",
					'label_block' => true,
					'description' => esc_html__( 'Array with rotate  X, Y and Z values', 'exfolio' )
				],
				'opacity'   => [
					'label'       => esc_html__( 'Opacity', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 0,
					'step'        => 0.1,
					'max'         => 1,
					'default'     => 1,
					'description' => esc_html__( 'Slide opacity 0 - 1', 'exfolio' )
				],
				'scale'     => [
					'label'       => esc_html__( 'Scale', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::NUMBER,
					'min'         => 0,
					'step'        => 0.1,
					'default'     => 1,
					'description' => esc_html__( 'Slide scale', 'exfolio' )
				],
				'shadow'    => [
					'label'        => esc_html__( 'Shadows', 'exfolio' ),
					'description'  => esc_html__( 'Enables slides shadows', 'exfolio' ),
					'type'         => \Elementor\Controls_Manager::SWITCHER,
					'label_on'     => esc_html__( 'Show', 'exfolio' ),
					'label_off'    => esc_html__( 'Hide', 'exfolio' ),
					'return_value' => '1',
				],
				'origin'    => [
					'label'       => esc_html__( 'Origin', 'exfolio' ),
					'type'        => \Elementor\Controls_Manager::TEXT,
					'label_block' => true,
					'description' => esc_html__( 'Transform origin, e.g. `left bottom`', 'exfolio' )
				],
			]

		];
	}

endif;