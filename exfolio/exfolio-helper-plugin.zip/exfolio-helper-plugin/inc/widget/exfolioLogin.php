<?php


/**
 *
 *
 *
 *
 * Class follow_me_widget
 *
 *
 *
 */



class exfolioLogin extends WP_Widget {

	private $exfolio_title;

	/**
	 * profile_widget constructor.
	 */
	public function __construct() {
		$this->exfolio_title = esc_html__( 'exfolio Login', 'exfolio' );


		$widget_ops = array(
			'classname'                   => 'widget_exfolio_login exfolio-login',
			'description'                 => esc_html__( 'Custom Login Ajax.', 'exfolio' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'exfolio_exfolio_login', esc_html__( 'exfolio exfolio Login', 'exfolio' ), $widget_ops );

	}


	/**
	 *
	 * ========================================
	 *      front-end display of widget
	 * ========================================
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {

		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}


		echo exfolio_view( 'widget/login/login-widget', array(
			'args'        => $args,
			'instance'    => $instance,
			'exfolio_title' => $this->exfolio_title
		) );
	}


	private function exfolio_login_view( $exfolioLogin, $instance, $name, $label, $default = '' ) {
		return sprintf( '<p><label for="%1$s">%2$s</label><input type="text" class="widefat" id="%1$s" name="%3$s" value="%4$s"/></p>',
			$this->get_field_id( $name ),
			$label,
			$this->get_field_name( $name ),
			isset( $instance[ $name ] ) ? $instance[ $name ] : $default
		);
	}

	private function exfolio_login_view_text( $exfolioLogin, $instance, $name, $label, $default = '' ) {
		return sprintf( '<p><label for="%1$s">%2$s</label><textarea type="text" class="widefat" id="%1$s" name="%3$s">%4$s</textarea></p>',
			$this->get_field_id( $name ),
			$label,
			$this->get_field_name( $name ),
			isset( $instance[ $name ] ) ? $instance[ $name ] : $default
		);
	}


	/**
	 *
	 * ========================================
	 *      back-end display of widget
	 * ========================================
	 *
	 * @param array $instance
	 *
	 * @return string
	 */
	public function form( $instance ) {

		$id   = $this->get_field_id( 'title' );
		$name = $this->get_field_name( 'title' );
		$out  = [];

		$out[] = $this->exfolio_login_view( $this, $instance, 'username', esc_html__( 'Username', 'exfolio' ), esc_html__( 'Username or Email Address', 'exfolio' ) );
		$out[] = $this->exfolio_login_view( $this, $instance, 'password', esc_html__( 'Password', 'exfolio' ), esc_html__( 'Password', 'exfolio' ) );
		$out[] = $this->exfolio_login_view( $this, $instance, 'remember', esc_html__( 'Remember', 'exfolio' ), esc_html__( 'Remember Me', 'exfolio' ) );
		$out[] = $this->exfolio_login_view( $this, $instance, 'login', esc_html__( 'Login', 'exfolio' ), esc_html__( 'Login', 'exfolio' ) );
		$out[] = $this->exfolio_login_view( $this, $instance, 'forget_password', esc_html__( 'Forget Password', 'exfolio' ), esc_html__( 'Forget Password', 'exfolio' ) );
		$out[] = $this->exfolio_login_view( $this, $instance, 'register', esc_html__( 'Register', 'exfolio' ), esc_html__( 'Register', 'exfolio' ) );
		$out[] = $this->exfolio_login_view_text( $this, $instance, 'wrong', esc_html__( 'Wrong Message', 'exfolio' ), esc_html__( 'Wrong username or password', 'exfolio' ) );
		$out[] = $this->exfolio_login_view_text( $this, $instance, 'success', esc_html__( 'Success Message', 'exfolio' ), esc_html__( 'Login Success, redirecting...', 'exfolio' ) );


		echo exfolio_view( 'widget/login/login-form', array(
			'instance'    => $instance,
			'exfolioLogin'  => $out,
			'id_title'    => $id,
			'name_title'  => $name,
			'exfolio_title' => $this->exfolio_title
		) );
	}


	public function update( $new_instance, $old_instance ) {

		$instance           = $old_instance;
		$instance['title']  = sanitize_text_field( $new_instance['title'] );
		$instance['username']  = sanitize_text_field( $new_instance['username'] );
		$instance['password']  = sanitize_text_field( $new_instance['password'] );
		$instance['remember']  = sanitize_text_field( $new_instance['remember'] );
		$instance['login']  = sanitize_text_field( $new_instance['login'] );
		$instance['forget_password']  = sanitize_text_field( $new_instance['forget_password'] );
		$instance['register']  = sanitize_text_field( $new_instance['register'] );
		$instance['wrong']  = sanitize_text_field( $new_instance['wrong'] );
		$instance['success']  = sanitize_text_field( $new_instance['success'] );


		return $instance;
	}


}

