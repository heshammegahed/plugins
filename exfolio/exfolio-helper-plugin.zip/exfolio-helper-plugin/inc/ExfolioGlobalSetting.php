<?php

namespace inc;
class ExfolioGlobalSetting {

	private $category = false;
	private $data_reference = [];
	private $data_widget = null;


	public function is_category(): bool {
		return $this->category;
	}

	public function set_category( bool $category ) {
		$this->category = $category;
	}


	public function restData() {
		$GLOBALS['exfolio_global_setting'] = new ExfolioGlobalSetting();
	}

	public function get_data_reference(): array {
		return $this->data_reference;
	}

	public function set_data_reference( array $data_reference ) {
		$this->data_reference = $data_reference;
	}

	/**
	 * @return null
	 */
	public function get_data_widget( $widget = null ) {
		if ( $this->data_widget ) {
			return $this->data_widget;
		}

		return $widget;
	}

	/**
	 * @param null $data_widget
	 */
	public function set_data_widget( $data_widget ) {
		$this->data_widget = $data_widget;
	}


}

/**
 * @global ExfolioGlobalSetting $exfolio_global_setting
 */
$GLOBALS['exfolio_global_setting'] = new ExfolioGlobalSetting();


if ( ! function_exists( 'exfolio_custom_post_slug' ) ) :
	/**
	 * @return ExfolioGlobalSetting
	 */
	function exfolio_get_global_setting(): ExfolioGlobalSetting {
		global $exfolio_global_setting;

		return $exfolio_global_setting;
	}
endif;


/**
 *
 *  ============================
 *         Slug Project
 *  ============================
 *
 *  - Retrieves an option value based on a Slug Work name.
 *
 */
if ( ! function_exists( 'exfolio_custom_post_slug' ) ) :

	function exfolio_custom_post_slug() { //inserts string
		return 'dsn-custom-skin';
	}

endif;


