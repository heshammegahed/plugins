<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );
$widget    = $shortcode->getWidgetBase();



$img_src = $shortcode->getAttachImageSrc($shortcode->getImageId(), $shortcode->getVal( 'image_size', 'full' ));


$widget->add_render_attribute( 'hover-title', [
	'class'       => 'p-relative dsn-style-hover',
	"data-dsn-fx" => $shortcode->getVal( 'style_hover_post', '1' ),
	"data-img"    => $img_src
]  );


printf( '<div %1$s>%2$s</div>',
	$widget->get_render_attribute_string( 'hover-title' ),
	exfolio_shortcode_render_group( 'heading', array( 'widget-base' => $shortcode ) )
);