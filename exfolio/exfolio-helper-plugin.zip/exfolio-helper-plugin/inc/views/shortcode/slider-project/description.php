<?php
/**
 * @var $shortcode exfolioShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );

if ( ! $option['show_description'] ) {
	return '';
}


$description_tag = $shortcode->getItemKey( 'description_header', $option['index'] );
$shortcode->getWidgetBase()->add_render_attribute( $description_tag, [
	'class' => 'description swiper-animate-head max-w570 mt-20',
] );
$description = $shortcode->getSubVal( 'description_header', '', $shortcode->getSubVal( 'ID' ) );
if ( ! $shortcode->getVal( 'dsn_views' ) && ! $description ) {
	$description = get_the_excerpt( $shortcode->getSubVal( 'ID' ) );
}

if ( $description ) {
	printf( '<p %1$s>%2$s</p>',
		$shortcode->getWidgetBase()->get_render_attribute_string( $description_tag ),
		$shortcode->excerpt( $shortcode->getValueNumberSlide( 'excerpt_length', 25 ), strip_tags( $description ) )
	);
}