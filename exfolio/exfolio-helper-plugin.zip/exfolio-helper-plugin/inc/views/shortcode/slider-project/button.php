<?php
/**
 * @var $shortcode exfolioShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );


if ( ! $option['show_button'] ) {
	return '';
}

$key = $option['key'];

$button = new exfolioShortCode( $shortcode );
$button->setWidgetBase( $shortcode->getWidgetBase() );


$is_custom = $shortcode->getVal( 'dsn_views' );
$text_link =

	$is_custom ?
		$shortcode->getSubVal( 'text_link' . $key, esc_html__( "VIEW CASE", 'exfolio' ) ) :
		$shortcode->getVal( 'text_link' , esc_html__( "VIEW CASE", 'exfolio' ) );


$array_block = [
	'text'       => $text_link,
	'style_btn'         => 'dsn-shape-btn dsn-background-inherit',
	'bg_btn'           => 'background-theme',
	'bg_icon'           => 'background-theme',
	'icon_align'        => 'right',
	'icon'              => [ "value" => "fas fa-long-arrow-alt-right", "library" => "fa-solid" ],
	'width_icon'        => [ 'unit' => 'px', 'size' => 14 ]

];


if ( $shortcode->getVal( 'dsn_views' ) && $link = $shortcode->getSubVal( 'link' . $key ) ) {
	$array_block['link'] = $link;
} else {

	$button->getWidgetBase()->add_render_attribute( 'link', [
		'href'          => get_the_permalink( $shortcode->getSubVal( 'ID' ) ),
		'class'         => 'effect-ajax',
		'data-dsn-ajax' => 'slider',
		'data-dsn'      => 'parallax'

	], null, true );

}


$button->setBlock( $array_block );


$button->getWidgetBase()->add_render_attribute( 'link', [
	'class' => [
		' mr-15',
		$shortcode->getVal( 'with_line_' . $key ),
		$shortcode->getVal( 'bg_ver_button-' . $key, '' ),
		$shortcode->getVal( 'bg_button-' . $key, 'background-transparent' )
	]

], null, true );

echo exfolio_shortcode_render_group( 'button', array( 'widget-base' => $button ) );