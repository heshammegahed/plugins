<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );


$widget = $shortcode->getWidgetBase();


$widget->add_render_attribute( 'bg-mask', [
	'class' => [
		'dsn-bg-mask',
		$shortcode->getVal( 'background_ver_mask' ),
		$shortcode->getVal( 'background_mask', 'background-section' )
	]
] );

printf( '<div %s></div>', $widget->get_render_attribute_string( 'bg-mask' ) );