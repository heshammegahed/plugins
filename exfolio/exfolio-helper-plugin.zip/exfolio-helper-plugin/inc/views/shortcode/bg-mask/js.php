<#
view.addRenderAttribute('bg-mask' , 'class' , ['dsn-bg-mask' ,settings.background_ver_mask,settings.background_mask ]);
#>

<div {{{ view.getRenderAttributeString( 'bg-mask' ) }}} ></div>