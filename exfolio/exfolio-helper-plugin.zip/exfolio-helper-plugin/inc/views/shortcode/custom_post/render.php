<?php

use inc\classes\ExfolioOption;

$attr = get_query_var( 'attr' );
/**
 * @var $myPosts WP_Query
 */
$myPosts = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );
$widget    = $shortcode->getWidgetBase();


$id_temp         = $shortcode->getVal( 'choose_template_posts' );
$pluginElementor = \Elementor\Plugin::instance();






$global_setting = \inc\exfolio_get_global_setting();
$global_setting->set_data_reference( $shortcode->getBlock() );
$global_setting->set_data_widget($widget);



/**
 * Swiper
 */

$swiper_item = $shortcode->get_render_swiper_slide_attribute();

$shortcode->add_parallax_attributes( 'dsn-item-content', 'box' );


$widget->add_render_attribute( 'dsn-item-content', 'class', [
	'box-content d-flex dsn-background-inherit',
	$shortcode->getVal( 'bg_btn', 'background-main' )
] );


if ( $myPosts->have_posts() ) :
	while ( $myPosts->have_posts() ) :
		$myPosts->the_post();


		$widget->remove_render_attribute('link');
		$widget->remove_render_attribute('cat');
		$widget->remove_render_attribute('title_link');

		$shortcode->add_parallax_attributes( 'title_link', 'title_link' );
		$shortcode->add_parallax_attributes( 'cat', 'cat_link' );
		$shortcode->add_parallax_attributes( 'link', 'button_link' );

		$widget->add_render_attribute( 'dsn-item-post', 'class', [
			'dsn-item-post  grid-item over-hidden p-relative box-hover-image',
			'post-' . get_the_ID(),
			$shortcode->getVal( 'show_link', '1' ) ? 'dsn-show-link' : '',
			ExfolioOption::PostCategorySlug(),
			$shortcode->getVal( 'bg_ver_btn', '' ),
			$shortcode->getVal( 'bg_btn', 'background-main' ),
		], true );

		$widget->add_render_attribute( 'dsn-item-post', $swiper_item );

		?>


        <article <?php $widget->print_render_attribute_string( 'dsn-item-post' ) ?> >
            <div <?php $widget->print_render_attribute_string( 'dsn-item-content' ) ?>>
				<?php echo exfolio_get_builder_content( $id_temp, $pluginElementor ) ?>
            </div>

        </article>


	<?php
	endwhile;
	wp_reset_postdata();

	$global_setting->restData();

endif;
?>
