<?php



$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );
$widget    = $shortcode->getWidgetBase();

$shortcode->mergeBlock(inc\exfolio_get_global_setting()->get_data_reference());




if ( ! $shortcode->getVal( 'show_excerpt', '1' ) ) {
	return;
}


$widget->add_render_attribute( 'description', [
	'class' => [
		'section_description',
		$shortcode->getVal( 'description_color' ),
	]

] );


$length = $shortcode->getValueNumberSlide( 'excerpt_length_p' );


$length = $length ? $length : $shortcode->getValueNumberSlide( 'excerpt_length', 25 );

if ( $ex = exfolio_excerpt( $length ) ) {
	printf( '<p class="section_description">%1$s</p>', $ex );
}