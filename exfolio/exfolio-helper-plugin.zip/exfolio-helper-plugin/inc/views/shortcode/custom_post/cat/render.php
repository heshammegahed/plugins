<?php

use inc\classes\ExfolioOption;

$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );
$widget    = inc\exfolio_get_global_setting()->get_data_widget($shortcode->getWidgetBase());


$shortcode->mergeBlock( inc\exfolio_get_global_setting()->get_data_reference() );

$meta_data     = $shortcode->getVal( 'meta_data', array( 'category' ) );
$show_category = in_array( 'category', $meta_data );

if ( ! $show_category ) {
	return;
}

$separator_between_cat = $shortcode->getVal( 'separator_between_cat', '' );

$with_svg = $shortcode->getVal( 'with_svg' );
$bg_btn = $shortcode->getVal( 'bg_btn', 'background-main' );



$widget->add_render_attribute( 'cat', [
	'class' => [ 'p-relative dsn-category dsn-bg bg-revere', $with_svg  , $bg_btn]
] );
$widget->add_render_attribute( 'svg', [
	'class' => [ 'dsn-icon' ]
] );


if ( $cat = ExfolioOption::PostCategory( $separator_between_cat, false, true, false, '<span class="cat-item dsn-revere-bg">', '</span>' ) ) {
	printf( '<div %1$s>%2$s %2$s %3$s</div>',
		$widget->get_render_attribute_string( 'cat' ),
		$with_svg ?
			'<span ' . $widget->get_render_attribute_string( 'svg' ) . '><svg class="top-svg" version="1.1" xmlns="http://www.w3.org/2000/svg" x="0" y="0" viewBox="0 0 100 100" xml:space="preserve">
                                                                <path d="M98.1 0h1.9v51.9h-1.9c0-27.6-22.4-50-50-50V0h50z">
                                                                </path>
                                                            </svg></span>' : '',

		$cat );
}