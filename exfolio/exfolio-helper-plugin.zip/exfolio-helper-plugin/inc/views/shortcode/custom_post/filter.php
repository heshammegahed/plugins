<?php
/**
 * @var $shortcode exfolioShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );
$myPosts   = $option['my-posts'];

$type_nav_post = $shortcode->getVal( 'pagination_type', 'none' );
if ( ! $shortcode->getVal( 'filter_bar' ) ) {
	return;
}


$slug_tax      = array_keys( get_taxonomies( array(
	'object_type' => array( $shortcode->getVal( 'query_post', exfolio_project_slug()) )
) ) );


$slug_tax = $slug_tax[0] ?? 'category';
$terms = exfolio_get_filter_categories( $myPosts, $slug_tax );


$widget = $shortcode->getWidgetBase();


$widget->add_render_attribute( 'filter_title', 'class', 'filter-title' );
$widget->add_render_attribute( 'all_filter', [
	'class'       => 'active',
	'data-filter' => '*',
	'type'        => 'button',
] );
?>


<div class="dsn-filtering z-index-1 p-relative w-100 mb-50">
    <div class="filtering-t">
        <div class="filtering-wrap">
            <h5 <?php $widget->print_render_attribute_string( 'filter_title' ) ?> >
				<?php echo esc_html( $shortcode->getVal( 'filter_title', esc_html__( 'Filter', 'exfolio' ) ) ) ?>
            </h5>
            <div class="filtering">
                <button <?php $widget->print_render_attribute_string( 'all_filter' ) ?> >
					<?php echo esc_html( $shortcode->getVal( 'all_filter', esc_html__( 'All', 'exfolio' ) ) ) ?>
                </button>
				<?php
				if ( count( $terms ) ):
					foreach ( $terms as $slug => $name ):?>
                        <button type="button"
                                class="<?php echo 'dsn-filter-category-' . esc_attr( $slug ); ?>"
                                data-filter='.<?php echo esc_attr( $slug ); ?> , .<?php echo 'category-' . esc_attr( $slug ); ?>'>
							<?php echo esc_html( $name ); ?>
                        </button>
					<?php endforeach;
				endif;
				?>
            </div>
        </div>
    </div>
</div>
