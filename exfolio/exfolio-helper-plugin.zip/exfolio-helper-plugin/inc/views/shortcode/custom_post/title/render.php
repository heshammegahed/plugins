<?php

use function inc\exfolio_get_global_setting;

$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


if ( ! $title = wp_kses_post( exfolio_custom_title() ) ) {
	return;
}


$shortcode = new exfolioShortCode( $attr );


$widget    = exfolio_get_global_setting()->get_data_widget($shortcode->getWidgetBase());

$shortcode->mergeBlock( exfolio_get_global_setting()->get_data_reference() );






$widget->add_render_attribute( 'title_link', [
	'href'          => esc_url( get_the_permalink() ),
	'class'         => 'effect-ajax init-color',
	'data-dsn-ajax' => 'work'
], null, true );


$widget->add_render_attribute( 'title', [
	'class' => [
		'post-title',
		$shortcode->getVal( 'font_size', 'title-block' ),
		$shortcode->getVal( 'use_as_stroke' ),
		$shortcode->getVal( 'dsn_line_text' ),
		$shortcode->getVal( 'title_color' ),
	]

], null, true );


printf( '<%1$s %2$s><a %3$s>%4$s</a></%1$s>',
	$shortcode->getHtmlTag(),
	$widget->get_render_attribute_string( 'title' ),
	$widget->get_render_attribute_string( 'title_link' ),
	$title );

