<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new exfolioShortCode( $attr, $items_key );


$items = $shortcode->getVal( 'items', array() );

if ( ! count( $items ) || ! is_array( $items ) ) {
	return;
}


$widget = $shortcode->getWidgetBase();

/**
 * testimonials
 */
$widget->add_render_attribute( 'testimonials', [
	'class'           => 'dsn-testimonials exfolio-swiper-slider dsn-swiper p-relative has-parallax-image',
	'data-dsn-option' => json_encode( $shortcode->getSwiperOption() )
] );

/**
 * testimonials-content
 */
$widget->add_render_attribute( 'swiper-slide', [
	'class' => [
		'swiper-slide',
		$shortcode->getVal( 'bg_ver_item', '' ),
		$shortcode->getVal( 'bg_item', 'background-transparent' ),
		$shortcode->getValBackdropFilter()
	]
] );


$widget->add_render_attribute( 'box-text', 'class', 'label box-text' );
$shortcode->add_parallax_attributes( 'box-text', 'content' );

$widget->add_render_attribute( 'image', 'class', 'avatar d-flex align-items-center box-img ' );
$shortcode->add_parallax_attributes( 'image', 'image' );


$widget->add_render_attribute( 'quote', 'class', 'quote' );
$shortcode->add_parallax_attributes( 'quote', 'description' );


?>

<div <?php $widget->print_render_attribute_string( 'testimonials' ) ?>>

    <div class="testimonials-content">


        <div class="testimonial-inner">

            <div class="swiper">
                <div class="swiper-wrapper">
					<?php foreach ( $items as $index => $item ) : $shortcode->setSubBlock( $item );
						$image = $shortcode->getAttachImage( $shortcode->getSubVal( 'image' ),
							$shortcode->getVal( 'image_size', 'thumbnail' ), array( 'class' => 'cover-bg-img' ) )
						?>
                        <div <?php $widget->print_render_attribute_string( 'swiper-slide' ) ?> >


                            <div class="testimonial-item">
                                <div class="dsn-icon dsn-icon-main-color">
                                    <svg width="20px" height="20px" viewBox="0 0 20 20" version="1.1"
                                         xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
                                        <g id="Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                            <g id="Dribbble-Light-Preview"
                                               transform="translate(-140.000000, -999.000000)" fill="#000000">
                                                <g id="icons" transform="translate(56.000000, 160.000000)">
                                                    <path d="M97.1784026,840.884344 C92.8882915,837.134592 86.2359857,839.256228 84.7592414,844.817545 C84.139128,847.151543 84.7373784,848.235292 84.7373784,849.987037 C84.7373784,851.787636 84,854.395812 84,854.395812 C84,854.714855 84.2832249,855.025921 84.6320386,854.935194 C85.8792217,854.609172 87.8627895,853.964107 90.2349218,854.608175 C98.2119249,856.770688 103.330841,846.261214 97.1784026,840.884344 M103.447113,859 C103.395437,859 103.341773,858.993021 103.287115,858.979063 C96.9806421,857.395812 97.4039887,859.174477 93.8999507,858.237288 C92.8395967,857.954137 91.8746446,857.443669 91.0418642,856.781655 C97.4059763,857.561316 102.710728,852.016948 101.771614,845.487535 C102.732591,846.487535 103.438169,847.72582 103.7363,849.11266 C104.584981,853.048852 102.430484,852.38285 103.983749,858.364905 C104.075176,858.714855 103.765119,859 103.447113,859"
                                                          id="messages_chat-[#1557]"></path>
                                                </g>
                                            </g>
                                        </g>
                                    </svg>
                                </div>

								<?php
								if ( $image ):
									$widget->add_render_attribute( 'image', 'class', ['dsn-auto' , 'img-large'] );
									printf( '<div %1$s>%2$s</div>', $widget->get_render_attribute_string( 'image' ), $image );
									$widget->remove_render_attribute( 'image', 'class', ['dsn-auto' , 'img-large'] );
								endif;
								?>
                                <div class="testimonial-content">

									<?php
									echo exfolio_shortcode_render( 'testimonial/content/description', $shortcode, [
										'index' => $index
									] );
									?>
                                </div>

                                <div class="content-inner ">
                                    <div class="d-flex align-items-center ">
										<?php

										if ( $image ) {
											printf( '<div %1$s>%2$s</div>', $widget->get_render_attribute_string( 'image' ),
												' <div class="dsn-icon"> <svg width="26" height="19" viewBox="0 0 26 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M0 0C10.6801 7.41878 16.3937 7.34643 26 0V19C15.594 10.5293 9.86673 10.5632 0 19V0Z" fill="#E0E0E0" /></svg> </div>' . $image );
										}

										if ( $name = $shortcode->getSubVal( 'name', 'The Name' ) ) {
											$name_key = $shortcode->getItemKey( 'name', $index );
											$widget->add_render_attribute( $name_key, 'class',
												'testimonial-name sm-title-block' );
											$name = sprintf( '<h5 %s>%s</h5>',
												$widget->get_render_attribute_string( $name_key ), $name );
										}


										if ( $position = $shortcode->getSubVal( 'position', 'The Position' ) ) {
											$position_key = $shortcode->getItemKey( 'position', $index );
											$widget->add_render_attribute( $position_key, 'class',
												'testimonial-position ' );
											$position = sprintf( '<span %s>%s</span>',
												$widget->get_render_attribute_string( $position_key ), $position );
										}

										if ( $name || $position ) {
											printf( '<div %s>%s</div>',
												$widget->get_render_attribute_string( 'box-text' ), $name . $position );
										}

										?>

                                    </div>
                                </div>

                            </div>

                        </div>
					<?php endforeach; ?>
                </div>
            </div>
        </div>

		<?php $shortcode->print_content_paginate_render(); ?>
    </div>
</div>
