<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );
$widget    = $shortcode->getWidgetBase();


$widget->add_render_attribute( 'dsn-gallery',
	[
		'class'           => [
			'section-image section-move-image use-horizontal-scroll-image ',
			$shortcode->getVal( 'position_move', '' ),
		],
		'data-dsn-option' => json_encode( [
			'speed' => (float) $shortcode->getValueNumberSlide( 'speed_scroll', 0 ),
			'start' => $shortcode->getVal( 'start_scroll', 0 ),
			'end'   => $shortcode->getVal( 'end_scroll', 0 ),
			'pin'   => boolval( $shortcode->getVal( 'pin_scroll' ) )

		] )

	]
);

$items = $shortcode->getVal( 'items' );

$widget->add_render_attribute( 'grid-item', 'class', [
	"grid-item d-flex align-items-center flex-wrap justify-content-between border-style p-20",
	$shortcode->getVal( 'bg_ver_btn' ),
	$shortcode->getVal( 'bg_btn', 'background-transparent' )
] )


?>

<div class="dsn-marque p-relative h-100 over-hidden">
    <div <?php $widget->print_render_attribute_string( 'dsn-gallery' ) ?>>

		<?php
		if ( count( $items ) ): ?>


			<?php foreach ( $items as $item ):
				$shortcode->setSubBlock( $item );
				?>
                <div <?php $widget->print_render_attribute_string( 'grid-item' ) ?> >
					<?php

					$val_image = $shortcode->getSubVal( 'image' );
					$array_image = explode( '.', $val_image['url'] );
					if ( strtolower( end( $array_image ) ) === "svg" ) {
						$image = $shortcode->getIconImage( $val_image);
					} else {
						$image = $shortcode->getAttachImage($val_image, $shortcode->getVal( 'image_size' ), [ 'class' => 'cover-bg-img' ] );

					}

					if ( $image )

						printf( '<div class="image-item w-100">%s</div>', $image );

					if ( $title = $shortcode->getSubVal( 'title' ) )
						printf( "<h6 class='text-item title-block'>%s</h6>", $title )
					?>

                </div>
			<?php endforeach; ?>

		<?php endif; ?>
    </div>
</div>


