<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );


$widget = $shortcode->getWidgetBase();

$items = $shortcode->getVal( 'items', array() );


if ( ! count( $items ) ) {
	return;
}

$list_with_number = $shortcode->getVal( 'list_with_number' ) && false;
$title_tag        = $shortcode->getHtmlTag();
$font_class_size  = $shortcode->getSize( 'sm-title-block' );

$widget->add_render_attribute( 'accordion', [
	'class' => 'dsn-accordion',
	'role'  => 'tablist',
] );
?>

<div <?php echo $widget->get_render_attribute_string( 'accordion' ) ?>>
    <div class="accordion__wrapper d-flex flex-column">
		<?php foreach ( $items as $index => $item ):
			$shortcode->setSubBlock( $item );

			$ren_title = $shortcode->getItemKey( 'title', $index );
			$ren_desc  = $shortcode->getItemKey( 'description', $index );


			$title       = $shortcode->getSubVal( 'title' );
			$description = $shortcode->getSubVal( 'description' );


			$isIcon     = ! empty( $shortcode->getSubVal( 'icon', array( 'library' => '' ) )['library'] );
			$class_icon = $isIcon ? 'accordion-icon' : '';

			$widget->add_render_attribute( $ren_title, [
				'class'    => [ $font_class_size, 'tab-title heading-color fw-200' ],
				'role'     => 'tab',
				'data-tab' => $index,
			] );

			$widget->add_render_attribute( $ren_desc, [

				'class'    => [
					'accordion__answer tab-description dsn-bg',
					( $index === 0 ) ? 'active' : '',
					$class_icon
				],
				'role'     => 'tabpanel',
				'data-tab' => $index,
			] );

			?>

            <div class="accordion__item  <?php echo $index === 0 ? 'active' : '' ?>">
                <div class="accordion__question user-no-selection dsn-bg d-flex justify-content-between align-items-center <?php echo esc_attr( ( $index === 0 ) ? 'expanded' : '' ) ?> d-flex align-items-center  <?php echo esc_attr( $class_icon ) ?>">
                    <div class="head-desc">

						<?php

						if ( $list_with_number) : printf( '<span class="number background-theme h6">%s</span>', $index + 1 ); endif; ?>

						<?php
						printf( "<%s %s>%s</%s>", $title_tag, $widget->get_render_attribute_string( $ren_title ), $title, $title_tag );

						?>
                    </div>

                    <div class="dsn-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="17" height="15" viewBox="0 0 17 15" fill="">
                            <path d="M10.185 0.699692L9.33651 1.54822L14.6863 6.898L0.598282 6.88707L0.599212 8.08442L14.6872 8.09535L9.34574 13.4368L10.1956 14.2867L16.9838 7.49846L10.185 0.699692Z"
                                  fill=""></path>
                        </svg>
                    </div>

                </div>
                <div <?php echo $widget->get_render_attribute_string( $ren_desc ) ?> >
                    <div class="accordion__answer-item">
						<?php if ( $isIcon ): ?>
                            <span class="dsn-icon mb-20">
                                <?php $shortcode->printIcon( $shortcode->getSubVal( 'icon' ) ) ?>
                        </span>
						<?php
						endif; //--> icon
						echo $shortcode->parse_text_editor( $description, $shortcode->getValues() ) ?>
                    </div>

                </div>
            </div>

		<?php endforeach; ?>
    </div>
</div>