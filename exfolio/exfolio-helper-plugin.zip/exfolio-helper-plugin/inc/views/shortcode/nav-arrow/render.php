<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );


$widget = $shortcode->getWidgetBase();
$title  = $shortcode->getVal( 'title' );

$widget->add_render_attribute( 'nav-arrow', [
	'data-dsn-title' => $title,
	'data-dsn-id'    => $widget->get_id(),
	'class'          => [ 'dsn-nav-arrow d-flex h-100', 'dsn-id-' . $widget->get_id() ]
] );

$widget->add_render_attribute( 'nav-icon-right', [
	'class' => [
		$shortcode->getVal( 'border_color_btn', 'border-color-default' ),
		$shortcode->getVal( 'bg_ver_btn', '' ),
		$shortcode->getVal( 'bg_btn', 'background-section' ),
		$shortcode->getValBackdropFilter()
	]
] );


if ( $shortcode->getVal( 'parallax' ) ) {
	$widget->add_render_attribute( 'nav-icon-right', [
		'data-dsn' => 'parallax',
		'class'    => [ $shortcode->getVal( 'zoom' ), $shortcode->getVal( 'move_circle' ) ],
	] );
}

$widget->add_render_attribute( 'nav-icon-left', $widget->get_render_attributes( 'nav-icon-right' ) );


$widget->add_render_attribute( 'nav-icon-right', 'class', 'dsn-nav-right next-paginate dsn-paginate-arrow box-shadow dsn-slid-normal' );
$widget->add_render_attribute( 'nav-icon-left', 'class', 'dsn-nav-left prev-paginate dsn-paginate-arrow box-shadow dsn-slid-normal' );

?>

<div <?php $widget->print_render_attribute_string( 'nav-arrow' ) ?> >
    <div <?php $widget->print_render_attribute_string( 'nav-icon-left' ) ?> >
        <div class="dsn-icon">
            <svg viewBox="0 0 6 10">
                <path d="M0,9.9C1.4,8.3,2.9,5.6,3.4,5C2.9,4.4,1.4,1.7,0,0.1L0.1,0C1.5,1.6,5.8,4.8,6,5 c-0.2,0.2-4.5,3.4-5.9,5L0,9.9z"></path>
            </svg>
            <svg viewBox="0 0 6 10">
                <path d="M0,9.9C1.4,8.3,2.9,5.6,3.4,5C2.9,4.4,1.4,1.7,0,0.1L0.1,0C1.5,1.6,5.8,4.8,6,5 c-0.2,0.2-4.5,3.4-5.9,5L0,9.9z"></path>
            </svg>
        </div>

    </div>
    <div <?php $widget->print_render_attribute_string( 'nav-icon-right' ) ?> >
        <div class="dsn-icon">
            <svg viewBox="0 0 6 10">
                <path d="M0,9.9C1.4,8.3,2.9,5.6,3.4,5C2.9,4.4,1.4,1.7,0,0.1L0.1,0C1.5,1.6,5.8,4.8,6,5 c-0.2,0.2-4.5,3.4-5.9,5L0,9.9z"></path>
            </svg>
            <svg viewBox="0 0 6 10">
                <path d="M0,9.9C1.4,8.3,2.9,5.6,3.4,5C2.9,4.4,1.4,1.7,0,0.1L0.1,0C1.5,1.6,5.8,4.8,6,5 c-0.2,0.2-4.5,3.4-5.9,5L0,9.9z"></path>
            </svg>
        </div>
    </div>
</div>

