<#
var iconHTML = elementor.helpers.renderIcon( view, settings.selected_icon, { 'aria-hidden': true }, 'i' , 'object' ),
migrated = elementor.helpers.isIconMigrated( settings, 'selected_icon' )
view.addRenderAttribute('icon' , 'class' , 'dsn-icon');
view.addRenderAttribute('icon' , 'class' , settings.bg_ver_icon);
view.addRenderAttribute('icon' , 'class' , settings.bg_icon);
#>
<div class="d-flex">
    <div {{{view.getRenderAttributeString('icon' )}}} >
    <# if ( iconHTML && iconHTML.rendered  ) { #>
    {{{ iconHTML.value }}}
    <# } else { #>
    <i class="{{ settings.icon }}" aria-hidden="true"></i>
    <# } #>
</div>
</div>
