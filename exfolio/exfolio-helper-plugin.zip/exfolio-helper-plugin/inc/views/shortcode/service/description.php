<?php

/**
 * @var $shortcode exfolioShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );


$description_key = $shortcode->getItemKey( 'description', $option['index'] );
$description     = $shortcode->getSubVal( 'description' );
$shortcode->getWidgetBase()->add_render_attribute( $description_key, 'class', [
	'service_description dsn-p',
	'mt-10 max-w570 dsn-auto'
] );
if ( $description ) {
	printf( '<div %1$s>%2$s</div>', $shortcode->getWidgetBase()->get_render_attribute_string( $description_key ), $description );
}