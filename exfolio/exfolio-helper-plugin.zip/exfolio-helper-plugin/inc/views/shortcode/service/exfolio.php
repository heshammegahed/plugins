<?php

/**
 * @var $shortcode exfolioShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );

$widget = $shortcode->getWidgetBase();

if ( ! $shortcode->getVal( 'show_link', '1' ) ) {
	return;
}

$link_key = $shortcode->getItemKey( 'link', $option['index'] );
$is_link  = $shortcode->getOptionArray( $shortcode->getSubVal( 'link' ), 'url' );

if ( ! $is_link && empty( $is_link ) ) {
	return '';
}


$button = new exfolioShortCode( $shortcode );
$button->setWidgetBase( $shortcode->getWidgetBase() );


$array_block = [
	'text'       => $shortcode->getSubVal( 'text_link', esc_html__( "Read More", 'exfolio' ) ),
	'style_btn'         => 'dsn-shape-btn ',
	'bg_btn'           => 'background-theme',
	'bg_icon'           => 'background-theme',
	'icon_align' => 'right',
	'icon'              => [ "value" => "fas fa-long-arrow-alt-right", "library" => "fa-solid" ],
	'width_icon'        => [ 'unit' => 'px', 'size' => 14 ]
];


$widget->add_link_attributes( 'link', $shortcode->getSubVal( 'link', array() ), true );

$button->setBlock( $array_block );
?>
<div class="d-flex mt-20 dsn-background-inherit dsn-shape-btn dsn-icon-heading-color">
	<?php echo exfolio_shortcode_render_group( 'button', array( 'widget-base' => $button ) ); ?>
</div>

