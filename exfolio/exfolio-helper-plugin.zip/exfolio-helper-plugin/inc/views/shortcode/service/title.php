<?php

/**
 * @var $shortcode exfolioShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );


$title_key = $shortcode->getItemKey( 'title', $option['index'] );
$title     = $shortcode->getSubVal( 'title' );

$shortcode->getWidgetBase()->add_render_attribute( $title_key, 'class', [
	'service_title ',
	$shortcode->getSize( 'title-block' ),
	$shortcode->getVal( 'line_service_item', '' )
] );


if ( $title ) {
	printf( '<h4 %1$s>%2$s</h4>', $shortcode->getWidgetBase()->get_render_attribute_string( $title_key ), $title );
}