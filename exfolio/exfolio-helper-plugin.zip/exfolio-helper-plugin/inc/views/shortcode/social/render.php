<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new exfolioShortCode( $attr, $items_key );


$items = $shortcode->getVal( 'items', array() );

if ( ! count( $items ) || ! is_array( $items ) ) {
	return;
}

$widget = $shortcode->getWidgetBase();


?>

<ul class="dsn-socials box-social">
	<?php foreach ( $items as $index => $item ) :

		$shortcode->setSubBlock( $item );

		$title = $shortcode->getItemKey( 'title', $index );
		$title = $shortcode->getSubVal( 'title', 'FB' );
		$widget->add_render_attribute( $title, 'class', 'social-title' );

		$link = $shortcode->getSubVal( 'link' );
		printf( '<li ><a href="%1$s" target="_blank" rel="nofollow" class="init-color move-circle border-color-default ' . $shortcode->getVal( 'bg_item', 'background-section' ) . '" data-dsn="parallax"><span class="dsn-icon">%2$s</span><span>%3$s</span></a></li>',
			$link,
			$shortcode->getIcon( $shortcode->getSubVal( 'icon' ) ),
			$title
		);

	endforeach; ?>

</ul>

