<div class="dsn-logo main-logo">
	<?php exfolio_get_template_header( 'site', 'logo' ); ?>
</div>