<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );


$widget = $shortcode->getWidgetBase();

$items = $shortcode->getVal( 'items', array() );


if ( ! count( $items ) ) {
	return;
}

$html_tag = $shortcode->getHtmlTag();

$widget->add_render_attribute( 'grid', [
	'class'           => 'dsn-flip-animation dsn-grid-hover',
	'style'           => '--grid-count:' . count( $items ),
	'data-dsn-option' => json_encode( [
		'translateX'    => boolval( $shortcode->getVal( 'x', '1' ) ),
		'translateY'    => boolval( $shortcode->getVal( 'y' ) ),
		'skewX'         => boolval( $shortcode->getVal( 'skewx', '1' ) ),
		'skewY'         => boolval( $shortcode->getVal( 'skewy' ) ),
		'contrast'      => boolval( $shortcode->getVal( 'contrast', '1' ) ),
		'scale'         => boolval( $shortcode->getVal( 'scale' ) ),
		'brightness'    => boolval( $shortcode->getVal( 'brightness', '1' ) ),
		'speed'         => $shortcode->getVal( 'speed', 30 ),
		'parentElement' => $shortcode->getVal( 'target_element' ),
	] )
] );


$widget->add_render_attribute( 'row', 'class', [
	'grid-row',

] );
$widget->add_render_attribute( 'row-item', 'class', [
	'row__item-card',
	$shortcode->getVal( 'bg_ver_icon' ),
	$shortcode->getVal( 'bg_icon', "background-transparent" ),
] );

?>


<div <?php $widget->print_render_attribute_string( 'grid' ); ?>>


	<?php foreach ( $items as $index => $item ):

		$shortcode->setSubBlock( $item ); ?>

        <div <?php $widget->print_render_attribute_string( 'row' ); ?>>

			<?php
			$gallery = $shortcode->getSubVal( 'gallery' );
			if ( ! count( $gallery ) ) {
				continue;
			}
			foreach ( $gallery as $img ):


				?>
                <div <?php $widget->print_render_attribute_string( 'row-item' ); ?>>
					<?php
					echo wp_get_attachment_image( $img['id'], $shortcode->getVal( 'image_size', 'large' ), [
						'class' => 'cover-bg-img',
					] )
					?>
                </div>
			<?php endforeach; ?>
        </div>

	<?php endforeach; ?>

</div>
