<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new exfolioShortCode( $attr );


$widget = $shortcode->getWidgetBase();
$items  = $shortcode->getVal( 'items', array() );


if ( ! count( $items ) ) {
	return;
}


$widget->add_render_attribute( 'skills-item', 'class', 'dsn-skills-item grid-item' );

$style_skill = $shortcode->getVal( 'style_skill', 'p' ) . 'c';


$widget->add_render_attribute( 'skills-inner', 'class', 'skills-inner' );
$widget->add_render_attribute( 'number', 'class', 'dsn-number-award number' );


foreach ( $items as $index => $item ):
	$shortcode->setSubBlock( $item );
	?>

    <div <?php $widget->print_render_attribute_string( 'skills-item' ) ?>>
        <div <?php $widget->print_render_attribute_string( 'skills-inner' ) ?>>

			<?php
			echo exfolio_shortcode_render( 'skills/' . $style_skill, $shortcode, [
				'index' => $index
			] );
			?>


        </div>
    </div>
<?php endforeach; ?>

