<?php
if ( is_user_logged_in() ) {
	return;
}
$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : __( 'Login', 'exfolio' );
$username = ( ! empty( $instance['username'] ) ) ? $instance['username'] : '';
$password = ( ! empty( $instance['password'] ) ) ? $instance['password'] : '';
$remember = ( ! empty( $instance['remember'] ) ) ? $instance['remember'] : '';
$login = ( ! empty( $instance['login'] ) ) ? $instance['login'] : '';
$forget_password = ( ! empty( $instance['forget_password'] ) ) ? $instance['forget_password'] : '';
$register = ( ! empty( $instance['register'] ) ) ? $instance['register'] : '';
$wrong = ( ! empty( $instance['wrong'] ) ) ? $instance['wrong'] : '';
$success = ( ! empty( $instance['success'] ) ) ? $instance['success'] : '';
?>

<?php echo isset( $args["before_widget"] ) ? $args["before_widget"] : ''; ?>


    <div class="dsn-icon">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
             stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
             class="lucide lucide-user-round">
            <circle cx="12" cy="8" r="5"/>
            <path d="M20 21a8 8 0 0 0-16 0"/>
        </svg>
    </div>

    <div class="dsn-login">
	    <?php printf( '<h2 class="title-login title-block">%s</h2>', $title ) ?>
        <p class="status-form" data-dsn-form='{"wrong":"<?php esc_attr_e($username);?>","success":"<?php esc_attr_e($success);?>"}'></p>
        <form class="dsn-login__form" >
            <div class="form__input">
                <label>
                    <input type="text" name="username" placeholder="<?php esc_attr_e($username);?>" required/>
                </label>
            </div>
            <div class="form__input">
                <label>
                    <input type="password" name="password" placeholder="<?php esc_attr_e($password);?>" required/>
                </label>
            </div>
            <p class="forget-me-not">
                <label>
                    <input name="rememberme" type="checkbox"/>
	                <?php esc_html_e($remember);?>
                </label>
            </p>
            <div class="auth-btn">
                <button type="submit" class="background-main move-circle" data-dsn="parallax" >
                    <span class="p-relative z-index-1"><?php esc_html_e($login);?></span>

                </button>
            </div>
            <div class="action-login d-flex gap-20 justify-content-between align-items-center flex-wrap">
                <a href="<?php echo wp_lostpassword_url() ?>"><?php esc_html_e($forget_password);?></a>
                <a href="<?php echo wp_registration_url() ?>"><?php esc_html_e($register);?></a>
            </div>

        </form>
    </div>


<?php echo isset( $args["after_widget"] ) ? $args["after_widget"] : ''; ?>