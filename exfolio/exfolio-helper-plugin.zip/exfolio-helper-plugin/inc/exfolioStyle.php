<?php


namespace inc ;
class exfolioStyle {


	public function __construct() {

		add_action( 'init', [ $this, 'initTheme' ], 1 );
		add_filter( 'body_class', [ $this, 'bodyClass' ] );
	}


	/**
	 *
	 */
	public function initTheme() {
		if ( get_theme_mod( 'button_style_theme' ) )
			add_action( "wp_body_open", function () {
				echo "<script id='hdev_exfolio_script'>if(typeof hdevStartTheme === 'function')hdevStartTheme()</script>";
			} );

	}


	/**
	 * @param $classes
	 *
	 * @return mixed
	 */
	public function bodyClass( $classes ) {
		$classes[] = exfolio_getStyleDefault();



		if ( ! exfolio_is_elementor_preview_mode() && get_theme_mod( 'event_smooth_scrolling' ) ) {
			$classes[] = 'dsn-effect-scroll';
			wp_enqueue_script( 'smooth-scrollbar' );
			wp_enqueue_script( 'lenis' );
		}

		return $classes;
	}
}

new exfolioStyle();