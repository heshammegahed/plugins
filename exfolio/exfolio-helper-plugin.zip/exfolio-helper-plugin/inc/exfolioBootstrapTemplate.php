<?php


namespace inc;
use inc\classes\ExfolioTemplate;

if ( ! class_exists( "ExfolioTemplate" ) ) {
	return;
}

class exfolioBootstrapTemplate extends ExfolioTemplate {

	private static $inst = null;

	public function __construct() {
		parent::__construct();
		do_action( 'ohixm_template_category', $this->category() );
		do_action( 'ohixm_template', $this->temp() );
	}

	public static function Instance() {
		if ( self::$inst === null ) {
			self::$inst = new exfolioBootstrapTemplate();
		}

		return self::$inst;
	}

	protected function enqueue_scripts() {
		//--> fancybox
		wp_enqueue_style( exfolioFrontEnd::FANCYBOX, OHIXM_MODULES_PATH . '/fancybox/fancybox.css', array(), '4.0.26' );
		wp_enqueue_script( exfolioFrontEnd::FANCYBOX, OHIXM_MODULES_PATH . '/fancybox/fancybox.min.js', array( 'jquery' ), '4.0.26', true );
	}

	private function category(): array {

		return [
			'page'        => esc_html__( "Page", 'ohixm' ),
			'block'       => esc_html__( "Block", 'ohixm' ),
			'header'      => esc_html__( "Header", 'ohixm' ),
			'carousel'    => esc_html__( "Carousel", 'ohixm' ),
			'footer'      => esc_html__( "Footer", 'ohixm' ),
			'photography' => esc_html__( "Photography", 'ohixm' ),
			'portfolio'   => esc_html__( "Portfolio", 'ohixm' ),
			'personal'    => esc_html__( "Personal", 'ohixm' ),
		];
	}


	private function temp(): array {
		$url_page = "https://dsngrid.com/ohixm/";

		return [
			'contact'                   => [
				'name'     => esc_html__( "Contact Page", 'ohixm' ),
				'category' => [ 'page' ],
				"iframe"   => $url_page . "contact-us/"
			],
			'services_page'             => [
				'name'     => esc_html__( "Services Page", 'ohixm' ),
				'category' => [ 'page' ],
				"iframe"   => $url_page . "service/"

			],
			'work_card_2'               => [
				'name'     => esc_html__( "Work Card", 'ohixm' ),
				'category' => [ 'portfolio' ],

			],
			'work_classic_2'            => [
				'name'     => esc_html__( "work classic", 'ohixm' ),
				'category' => [ 'portfolio' ],

			],
			'about_us'                  => [
				'name'     => esc_html__( "About Us Page", 'ohixm' ),
				'category' => [ 'page' ],
				"iframe"   => $url_page . "about-us/"


			],
			'accordion_about'           => [
				'name'     => esc_html__( "Accordion", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'agency_about'              => [
				'name'     => esc_html__( "Agency", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'agency_header'             => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'architecture_about'        => [
				'name'     => esc_html__( "About Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'architecture_header'       => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'brands_1'                  => [
				'name'     => esc_html__( "Brand", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'brands_2'                  => [
				'name'     => esc_html__( "Brand", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'business_about'            => [
				'name'     => esc_html__( "About Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'business_header'           => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'carousel-portfolio-1'      => [
				'name'     => esc_html__( "Carousel", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "carousel-portfolio-1/"


			],
			'carousel-portfolio-2'      => [
				'name'     => esc_html__( "Carousel", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "carousel-portfolio-2/"


			],
			'carousel-portfolio-3'      => [
				'name'     => esc_html__( "Carousel", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "carousel-portfolio-3/"


			],
			'carousel-portfolio-4'      => [
				'name'     => esc_html__( "Carousel", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "carousel-portfolio-4/"


			],
			'contact_form'              => [
				'name'     => esc_html__( "Contact Form", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'contact_header'            => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'facts'                     => [
				'name'     => esc_html__( "Facts", 'ohixm' ),
				'category' => [ 'page' ],

			],
			'header_about'              => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'header_work'               => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'header_work_2'             => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'header_work_3'             => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'header_work_4'             => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'hero_1'                    => [
				'name'     => esc_html__( "Hero Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'hero_2'                    => [
				'name'     => esc_html__( "Hero Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'hero_3'                    => [
				'name'     => esc_html__( "Hero Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'hero_4'                    => [
				'name'     => esc_html__( "Hero Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'hero_5'                    => [
				'name'     => esc_html__( "Hero Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'image_half_about'          => [
				'name'     => esc_html__( "Image Half Left", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'main_slider'               => [
				'name'     => esc_html__( "Slider", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],

			],
			'map'                       => [
				'name'     => esc_html__( "Map", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'marquee'                   => [
				'name'     => esc_html__( "Marquee", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'personal_header'           => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header', 'personal', 'photography' ],

			],
			'photographer_header'       => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header', 'personal', 'photography' ],

			],
			'section_blog'              => [
				'name'     => esc_html__( "Blog", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_blog_2'            => [
				'name'     => esc_html__( "Blog", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_blog_3'            => [
				'name'     => esc_html__( "Blog", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_blog_4'            => [
				'name'     => esc_html__( "Blog", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_number'            => [
				'name'     => esc_html__( "Award", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'section_number_about'      => [
				'name'     => esc_html__( "Award", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'section_seat_1'            => [
				'name'     => esc_html__( "About Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'section_seat_2'            => [
				'name'     => esc_html__( "About Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'section_seat_3'            => [
				'name'     => esc_html__( "About Section", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'section_work_1'            => [
				'name'     => esc_html__( "Work", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_work_2'            => [
				'name'     => esc_html__( "Work", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_work_3'            => [
				'name'     => esc_html__( "Work", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_work_4'            => [
				'name'     => esc_html__( "Work", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_work_5'            => [
				'name'     => esc_html__( "Work", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'section_work_6'            => [
				'name'     => esc_html__( "Work", 'ohixm' ),
				'category' => [ 'portfolio', 'block' ],

			],
			'services'                  => [
				'name'     => esc_html__( "Service", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'services_1'                => [
				'name'     => esc_html__( "Service", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'services_2'                => [
				'name'     => esc_html__( "Service", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'services_3'                => [
				'name'     => esc_html__( "Service", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'services_4'                => [
				'name'     => esc_html__( "Service", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'services_5'                => [
				'name'     => esc_html__( "Service", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'services_6'                => [
				'name'     => esc_html__( "Service", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'services_page_header'      => [
				'name'     => esc_html__( "Header", 'ohixm' ),
				'category' => [ 'block', 'header' ],

			],
			'skills'                    => [
				'name'     => esc_html__( "Skills", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'slider_full_horizontal'    => [
				'name'     => esc_html__( "slider full horizontal", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "slider-full-horizontal/"


			],
			'slider_full_vertical'      => [
				'name'     => esc_html__( "slider full vertical", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "slider-full-vertical/"


			],
			'slider_padding_horizontal' => [
				'name'     => esc_html__( "slider Padding horizontal", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "slider-left/"


			],
			'slider_padding_vertical'   => [
				'name'     => esc_html__( "slider Padding vertical", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "slider-padding-vertical/"


			],
			'work_scroll_vertical'      => [
				'name'     => esc_html__( "slider card vertical", 'ohixm' ),
				'category' => [ 'portfolio', 'carousel', 'block' ],
				"iframe"   => $url_page . "work-scroll-vertical/"


			],
			'testimonial_1'             => [
				'name'     => esc_html__( "Testimonial", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'testimonial_2'             => [
				'name'     => esc_html__( "Testimonial", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'testimonial_3'             => [
				'name'     => esc_html__( "Testimonial", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'testimonial_4'             => [
				'name'     => esc_html__( "Testimonial", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'testimonial_about'         => [
				'name'     => esc_html__( "Testimonial", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'video'                     => [
				'name'     => esc_html__( "video", 'ohixm' ),
				'category' => [ 'block' ],

			],
			'work_card'                 => [
				'name'     => esc_html__( "work Card", 'ohixm' ),
				'category' => [ 'page', 'portfolio', 'block' ],
				"iframe"   => $url_page . "work-card-1/"

			],
			'work_card_3'               => [
				'name'     => esc_html__( "work Card", 'ohixm' ),
				'category' => [ 'page', 'portfolio', 'block' ],
				"iframe"   => $url_page . "work-card-2/"


			],
			'work_classic'              => [
				'name'     => esc_html__( "work Classic", 'ohixm' ),
				'category' => [ 'page', 'portfolio', 'block' ],
				"iframe"   => $url_page . "work-classic-1/"


			],
			'work_classic_3'            => [
				'name'     => esc_html__( "work Classic", 'ohixm' ),
				'category' => [ 'page', 'portfolio', 'block' ],
				"iframe"   => $url_page . "work-classic-3/"


			],
			'work_list'                 => [
				'name'     => esc_html__( "work List", 'ohixm' ),
				'category' => [ 'page', 'portfolio', 'block' ],
				"iframe"   => $url_page . "work-list-1/"


			],
			'photographer'              => [
				'name'     => esc_html__( "photographer", 'ohixm' ),
				'category' => [ 'page', 'photographer' ],
				"iframe"   => $url_page . "photographer/"


			],
			'personal'                  => [
				'name'     => esc_html__( "personal", 'ohixm' ),
				'category' => [ 'page', 'personal' ],
				"iframe"   => $url_page . "personal/"


			],
			'business'                  => [
				'name'     => esc_html__( "Business", 'ohixm' ),
				'category' => [ 'page' ],
				"iframe"   => $url_page . "business/"


			],
			'architecture'              => [
				'name'     => esc_html__( "Architecture", 'ohixm' ),
				'category' => [ 'page' ],
				"iframe"   => $url_page . "architecture/"

			],
			'agency'                    => [
				'name'     => esc_html__( "Agency", 'ohixm' ),
				'category' => [ 'page' ],
				"iframe"   => $url_page . "agency/"


			],
			'home'                      => [
				'name'     => esc_html__( "Corporate", 'ohixm' ),
				'category' => [ 'page' ],
				"iframe"   => $url_page . "corporate/"


			]

		];
	}

	public function print_template_views() {

		ohixm_view( 'print-template', [
			'categories' => $this->category(),
			'templates'  => $this->temp(),
		], false );
	}

	public function get_json( $name ) {


//		return @json_decode( file_get_contents( ohixm__PLUGIN_DIR_URL . 'assets/img/template/' . $name . ".json" ), true );
		return @json_decode( file_get_contents( "https://xxx.dsngrid.com/mestc/templete/" . $name . ".json" ), true );

	}
}

exfolioBootstrapTemplate::Instance();
