<?php

add_action( 'widgets_init', function () {

	$before_widget = '<div id="%1$s" class="widget %2$s">';
	$after_widget  = '</div>';
	$before_title  = '<h4 class="title-s heading title-style">';
	$after_title   = '</h4>';

	/**
	 *
	 * Woocommerce  Sidebar Blog
	 *
	 */
	register_sidebar( array(
		'id'            => 'wc-sidebar-1',
		'name'          => esc_html__( 'exfolio Woocommerce Sidebar', 'exfolio' ),
		'description'   => esc_html__( 'This is the widgetized Woocommerce sidebar.', 'exfolio' ),
		'before_widget' => $before_widget,
		'after_widget'  => $after_widget,
		'before_title'  => $before_title,
		'after_title'   => $after_title,
	) );


	/**
	 *
	 * Woocommerce  Cart
	 *
	 */
	register_sidebar( array(
		'id'            => 'wc-sidebar-cart',
		'name'          => esc_html__( 'exfolio Sidebar Menu', 'exfolio' ),
		'description'   => esc_html__( 'This is the widgetized Cart Woocommerce. & Search & Login', 'exfolio' ),
		'before_widget' => $before_widget,
		'after_widget'  => $after_widget,
		'before_title'  => $before_title,
		'after_title'   => $after_title,
	) );


} );


exfolio_get_template_render( 'widget/exfolioLogin' );

add_action( 'widgets_init', function() {
	register_widget( 'exfolioLogin' );
});