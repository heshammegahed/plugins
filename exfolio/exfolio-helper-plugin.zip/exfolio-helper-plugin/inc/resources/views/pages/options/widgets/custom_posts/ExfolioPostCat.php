<?php

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
};

/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class  ExfolioPostCat extends Widget_Base {

	use Exfolio_Widget_Base;

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_post_cat';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return __( 'exfolio Post Category', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-archive-posts';

	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'archive' ,'post' ,'category'] );
	}



	protected function register_controls() {

		$control = $this->getControl();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addSwitcher('with_svg')
			->setLabel(esc_html__('With SVG', 'exfolio'))
			->setReturn_value('dsn-with-svg')
			->get();
		$this->end_controls_section();
	}
	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		echo exfolio_shortcode_render_group( 'custom_post/cat', array( 'widget-base' => $this ) );

	}


}
