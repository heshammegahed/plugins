<?php

namespace inc\resources\views\pages\options\widgets\posts;


use Elementor\Core\Files\CSS\Post as Post_CSS;
use Elementor\Controls_Manager;
use inc\classes\ExfolioOption;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;
use function inc\exfolio_custom_post_slug;


trait  PostControl {

	public function __content_controller( ExfolioControl $control ) {


		$customPostType = exfolio_get_post_array( exfolio_custom_post_slug() );



		$control->addSelect2( 'choose_template_posts', $customPostType )

		        ->setLabelBlock()
		        ->setLabel( esc_html__( "Choose Template Post", "exfolio" ) )
		        ->get();


		$postTypes = get_post_types( array(
			'public'       => true,
			'show_in_rest' => true
		) );

		unset( $postTypes['attachment'] );
		unset( $postTypes['page'] );


		$control->addSelect( 'query_post', $postTypes )
		        ->setLabel( esc_html__( "Query", 'exfolio' ) )
		        ->setDefault( exfolio_project_slug() )
		        ->get();

		$control->addNumber( 'post_per_page', - 1, null, 1 )
		        ->setLabel( esc_html__( 'Post Per Page', 'exfolio' ) )
		        ->setDescription( esc_html__( 'number of posts to show per page , (-1 or 0) (show all posts) is used.',
			        'exfolio' ) )
		        ->setDefault( 6 )
		        ->get();

		$control->addImageSize()
		        ->getGroup();


	}

	public function __title_content_controller( ExfolioControl $control ) {
		$control->addHtmlTag()
		        ->setSeparator( "before" )
		        ->get();

		$control->addSize()
		        ->setDefault( 'title-block' )
		        ->get();
	}

	public function __excerpt_content_controller( ExfolioControl $control ) {

		$control->addSwitcher( 'show_excerpt' )
		        ->setSeparator( "before" )
		        ->setDefault( '1' )
		        ->setLabel( esc_html__( "Excerpt", 'exfolio' ) )
		        ->get();

		$control->addNumberSlider( 'excerpt_length_p', 15, 300, 5 )
		        ->setLabel( esc_html__( 'Excerpt length', 'exfolio' ) )
		        ->setCondition( [ 'show_excerpt' => '1' ] )
		        ->get();


	}


	public function __link_content_controller( ExfolioControl $control ) {

		$control->addSwitcher( 'show_link' )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( "Read More", 'exfolio' ) )
		        ->setDefault( '1' )
		        ->get();

	}

	public function __meta_content_controller( ExfolioControl $control ) {
		$control->addSelect2( 'meta_data', [
			'date'     => esc_html__( 'Date', 'exfolio' ),
			'category' => esc_html__( 'Category', 'exfolio' )
		] )
		        ->setMultiple()
		        ->setDefault( array( 'date', 'category' ) )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( 'Meta Data', 'exfolio' ) )
		        ->get();


	}


	public function __card_controller( ExfolioControl $control ) {
		$this->start_controls_section(
			'style_card_section',
			[
				'label' => esc_html__( 'Card', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_control(
			'dsn_important_note',
			[
				'label'           => esc_html__( 'Important Note', 'exfolio' ),
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => __( '<h6 style="margin-top:10px">you can use this options by class ( <span style="color: orangered">post-content</span> ) for container on skin post</h6>', 'exfolio' ),
				'content_classes' => 'your-class',
			]
		);

		$control->addSelect( 'bg_ver_btn',
			$control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background', 'exfolio' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background', 'exfolio' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-main' )
		        ->get();

		$control->addPaddingGroup( 'item_padding', '.root-posts .dsn-posts .box-content .post-content' )
		        ->setSeparator( "before" )
		        ->getResponsive();

		$control->addMarginGroup( 'item_margin', '.root-posts .dsn-posts .box-content .post-content' )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.root-posts .dsn-posts .box-content .post-content' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.root-posts .dsn-posts .box-content .post-content' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.root-posts .dsn-posts .box-content .post-content' )->getGroup();


		$this->end_controls_section();


	}

	public function __image_style_controller( ExfolioControl $control ) {
		$this->start_controls_section(
			'style_image_section',
			[
				'label' => esc_html__( 'Image', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$control->addSlider( 'dsn_height_image', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( esc_html__( 'Height', 'exfolio' ) )
		        ->setSelectors( '.box-image-link .box-image-bg ,{{WRAPPER}} .elementor-widget-dsn_featured-image', 'height:{{SIZE}}{{UNIT}};max-height:{{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addSelect( 'animate_image', [
			''                    => esc_html__( 'Default', 'exfolio' ),
			'box-image-transform' => esc_html__( 'Transform', 'exfolio' ),
			'box-image-parallax'  => esc_html__( 'Parallax', 'exfolio' ),
		] )
		        ->setLabel( esc_html__( 'Animate Image', 'exfolio' ) )
		        ->setDefault( '' )
		        ->setPrefix_class()
		        ->get();

		$control->addBorderRadiusGroup( 'item_border_radius_image', '.root-posts .dsn-posts .box-content .box-image-bg img , {{WRAPPER}} .root-posts .dsn-posts .box-content .box-image-bg:before ' )
		        ->getResponsive();

		$this->end_controls_section();
	}

	public function __style_controller( ExfolioControl $control ) {
		$args = array(
			'post-title'          => esc_html__( 'Title', 'exfolio' ),
			'cat-item a'        => esc_html__( 'Meta Data', 'exfolio' ),
			'section_description' => esc_html__( 'Description', 'exfolio' ),
		);

		foreach ( $args as $id => $value ):


			$this->start_controls_section(
				'style_content_post_' . sanitize_title( $id ),
				[
					'label' => $value,
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);


			$control->addColor( 'color_content_' . sanitize_title( $id ) )
			        ->setLabel( esc_html__( "Color", 'exfolio' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content_' . sanitize_title( $id ), '.' . $id )
			        ->getGroup();

			$control->addTextShadow( 'text_content_shadow_' . sanitize_title( $id ), '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;
	}


	protected function query( ExfolioControl $control ) {


		/**
		 * Query
		 */
		$this->start_controls_section(
			'content_query',
			[
				'label' => esc_html__( 'Query', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);




		$control->addSelect2( 'include_tax', ExfolioOption::getTermsArray( [
			'taxonomy' => [
				'category',
				exfolio_category_slug(),
				class_exists( 'WooCommerce' ) ? 'product_cat' : '',
			]
		], "term_id" ) )
		        ->setMultiple()
		        ->setLabelBlock()
		        ->setDefault( [] )
		        ->setPlaceholder( esc_html__( "All", "exfolio" ) )
		        ->setLabel( esc_html__( 'Taxonomy Query', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Show posts associated with certain taxonomy.', 'exfolio' ) )
		        ->get();

		$control->addSelect( 'operator_tax', [
			"IN"         => "IN",
			"NOT IN"     => "NOT IN",
			"AND"        => "AND",
			"EXISTS"     => "EXISTS",
			"NOT EXISTS" => "NOT EXISTS",
		] )
		        ->setDefault( "NOT IN" )
		        ->setLabelBlock()
		        ->setLabel( esc_html__( 'Operator Tax', 'exfolio' ), true )
		        ->get();

		$control->addNumber( 'offset', 0, null, 1 )
		        ->setDefault( 0 )
		        ->setSeparatorBefore()
		        ->setLabel( esc_html__( 'Offset', 'exfolio' ), true )
		        ->setDescription( esc_html__( 'offset Display posts from the 4th one', 'exfolio' ) )
		        ->get();

		$control->addSelect( 'orderby', [
			'none'       => esc_html__( 'No order', 'exfolio' ),
			'ID'         => esc_html__( 'post id', 'exfolio' ),
			'author'     => esc_html__( 'author', 'exfolio' ),
			'menu_order' => esc_html__( 'Menu Order', 'exfolio' ),
			'title'      => esc_html__( 'title', 'exfolio' ),
			'name'       => esc_html__( 'name', 'exfolio' ),
			'date'       => esc_html__( 'date', 'exfolio' ),
			'modified'   => esc_html__( 'last modified date', 'exfolio' ),
			'rand'       => esc_html__( 'Random order', 'exfolio' ),
		] )
		        ->setLabel( esc_html__( 'Order By', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Sort retrieved posts.', 'exfolio' ) )
		        ->setDefault( "date" )
		        ->get();

		$control->addSelect( 'order', [
			'DESC' => esc_html__( 'descending', 'exfolio' ),
			'ASC'  => esc_html__( 'ascending', 'exfolio' )
		] )
		        ->setLabel( esc_html__( 'Order', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Designates the ascending or descending order of the ‘orderby‘ parameter', 'exfolio' ) )
		        ->setDefault( "DESC" )
		        ->get();

		$this->end_controls_section();

	}


	public function getOptionQueries( \exfolioShortCode $shortcode ): array {

		$query_post    = $shortcode->getVal( 'query_post', exfolio_project_slug() );
		$post_per_page = $shortcode->getVal( 'post_per_page', 6 );
		$CurrentPage   = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;
		$slug_tax      = array_keys( get_taxonomies( array(
			'object_type' => array( $query_post )
		) ) );
		$slug_tax      = $slug_tax[0] ?? exfolio_category_slug();


		return array(
			'paged'          => $CurrentPage,
			'posts_per_page' => $post_per_page,
			'post_type'      => $query_post,

			'offset'    => $shortcode->getVal( 'offset', 0 ),
			'orderby'   => $shortcode->getVal( 'orderby', 'date' ),
			'order'     => $shortcode->getVal( 'order', 'DESC' ),
			'tax_query' => array(
				'relation' => 'OR',
				array(
					'taxonomy' => $slug_tax,
					'field'    => 'term_id',
					'terms'    => $shortcode->getVal( 'include_tax', [] ),
					'operator' => $shortcode->getVal( 'operator_tax', "NOT IN" ),
				),
			),

		);

	}





	public function EnqueueCssPosts() {

		if ( exfolio_is_elementor_preview_mode() ) {
			$myPosts = get_posts( [ "post_type" => exfolio_custom_post_slug(), 'posts_per_page' => - 1 ] );

			if ( $myPosts ) {
				foreach ( $myPosts as $post ) :
					$css_file = Post_CSS::create( $post->ID );
					$css_file->enqueue();
					$css_file->print_css();
				endforeach;
			}

		}

	}



}
