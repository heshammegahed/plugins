<?php

namespace inc\resources\views\pages\options\widgets\control;


use Elementor\Controls_Manager;
use Elementor\Controls_Stack;
use Elementor\Element_Base;


class ExfolioRegisterElement {

	use ExfolioRenderSectionElement;


	public function registerWidgetSection() {

		/**
		 * Add Controller For Element
		 * background_overlay_image
		 */
		add_action( 'elementor/element/section/section_layout/before_section_start',
			[ $this, 'register_widgets_before_section' ], 10, 2 );

		add_action( 'elementor/element/column/layout/before_section_start',
			[ $this, 'register_widgets_before_section' ], 10, 2 );


		add_action( 'elementor/element/after_section_end',

			[ $this, 'render_motion_effect' ], 10, 2 );


	}


	public function render_motion_effect( Controls_Stack $element, $section_id ) {


		if ( ! $element instanceof Element_Base || 'section_custom_attributes_pro' !== $section_id ) {
			return;
		}

		$control = new ExfolioControl ( $element );


		if ( $element->get_name() === "container" ) {
			$element->start_controls_section(
				'exfolio_section_space',
				[
					'tab'   => Controls_Manager::TAB_SETTINGS,
					'label' => __( 'exfolio Style', 'exfolio' ),
				]
			);
			/**
			 *  Add Padding & Margin in (Section , Column)
			 */
			$this->addSpaceSection( $element, $control );

			$element->add_control( 'hr_1', [ 'type' => Controls_Manager::DIVIDER ] );


			/**
			 * screen length
			 * $this->addLayout( $element, [ 'full-width' => esc_html__( 'Ful Width', 'exfolio' ) ] );
			 */
			$this->addLayout( $element );

			$element->add_control( 'hr_2', [ 'type' => Controls_Manager::DIVIDER ] );
			$this->addStyleBg( $element );

			$element->end_controls_section();


			$element->start_controls_section(
				'exfolio_section_flexibility',
				[
					'tab'   => Controls_Manager::TAB_SETTINGS,
					'label' => __( 'exfolio Flexibility', 'exfolio' ),
				]
			);

			$control->getFlexibilityGroup();

			$element->end_controls_section();

		}

		$control = new ExfolioControl ( $element );

		$element->start_controls_section(
			'dsn_motion_effect',
			[
				'tab'   => Controls_Manager::TAB_ADVANCED,
				'label' => esc_html__( 'DSN Motion Effect', 'exfolio' ),
			]
		);


		$control->addSwitcher( 'use_motion_effect' )
		        ->setLabel( esc_html__( 'Scrolling Effects', 'exfolio' ) )
		        ->get();


		$control->addText( 'use_trigger' )
		        ->setLabel( esc_html__( 'Trigger', 'exfolio' ) )
		        ->setDescription( esc_html__( 'The element (or selector text for the element) whose position in the normal document flow is used to calculate where the ScrollTrigger starts. ',
			        'exfolio' ) )
		        ->setConditions( 'use_motion_effect', '1' )
		        ->get();

		$control->addText( 'use_scrub' )
		        ->setLabel( esc_html__( 'Scrub', 'exfolio' ) )
		        ->setDescription( esc_html__( "smooth scrubbing is empty ( don't animate the pinned element itself because that will throw off the measurements )",
			        'exfolio' ) )
		        ->setConditions( 'use_motion_effect', '1' )
		        ->get();

		$control->addText( 'use_start' )
		        ->setLabel( esc_html__( 'Start', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Space Start Top', 'exfolio' ) )
		        ->setDefault( '100%' )
		        ->setConditions( 'use_motion_effect', '1' )
		        ->get();

		$control->addText( 'use_end' )
		        ->setLabel( esc_html__( 'End', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Space End Bottom', 'exfolio' ) )
		        ->setDefault( '0%' )
		        ->setConditions( 'use_motion_effect', '1' )
		        ->get();


		$control->addSwitcher( 'use_pin' )
		        ->setLabel( esc_html__( 'Pin', 'exfolio' ) )
		        ->setDescription( esc_html__( 'pin the trigger element while active', 'exfolio' ) )
		        ->setConditions( 'use_motion_effect', '1' )
		        ->get();

		$control->addSwitcher( 'use_markers' )
		        ->setLabel( esc_html__( 'Markers', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Adds markers that are helpful during development/troubleshooting. ', 'exfolio' ) )
		        ->setConditions( 'use_motion_effect', '1' )
		        ->get();


		$selection = [
			'x'       => esc_html__( 'Horizontal Scroll', 'exfolio' ),
			'y'       => esc_html__( 'Vertical Scroll', 'exfolio' ),
			'scaleX'  => esc_html__( 'Horizontal Scale', 'exfolio' ),
			'scaleY'  => esc_html__( 'Vertical Scale', 'exfolio' ),
			'scale'   => esc_html__( 'Vertical & Horizontal Scale', 'exfolio' ),
			'rotateX' => esc_html__( 'Horizontal Rotate', 'exfolio' ),
			'rotateY' => esc_html__( 'Vertical Rotate', 'exfolio' ),
			'rotate'  => esc_html__( 'Vertical & Horizontal Rotate', 'exfolio' ),
			'skewX'   => esc_html__( 'Horizontal Skew', 'exfolio' ),
			'skewY'   => esc_html__( 'Vertical Skew', 'exfolio' ),
			'skew'    => esc_html__( 'Vertical & Horizontal Skew', 'exfolio' ),
			'opacity' => esc_html__( 'Transparency', 'exfolio' ),
			'custom'  => esc_html__( 'Custom', 'exfolio' ),
		];


		foreach (
			[
				'from' => esc_html__( 'Animation From', 'exfolio' ),
				'to'   => esc_html__( 'Animation To', 'exfolio' )
			] as $key => $value
		):
			$control->startRepeater();


			$control->get_element_base()->add_control(
				'important_note',
				[
					'type'      => Controls_Manager::RAW_HTML,
					'raw'       => esc_html__( 'Use Value as Number and Optional Unit. like(10px , 10 , 10% , 100vw)',
						'exfolio' ),
					'condition' => [
						'key' => [ 'x', 'y' ]
					]
				]
			);

			$control->get_element_base()->add_control(
				'important_note_number',
				[
					'type'      => Controls_Manager::RAW_HTML,
					'raw'       => esc_html__( 'Use Number only', 'exfolio' ),
					'condition' => [
						'key' => [
							'scaleX',
							'scaleY',
							'scale',
							'rotate',
							'rotateX',
							'rotateY',
							'skew',
							'skewX',
							'skewY'
						]
					]
				]
			);

			$control->get_element_base()->add_control(
				'important_note_opacity',
				[
					'type'      => Controls_Manager::RAW_HTML,
					'raw'       => esc_html__( 'Use Number only from 0 to 1', 'exfolio' ),
					'condition' => [
						'key' => [ 'opacity' ]
					]
				]
			);

			$control->addSelect2( 'key', $selection )
			        ->setLabel( esc_html__( "Property", "exfolio" ) )
			        ->setLabelBlock()
			        ->setSeparatorBefore()
			        ->get();


			$control->addText( 'custom' )
			        ->setLabel( esc_html__( "Property Custom", 'exfolio' ) )
			        ->setConditions( 'key', 'custom' )
			        ->get();

			$control->addText( 'value' )
			        ->setLabel( esc_html__( "Value", 'exfolio' ) )
			        ->setDefault( 0 )
			        ->getResponsive();


			$control->endRepeater( 'items_' . $key )
			        ->setLabel( $value )
			        ->setTitle_field( 'key' )
			        ->setConditions( 'use_motion_effect', '1' )
			        ->setSeparatorBefore()
			        ->get();

		endforeach;


		$control->addSelect2( 'dsn_animation_layout', [
			'desktop' => esc_html__( 'Desktop', 'exfolio' ),
			'tablet'  => esc_html__( 'Tablet', 'exfolio' ),
			'mobile'  => esc_html__( 'Mobile', 'exfolio' ),
		] )
		        ->setMultiple()
		        ->setLabelBlock()
		        ->setDefault( array( 'desktop', 'tablet', 'mobile' ) )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( 'Apply Effects On', 'exfolio' ) )
		        ->get();

		$element->end_controls_section();

	}

	/** @var Controls_Stack $element */
	public function register_widgets_before_section( Controls_Stack $element ) {


		$control = new ExfolioControl ( $element );

		$is_section = $element->get_name() === 'section';
		$is_column  = $element->get_name() === 'column';


		$element->start_controls_section(
			'exfolio_section_space',
			[
				'tab'   => Controls_Manager::TAB_SETTINGS,
				'label' => __( 'exfolio Style', 'exfolio' ),
			]
		);


		/**
		 *  Add Padding & Margin in (Section , Column)
		 */
		$this->addSpaceSection( $element, $control );

		$element->add_control( 'hr_1', [ 'type' => Controls_Manager::DIVIDER ] );

		/**
		 * screen length
		 * $this->addLayout( $element, [ 'full-width' => esc_html__( 'Ful Width', 'exfolio' ) ] );
		 */
		$this->addLayout( $element );

		$element->add_control( 'hr_2', [ 'type' => Controls_Manager::DIVIDER ] );
		$this->addStyleBg( $element );


		$element->end_controls_section();


		if ( $is_column ) {
			$this->column_widget( $element );

		}


		if ( $is_section ) {
			$this->section_widget( $element, $control );
		}


	}


	/**
	 * @param $element  Controls_Stack.
	 * Margin And Padding Section
	 */
	private function addSpaceSection( Controls_Stack $element, ExfolioControl $control ) {

		$element->add_control(
			'dsn_col_margin',
			[
				'label' => __( 'Margin', 'exfolio' ),

				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'mt-section'     => [
						'title' => __( 'Margin Top', 'exfolio' ),
						'icon'  => 'eicon-v-align-top',
					],
					'section-margin' => [
						'title' => __( 'Margin Top & Bottom ', 'exfolio' ),
						'icon'  => 'eicon-v-align-middle',
					],

					'mb-section' => [
						'title' => __( 'Margin Bottom', 'exfolio' ),
						'icon'  => 'eicon-v-align-bottom',
					],

				],
				'default'      => '',
				'prefix_class' => '',
			]
		);

		$element->add_control(
			'dsn_col_padding',
			[
				'label' => __( 'Padding', 'exfolio' ),

				'type'         => Controls_Manager::CHOOSE,
				'options'      => [
					'pt-section'      => [
						'title' => __( 'Padding Top', 'exfolio' ),
						'icon'  => 'eicon-v-align-top',
					],
					'section-padding' => [
						'title' => __( 'Padding Top & Bottom', 'exfolio' ),
						'icon'  => 'eicon-v-align-middle',
					],

					'pb-section' => [
						'title' => __( 'Padding Bottom', 'exfolio' ),
						'icon'  => 'eicon-v-align-bottom',
					],

				],
				'default'      => '',
				'prefix_class' => '',
			]
		);

		if ( $element->get_name() !== 'column' ) {
			return;
		}


		$element->add_responsive_control(
			'_flex_dsn_order',
			[
				'label'                => esc_html__( 'Order', 'elementor' ),
				'type'                 => Controls_Manager::CHOOSE,
				'default'              => '',
				'options'              => [
					'start'  => [
						'title' => esc_html_x( 'Start', 'Flex Item Control', 'elementor' ),
						'icon'  => 'eicon-flex eicon-order-start',
					],
					'end'    => [
						'title' => esc_html_x( 'End', 'Flex Item Control', 'elementor' ),
						'icon'  => 'eicon-flex eicon-order-end',
					],
					'custom' => [
						'title' => esc_html__( 'Custom', 'elementor' ),
						'icon'  => 'eicon-ellipsis-v',
					],
				],
				'selectors_dictionary' => [
					'start'  => '-99999 /* order start hack */',
					'end'    => '99999 /* order end hack */',
					'custom' => '',
				],
				'selectors'            => [
					'{{WRAPPER}}' => 'order: {{VALUE}};',
				],

			]
		);
		$element->add_responsive_control(
			'_flex_dsn_order_custom',
			[
				'label'     => esc_html__( 'Custom Order', 'elementor' ),
				'type'      => Controls_Manager::NUMBER,
				'selectors' => [
					'{{WRAPPER}}' => 'order: {{VALUE}};',
				],
				'condition' => [
					'_flex_dsn_order' => 'custom',
				],
			]
		);


		$control->addSwitcher( 'dsn_custom_gap' )
		        ->setSeparatorBefore()
		        ->setReturn_value( "dsn-column-gap-custom" )
		        ->setLabel( esc_html__( "Gap Columns", "exfolio" ) )
		        ->setPrefix_class()
		        ->get();

		$control->addSwitcher( 'dsn_custom_gap_text' )
		        ->setLabel( esc_html__( "Use Manuel Custom Gaps", "exfolio" ) )
		        ->setConditions( 'dsn_custom_gap', '!=', '' )
		        ->get();


		$control->addText( 'dsn_col_number_col_text' )
		        ->setLabel( esc_html__( "Columns Template Gap", 'exfolio' ) )
		        ->setSelectors( '> div', 'grid-template-columns: {{VALUE}};' )
		        ->setConditions( 'dsn_custom_gap', '!=', '' )
		        ->setLabelBlock()
		        ->setConditions( 'dsn_custom_gap_text', '!=', '', 'and' )
		        ->getResponsive();

		$control->addNumberSlider( 'dsn_col_number_col', 0, 100, 1 )
		        ->setLabel( esc_html__( "Columns Template Gap", 'exfolio' ) )
		        ->setSelectors( '> div',
			        '-ms-grid-columns: (1fr)[{{SIZE}}];grid-template-columns: repeat({{SIZE}},1fr);' )
		        ->setConditions( 'dsn_custom_gap', '!=', '' )
		        ->setConditions( 'dsn_custom_gap_text', '!=', '1', 'and' )
		        ->getResponsive();

		$control->addNumberSlider( 'dsn_col_layout_gap', 0, 100, 1 )
		        ->setSizeUnits( [ 'px', '%', 'vw' ] )
		        ->setLabel( esc_html__( "Columns Gap", 'exfolio' ) )
		        ->setSelectors( '> div', 'grid-column-gap:{{SIZE}}{{UNIT}};' )
		        ->setConditions( 'dsn_custom_gap', '!=', '' )
		        ->getResponsive();

		$control->addNumberSlider( 'dsn_row_layout_gap', 0, 100, 1 )
		        ->setSizeUnits( [ 'px', '%', 'vh' ] )
		        ->setLabel( esc_html__( "Row Gap", 'exfolio' ) )
		        ->setConditions( 'dsn_custom_gap', '!=', '' )
		        ->setSelectors( '> div', 'grid-row-gap:{{SIZE}}{{UNIT}};' )
		        ->getResponsive();


	}

	/**
	 * @param $element
	 * @param array $args
	 */
	private function addLayout( $element, array $args = array() ) {


		$option = array_merge( [
			''                                  => __( 'Default', 'exfolio' ),
			'dsn-container'                     => __( 'Wide Page', 'exfolio' ),
			'container'                         => __( 'Container Page', 'exfolio' ),
			'dsn-container dsn-right-container' => __( 'Right Container Page', 'exfolio' ),
			'dsn-container dsn-left-container'  => __( 'Left Container Page', 'exfolio' ),
		], $args );

		$element->add_control(
			'dsn_width_layout',
			[
				'label'        => __( 'Width Layout', 'exfolio' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => '',
				'options'      => $option,
				'prefix_class' => '',
			]
		);

	}


	/**
	 * @param $element Controls_Stack
	 */
	private function addStyleBg( Controls_Stack $element ) {

		$control = new ExfolioControl ( $element );


		$control->addHidden( "dd_over", [
			'conditions' => [
				'relation' => 'or',
				'terms'    => [
					[
						'name'     => 'background_overlay_image[url]',
						'operator' => '!==',
						'value'    => '',
					]
				],
			]
		] )
		        ->setDefault( ' ' )
		        ->setPrefix_class( 'not-bg-dot ' )
		        ->get();

		$element->add_control(
			'background_dsn_style_ver',
			[
				'label'        => __( 'Version Background Section', 'exfolio' ),
				'type'         => Controls_Manager::SELECT,
				'default'      => '',
				'description'  => __( 'If you choose the wallpaper version, it is best to choose the type of background section',
					'exfolio' ),
				'label_block'  => true,
				'options'      => [
					''             => __( 'Default', 'exfolio' ),
					'v-light'      => __( 'Light', 'exfolio' ),
					'v-light-head' => __( 'Light (Static)', 'exfolio' ),
					'v-dark'       => __( 'Dark', 'exfolio' ),
					'v-dark-head'  => __( 'Dark  (Static)', 'exfolio' ),
				],
				'prefix_class' => '',

			]
		);

		$element->add_control(
			'background_dsn_style',
			[
				'label'       => __( 'Background Section', 'exfolio' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => 'background-transparent',
				'label_block' => true,

				'options'      => [
					'background-transparent' => __( 'Default', 'exfolio' ),
					'background-main'        => __( 'Background Main', 'exfolio' ),
					'background-section'     => __( 'Background Section', 'exfolio' ),
					'background-theme'       => __( 'Background Theme', 'exfolio' ),
					'background-heading'     => __( 'Background Heading', 'exfolio' ),
					'dsn-revere-bg'          => __( 'Revere Background', 'exfolio' ),
				],
				'prefix_class' => '',

			]
		);


		$control->addSwitcher( 'backdrop_filter' )
		        ->setLabel( esc_html__( "Backdrop Filter", 'exfolio' ) )
		        ->setReturn_value( 'backdrop-filter' )
		        ->setPrefix_class( 'dsn-background-inherit dsn-bg-before ' )
		        ->get();


		$element->add_control(
			'background_dsn_pattern',
			[
				'label'       => __( 'Background Pattern', 'exfolio' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'label_block' => true,
				'separator'   => "before",

				'options'      => [
					''          => __( 'Default', 'exfolio' ),
					'bg-square' => __( 'Square', 'exfolio' ),
					'bg-line'   => __( 'Line', 'exfolio' ),
				],
				'prefix_class' => 'dsn-bg-pattern ',
				'condition'    => [
					'backdrop_filter' => [ '' ],
				],

			]
		);

		$element->add_responsive_control(
			'dsn_overlay_backdrop',
			[
				'label'      => esc_html__( 'Backdrop Size', 'exfolio' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => 8,
				],
				'range'      => [
					'px' => [
						'max'  => 300,
						'step' => 1,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--backdrop-filter: {{SIZE}}px;',
				],
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'backdrop_filter',
							'operator' => '==',
							'value'    => 'backdrop-filter',
						],
					],
				],

			]
		);
		$element->add_responsive_control(
			'dsn_overlay_opacity',
			[
				'label'      => esc_html__( 'Opacity', 'elementor' ),
				'type'       => Controls_Manager::SLIDER,
				'default'    => [
					'size' => .3,
				],
				'range'      => [
					'px' => [
						'max'  => 1,
						'step' => 0.01,
					],
				],
				'selectors'  => [
					'{{WRAPPER}}' => '--bg-opacity: {{SIZE}};',
				],
				'conditions' => [
					'relation' => 'or',
					'terms'    => [
						[
							'name'     => 'background_dsn_pattern',
							'operator' => '!==',
							'value'    => '',
						]
						,
						[
							'name'     => 'backdrop_filter',
							'operator' => '==',
							'value'    => 'backdrop-filter',
						],
					],
				],

			]
		);
		$control->addSwitcher( 'offset_bg' )
		        ->setLabel( esc_html__( "Offset Background", "exfolio" ) )
		        ->setReturn_value( "bg-offset" )
		        ->setPrefix_class()
		        ->setConditions( 'backdrop_filter', '!=', 'backdrop-filter' )
		        ->get();

		$control->addText( 'bg_size' )
		        ->setLabel( esc_html__( "Background Size", "exfolio" ) )
		        ->setDefault( "130px 130px" )
		        ->setSelectors( '', '--bg-size:{{VALUE}}' )
		        ->setCondition( [
			        'background_dsn_pattern!' => [ '', 'bg-line' ],

		        ] )
		        ->getResponsive();

		$control->addSwitcher( 'dsn-fill-text-animate' )
		        ->setLabel( esc_html__( "Fill Text Animation", "exfolio" ) )
		        ->setSeparatorBefore()
		        ->setReturn_value( "dsn-fill" )
		        ->setPrefix_class()
		        ->get();


	}


	/** @var Controls_Stack $element */
	private function column_widget( Controls_Stack $element ) {

		$element->start_controls_section(
			'exfolio_section_animate',
			[
				'tab'   => Controls_Manager::TAB_SETTINGS,
				'label' => __( 'exfolio Animate', 'exfolio' ),
			]
		);

		$element->add_control( 'data_animation_section', [
			'label'        => __( 'Animate Section', 'exfolio' ),
			'type'         => Controls_Manager::SWITCHER,
			'description'  => __( 'you can turn on animation in the children element', 'exfolio' ),
			'return_value' => '1',
		] );


		$element->end_controls_section();

	}

	/**
	 * @param Controls_Stack $element
	 * @param ExfolioControl $control ;
	 */
	private function section_widget( Controls_Stack $element, ExfolioControl $control ) {

		$this->sectionBgControl( $element, $control );
	}


	/**
	 * @param Controls_Stack $element
	 * @param ExfolioControl $control ;
	 */
	private function sectionBgControl( Controls_Stack $element, ExfolioControl $control ) {


		$element->start_controls_section(
			'exfolio_section_bg',
			[
				'tab'   => Controls_Manager::TAB_STYLE,
				'label' => __( 'exfolio Parallax Background', 'exfolio' ),
			]
		);

		$control->addImage()
		        ->setDefault( [] )
		        ->get()
		        ->addImageSize()->getGroup();

		/**
		 * Overlay Bg
		 */
		$control->addPopover( 'opacity_overlay_popover' )
		        ->setLabel( __( "Background Overlay", 'elementor' ) )
		        ->setSeparator( "before" )
		        ->get();

		$element->start_popover();

		$control->addColor( 'color_overlay' )
		        ->setLabel( __( 'Color Overlay' ) )
		        ->get();

		$control->addNumberSlider( 'opacity_overlay', 0, 10, 1 )
		        ->setLabel( __( 'Opacity Overlay' ) )
		        ->setDefaultRange( 4 )
		        ->get();

		$element->end_popover();


		$control->addBlendMode( 'bland_overlay', '.img-box-parallax img' )
		        ->get();


		$control->addPopover( 'position_image' )
		        ->setLabel( __( 'Position Image', 'exfolio' ) )
		        ->get();
		$element->start_popover();

		$control->addNumber( 'position_image_position_x', 1, 100, 10 )
		        ->setLabel( __( 'Position X', 'exfolio' ) )
		        ->setDefault( 50 )
		        ->get();


		$control->addNumber( 'position_image_position_y', 1, 100, 10 )
		        ->setLabel( __( 'Position Y', 'exfolio' ) )
		        ->setDefault( 50 )
		        ->get();

		$element->end_popover();
		$this->getEntranceAnimationImage( $control );

		$element->end_controls_section();


	}


	/**
	 * @param $control ExfolioControl
	 */
	private function getEntranceAnimationImage( ExfolioControl $control ) {


		$control->addChoose( 'direction_animate_image' )
		        ->setLabel( __( "Direction", 'exfolio' ) )
		        ->setOptionChoose( 'has-opposite-direction', __( 'Up', 'exfolio' ), 'eicon-arrow-up' )
		        ->setOptionChoose( 'has-direction', __( 'Down', 'exfolio' ), 'eicon-arrow-down' )
		        ->setDefault( 'has-direction' )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSelect( 'animate_image_style', [
			''                 => __( "Default", 'exfolio' ),
			'has-bigger-scale' => __( "Scale Down", 'exfolio' ),
			'has-scale'        => __( "Scale Up", 'exfolio' ),
		] )
		        ->setLabel( __( "Entrance Animation Type", 'exfolio' ) )
		        ->setDefault( '' )->get();


		$control->getTriggerHock( 'animate_image_triggerhook' )
		        ->get();


		$control->addNumberSlider( 'speed_animation_image', 0, 100, 10 )
		        ->setDefaultRange( 30 )
		        ->setLabel( __( 'Speed', 'exfolio' ) )
		        ->get();

	}


}