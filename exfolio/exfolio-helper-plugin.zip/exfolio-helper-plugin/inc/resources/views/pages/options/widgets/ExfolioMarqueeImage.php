<?php

use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;
use inc\resources\views\pages\options\widgets\control\ExfolioLayout;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class ExfolioMarqueeImage extends ExfolioLayout {

	use Exfolio_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_move_image';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Section Marquee Scroll', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-gallery-justified';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'image', 'photo', 'gallery', 'justified', 'slider' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();


		$control->addHidden( 'dsn_over_hidden' )
		        ->setDefault( 'over-hidden' )
		        ->setPrefix_class()
		        ->get();

		$control->addPopover( 'pop_transition' )
		        ->setLabel( esc_html__( 'Translate', 'exfolio' ) )
		        ->get();

		$this->start_popover();

		$unit = [
			'size_units' => [ 'px', '%', 'em', 'rem', 'vw', 'custom' ],
			'range'      => [
				'%'  => [
					'min' => - 100,
					'max' => 100,
				],
				'px' => [
					'min' => - 1000,
					'max' => 1000,
				],
			],
		];

		$control->addNumberSlider( 't_x', 0, 100, 1, $unit )
		        ->setLabel( esc_html__( 'Image Position X', 'exfolio' ) )
		        ->setSelectors( '.section-move-image', '--tx: {{SIZE}}{{UNIT}}' )
		        ->getResponsive();

		$control->addNumberSlider( 't_y', 0, 100, 1, $unit )
		        ->setLabel( esc_html__( 'Image Position Y', 'exfolio' ) )
		        ->setSelectors( '.section-move-image', '--ty: {{SIZE}}{{UNIT}}' )
		        ->getResponsive();

		$this->end_popover();

		$control->addChoose( 'position_move' )
		        ->setLabel( __( 'Position', 'exfolio' ) )
		        ->setOptionChoose( 'move-left', esc_html__( 'Left', 'exfolio' ), 'eicon-h-align-left' )
		        ->setOptionChoose( '', esc_html__( 'Right', 'exfolio' ), 'eicon-h-align-right' )
		        ->setOptionChoose( 'move-top', esc_html__( 'Up', 'exfolio' ), ' eicon-v-align-top' )
		        ->setOptionChoose( 'move-bottom', esc_html__( 'Down', 'exfolio' ), ' eicon-v-align-bottom' )
		        ->setSeparatorAfter()
		        ->setDefault( '' )
		        ->get();


		$control->addSwitcher( 'dsn_equal_height', [
			'label'        => __( 'Enable Equal Height', 'blackdsn' ),
			'prefix_class' => 'dsn-equal-height ',
			'default'      => '',
		] )
		        ->setReturn_value( 'h-100' )
		        ->setCondition( [
			        'position_move' => [ 'move-top', 'move-bottom' ]
		        ] )
		        ->get();

		$control->addSlider( 'height_temp', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Height', 'elementor' ) )
		        ->setSelectors( '.dsn-marque', 'height: {{SIZE}}{{UNIT}};max-height: {{SIZE}}{{UNIT}};' )
		        ->setCondition( [
			        'position_move' => [ 'move-top', 'move-bottom' ]
		        ] )
		        ->setSeparatorAfter()
		        ->getResponsive();


		$control->addImageSize()
		        ->get();


		$control->startRepeater();

		$control->addImage()->get();
		$control->addTextarea( "title" )
		        ->setLabelBlock()
		        ->setLabel( esc_html__( 'Text', 'exfolio' ), true )
		        ->setSeparatorBefore()
		        ->setDynamicActive( true )
		        ->get();

		$control->endRepeater( 'items' )
		        ->setLabel( "Item", "exfolio" )
		        ->setTitle_field_WithImage( 'image', 'title' )
		        ->get();


		$this->end_controls_section();
		$this->styleSettings();
		$this->getScroll();

	}

	private function getScroll() {
		$control = $this->getControl();
		$this->start_controls_section(
			'scroll_section',
			[
				'label' => esc_html__( 'Motion Effect', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			]
		);


		$control->addNumberSlider( 'speed_scroll', 0, 10, 0.1 )
		        ->setLabel( esc_html__( 'Speed Scroll', 'exfolio' ) )
		        ->setDescription( esc_html__( 'smooth scrubbing', 'exfolio' ) )
		        ->setDefaultDesktopRange( 0.1 )
		        ->get();


		$control->addSwitcher( 'pin_scroll' )
		        ->setLabel( esc_html__( 'Pin', 'exfolio' ) )
		        ->setDescription( esc_html__( 'pin the trigger element while active', 'exfolio' ) )
		        ->get();

		$control->addText( 'start_scroll' )
		        ->setLabel( esc_html__( 'Offset Top Scroll', 'exfolio' ) )
		        ->setDefault( "100%" )
		        ->get();

		$control->addText( 'end_scroll' )
		        ->setLabel( esc_html__( 'Offset Bottom Scroll', 'exfolio' ) )
		        ->setDefault( "0%" )
		        ->get();


		$this->end_controls_section();

	}


	private function styleSettings() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Additional Options', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			]
		);

		$control->addNumberSlider( 'number_exfolio', 1, 9, 1 )
		        ->setLabel( esc_html__( "Columns", 'exfolio' ) )
		        ->setDefaultRange( 1 )
		        ->setSelectors( $this->style_layout, '--dsn-width-item: {{SIZE}};' )
		        ->getResponsive();

		$this->getGridSpace();


		$this->end_controls_section();

		$this->start_controls_section(
			'style_image_section_item',
			[
				'label' => esc_html__( 'Items', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background', 'exfolio' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background', 'exfolio' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-transparent' )
		        ->get();

		$control->addPaddingGroup( 'item_padding_service', '.grid-item' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.grid-item' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.grid-item' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.grid-item' )->getGroup();
		$this->end_controls_section();
		$this->__image_style_controller( $control );
		$this->__style_content_controller( $control );


	}

	private function __image_style_controller( ExfolioControl $control ) {
		$this->start_controls_section(
			'style_image_section',
			[
				'label' => esc_html__( 'Image', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$control->addSlider( 'height', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Height', 'elementor' ) )
		        ->setSelectors( '.grid-item img', 'height: {{SIZE}}{{UNIT}};max-height: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addBorderRadiusGroup('item_border_radius_image', '.grid-item img')
		        ->getResponsive();

		$control->addMarginGroup( 'item_margin_service', '.grid-item .image-item' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$this->end_controls_section();


		$this->__style_controller($control);
	}

	private function __style_content_controller( ExfolioControl $control ) {
		$args = array(
			'text-item' => esc_html__( 'Text', 'exfolio' ),
		);

		foreach ( $args as $id => $value ):

			$this->start_controls_section(
				'style_content_service_' . $id,
				[
					'label' => $value,
					'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);


			$control->addColor( 'color_content_' . $id )
			        ->setLabel( esc_html__( "Color", 'exfolio' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content_' . $id, '.' . $id )
			        ->getGroup();

			$control->addMarginGroup( 'item_padding_service_' . $id, '.' . $id )
			        ->setSeparator( "before" )
			        ->getResponsive();


			$control->addTextShadow( 'text_content_shadow_' . $id, '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;

	}


	public function __style_controller( ExfolioControl $control ) {


		$this->start_controls_section(
			'style_svg_section',
			[
				'label' => esc_html__( 'SVG', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$control->addSwitcher( 'use_stroke' )
		        ->setLabel( esc_html__( "Color Stroke", "ohixm" ) )
		        ->setReturn_value( "dsn-icon-stroke" )
		        ->setPrefix_class()
		        ->get();

		$control->addIconColor( 'icon_color_select' )
		        ->setPrefix_class()
		        ->setDefault( 'dsn-icon-theme-color' )
		        ->get();

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'elementor' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'icon_color_select' => ''
				],
				'selectors' => [
					'{{WRAPPER}} .dsn-icon i'                                    => 'color: {{VALUE}};',
					'{{WRAPPER}} .dsn-icon svg , {{WRAPPER}} .dsn-icon svg path' => 'fill: {{VALUE}};'
				],

			]
		);

		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-icon', '--dsn-icon-size: {{SIZE}}{{UNIT}};' )
		        ->setSeparatorBefore()
		        ->getResponsive();

		$control->addSlider( 'height_icon', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Height Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-icon', '--dsn-icon-height: {{SIZE}}{{UNIT}};' )
		        ->setSeparatorBefore()
		        ->getResponsive();

		$this->end_controls_section();

	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$control = $this->getShortCode();
		$this->addPrefixClassLayout( 'dsn-gallery', $control );
		echo exfolio_shortcode_render_group( 'move-section-image', array( 'widget-base' => $this ) );

	}


}
