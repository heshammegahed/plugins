<?php

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}




/**
 * Page Header in Elementor Document Settings
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'exfolio_document_settings_page_footer' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'exfolio_document_settings_page_footer' );
function exfolio_document_settings_page_footer( PageBase $page ) {

//	if ( exfolio_is_work() )
//		return;

	$control = new ExfolioControl( $page );

	$page->start_controls_section(
		'page_footer_section',
		array(
			'label' => esc_html__( 'Footer', 'exfolio' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		)
	);


	$control->addSwitcher( 'show_footer' )
	        ->setLabel( esc_html__( 'Show Footer', 'exfolio' ) )
	        ->setDefault( '1' )
	        ->get();

	$control->addSelect( 'dsn_footer_layout', [
		''                                  => __( 'Default', 'exfolio' ),
		'dsn-container'                     => __( 'Wide Page', 'exfolio' ),
		'container'                         => __( 'Container Page', 'exfolio' ),
		'dsn-container dsn-right-container' => __( 'Right Container Page', 'exfolio' ),
		'dsn-container dsn-left-container'  => __( 'Left Container Page', 'exfolio' ),
	] )
	        ->setDefault(  exfolio_is_work() ? 'container' :'' )
	        ->setLabel( __( 'Width Layout', 'exfolio' ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();

	$control->addSelect( 'dsn_footer_bg_ver', [
		''             => __( 'Default', 'exfolio' ),
		'v-light'      => __( 'Light', 'exfolio' ),
		'v-light-head' => __( 'Light (Static)', 'exfolio' ),
		'v-dark'       => __( 'Dark', 'exfolio' ),
		'v-dark-head'  => __( 'Dark  (Static)', 'exfolio' ),
	] )
	        ->setDefault( '' )
	        ->setLabelBlock()
	        ->setLabel( __( 'Version Background Section', 'exfolio' ) )
	        ->setDescription( __( 'If you choose the wallpaper version, it is best to choose the type of background section',
		        'exfolio' ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();

	$control->addSelect( 'dsn_footer_bg', [
		'background-transparent' => __( 'Default', 'exfolio' ),
		'background-main'        => __( 'Background Main', 'exfolio' ),
		'background-section'     => __( 'Background Section', 'exfolio' ),
		'background-theme'       => __( 'Background Theme', 'exfolio' ),
	] )
	        ->setLabelBlock()
	        ->setDefault( exfolio_is_work() ? 'background-transparent' : 'background-section' )
	        ->setLabel( __( 'Background Section', 'exfolio' ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();

	$control->addSelect( 'type_footer', [
		'default' => esc_html__( "Default", "exfolio" ),
		'custom'  => esc_html__( "Custom", "exfolio" )
	] )
	        ->setDefault( 'default' )
	        ->setSeparatorBefore()
	        ->setLabel( esc_html__( "Type Footer", "exfolio" ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();


	$control->addSelect2( 'choose_template_footer', exfolio_get_post_array( exfolio_footer_slug() ) )
	        ->setDefault( 'default' )
	        ->setLabelBlock()
	        ->setLabel( esc_html__( "Choose Template Footer", "exfolio" ) )
	        ->setConditions( 'show_footer', '===', '1' )
	        ->setConditions( 'type_footer', '===', 'custom', 'and' )
	        ->get();

	$page->end_controls_section();

}