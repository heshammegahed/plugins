<?php

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Page Header in Elementor Document Settings
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'exfolio_document_settings_page_header' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'exfolio_document_settings_page_header' );
function exfolio_document_settings_page_header( PageBase $page ) {

	$control = new ExfolioControl( $page );

	$page->start_controls_section(
		'page_header_section',
		array(
			'label' => esc_html__( 'Page Header', 'exfolio' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		)
	);


	$control->addSwitcher( 'bg_dotes' )
	        ->setLabel( esc_html__( 'Background Dots', 'exfolio' ) )
	        ->setReturn_value( "bg-dots" )
	        ->get();

	$control->addSwitcher( 'show_menu' )
	        ->setLabel( esc_html__( 'Show Menu', 'exfolio' ) )
	        ->setDefault( '1' )
	        ->get();




	$control->addSelect( 'menu_type', [
		'auto'          => esc_html__( "Auto", "exfolio" ),
		''              => esc_html__( "Classic", "exfolio" ),
		'dsn-hamburger' => esc_html__( "Hamburger", "exfolio" )
	] )
	        ->setDefault( "auto" )
	        ->setLabel( esc_html__( "Menu Type", "exfolio" ) )
	        ->setConditions( 'show_menu', '1' )
	        ->get();

	$menus           = wp_get_nav_menus();
	$option_menus    = [];
	$option_menus[0] = esc_html__( 'Default Menu', 'exfolio' );
	foreach ( $menus as $menu ) {
		$option_menus[ $menu->slug ] = $menu->name;
	}
	$control->addSelect( 'menu_id', $option_menus )
	        ->setDefault( 0 )
	        ->setLabel( esc_html__( "Menu", "exfolio" ) )
	        ->setConditions( 'show_menu', '1' )
	        ->get();


	$control->addSwitcher( 'show_header' )
	        ->setLabel( esc_html__( 'Show Header', 'exfolio' ) )
	        ->setDefault( '1' )
	        ->setSeparatorBefore()
	        ->get();

	$control->addSwitcher( 'show_social' )
	        ->setLabel( esc_html__( 'Show Social', 'exfolio' ) )
	        ->get();

	$control->addSelect( 'image_type', [
		'dsn-full-header'              => esc_html__( "Full Width", "exfolio" ),
		''                             => esc_html__( "Padding", "exfolio" ),
		'header-normal header-project' => esc_html__( "Default length", "exfolio" ),
	] )
	        ->setDefault( 'dsn-full-header' )
	        ->setLabel( esc_html__( "Image Type", "exfolio" ) )
	        ->setConditions( 'show_header', '1' )
	        ->get();


	$control->addSwitcher( 'show_box_shadow' )
	        ->setLabel( esc_html__( "Show Box Shadow", "exfolio" ) )
	        ->setConditions( 'show_header', '1' )
	        ->setDefault( '' )
	        ->setReturn_value( 'show-box-shadow' )
	        ->get();


	$control->addImageSize()
	        ->setDefault( '' )
	        ->setDefault( 'full' )
	        ->setConditions( 'show_header', '1' )
	        ->get();

	$control->addSwitcher( 'show_background_video' )
	        ->setLabel( esc_html__( 'Feature Video', 'exfolio' ) )
	        ->setConditions( 'show_header', '1' )
	        ->get();

	$control->addText( 'dsn_video_link' )
	        ->setLabel( esc_html__( 'Video Link', 'exfolio' ) )
	        ->setLabelBlock()
	        ->setCondition( [
		        'show_background_video' => '1',
		        'show_header'           => '1',
	        ] )
	        ->get();


	$control->addNumberSlider( 'opacity_overlay', 1, 10, 1 )
	        ->setLabel( esc_html__( 'Opacity Overlay', 'exfolio' ) )
	        ->setDefaultRange( 4 )
	        ->setConditions( 'show_header', '1' )
	        ->get();

	$control->addNumberSlider( 'background_option_position_image_position_x', 0, 100, 1 )
	        ->setLabel( esc_html__( 'Image Position X', 'exfolio' ) )
	        ->setDefaultRange( 50 )
	        ->setConditions( 'show_header', '1' )
	        ->setSelectors( '#dsn_header #hero_image .transform-3d , .bg-blur-head img',
		        'object-position:{{SIZE}}% {{background_option_position_image_position_y.SIZE}}%' )
	        ->getResponsive();

	$control->addNumberSlider( 'background_option_position_image_position_y', 0, 100, 1 )
	        ->setLabel( esc_html__( 'Image Position Y', 'exfolio' ) )
	        ->setDefaultRange( 50 )
	        ->setConditions( 'show_header', '1' )
	        ->setSelectors( '#dsn_header #hero_image .transform-3d , .bg-blur-head img',
		        'object-position:{{background_option_position_image_position_x.SIZE}}% {{SIZE}}%' )
	        ->getResponsive();


	$page->end_controls_section();

}