<?php

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
};

/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class  ExfolioPostDate extends Widget_Base {

	use Exfolio_Widget_Base;

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_post_date';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return __( 'exfolio Post Date', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-date';

	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'archive', 'post', 'date' ] );
	}


	protected function register_controls() {

		$control = $this->getControl();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'type',
			[
				'label'   => esc_html__( 'Type', 'exfolio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'post_date_gmt'     => esc_html__( 'Post Published', 'exfolio' ),
					'post_modified_gmt' => esc_html__( 'Post Modified', 'exfolio' ),
				],
				'default' => 'post_date_gmt',
			]
		);

		$this->add_control(
			'format',
			[
				'label'   => esc_html__( 'Format', 'exfolio' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'default' => esc_html__( 'Default', 'exfolio' ),
					'F j, Y'  => gmdate( 'F j, Y' ),
					'j M, Y'  => gmdate( 'j M, Y' ),
					'Y-m-d'   => gmdate( 'Y-m-d' ),
					'm/d/Y'   => gmdate( 'm/d/Y' ),
					'd/m/Y'   => gmdate( 'd/m/Y' ),
					'human'   => esc_html__( 'Human Readable', 'exfolio' ),
					'custom'  => esc_html__( 'Custom', 'exfolio' ),
				],
				'default' => 'default',
			]
		);


		$this->add_control(
			'custom_format',
			[
				'label'       => esc_html__( 'Custom Format', 'exfolio' ),
				'default'     => '',
				'description' => sprintf( '<a href="https://go.elementor.com/wordpress-date-time/" target="_blank">%s</a>', esc_html__( 'Documentation on date and time formatting', 'exfolio' ) ),
				'condition'   => [
					'format' => 'custom',
				],
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {


		$shortcode = new exfolioShortCode( array( 'widget-base' => $this ) );
		$shortcode->mergeBlock( inc\exfolio_get_global_setting()->get_data_reference() );
		$meta_data = $shortcode->getVal( 'meta_data', array( 'date' ) );
		$show_date = in_array( 'date', $meta_data );



		if ( ! $show_date ) {
			return;
		}


		$date_type = $shortcode->getVal( 'type' );
		$format    = $shortcode->getVal( 'format' );


		if ( 'human' === $format ) {
			/* translators: %s: Human readable date/time. */
			$value = sprintf( esc_html__( '%s ago', 'elementor-pro' ), human_time_diff( strtotime( get_post()->{$date_type} ) ) );
		} else {
			switch ( $format ) {
				case 'default':
					$date_format = '';
					break;
				case 'custom':
					$date_format = $this->get_settings( 'custom_format' );
					break;
				default:
					$date_format = $format;
					break;
			}

			if ( 'post_date_gmt' === $date_type ) {
				$value = get_the_date( $date_format );
			} else {
				$value = get_the_modified_date( $date_format );
			}
		}

		printf( '<span class="post-date">%1$s</span>', wp_kses_post( $value ) );


//		echo exfolio_shortcode_render_group( 'custom_post/cat', array( 'widget-base' => $this ) );

	}


}
