<?php

namespace inc\resources\views\pages\options\widgets\posts\slider;

use Elementor\Controls_Manager;


trait  SliderControl {


	public function registerSlider() {
		$control = $this->getControl();

		$control->addSelect( 'layout_style', [
			''                    => esc_html__( 'Full', 'exfolio' ),
			'dsn-section-padding' => esc_html__( 'Padding', 'exfolio' )

		] )
		        ->setDefault( 'dsn-section-padding' )
		        ->setPrefix_class()
		        ->setLabel( esc_html__( 'Layout', 'exfolio' ) )
		        ->get();


		$control->addHidden( '_background_dark' )
		        ->setDefault( 'v-dark-head' )
		        ->setPrefix_class()
		        ->get();


		$control->addSwitcher( 'box_shadow_head' )
		        ->setLabel( esc_attr__( 'Use Shadow Head', 'exfolio' ) )
		        ->setReturn_value( 'box-shadow-head' )
		        ->setPrefix_class()
		        ->get();


		$control->addSwitcher( 'dsn_views' )
		        ->setLabel( esc_html__( "Custom Slider", 'exfolio' ) )
		        ->get();


		$control->addNumberSlider( 'blog_pages_show_at_most', - 1, 100, 1 )
		        ->setDefaultRange( get_option( 'posts_per_page' ) )
		        ->setLabel( esc_html__( 'blog_pages_show_at_most', 'exfolio' ) )
		        ->setConditions( 'dsn_views', '' )
		        ->get();

		$control->addText( 'text_link' )
		        ->setLabel( esc_html__( "Text Link ", 'exfolio' ), true )
		        ->setDefault( esc_html__( "VIEW CASE", 'exfolio' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'dsn_views', '' )
		        ->get();

	}


	public function getSliderCustom() {
		$control = $this->getControl();
		$control->startRepeater();
		$control->addImage()->get();
		$control->addImageSize()->get();
		$this->getOverlay();

		$control->addText( 'post_title' )
		        ->setLabel( esc_html__( "title", 'exfolio' ), true )
		        ->setDynamicActive( true )
		        ->setLabelBlock()
		        ->setSeparator( "before" )
		        ->setDefault( esc_html__( "Enter Your Title", 'exfolio' ) )
		        ->get();

		$control->addText( 'subtitle' )
		        ->setLabel( esc_html__( "Subtitle", 'exfolio' ), true )
		        ->setDynamicActive( true )
		        ->setLabelBlock()
		        ->get();


		$control->addTextarea( 'description_header' )
		        ->setLabel( esc_html__( "Description", 'exfolio' ), true )
		        ->setDynamicActive( true )
		        ->setDefault( "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias maiores molestias nisi officiis perferendis possimus qui voluptates. Accusantium beatae consequuntur dolorem nam quod reiciendis, tempore!" )
		        ->setLabelBlock()
		        ->get();


		$control->addLink( 'link1' )
		        ->setLabel( esc_html__( 'URL 1', 'exfolio' ) )
		        ->setPlaceholder( esc_html__( "www.your-site.com", 'exfolio' ) )
		        ->setDynamicActive( true )
		        ->setSeparator( "before" )
		        ->get();

		$control->addText( "text_link1" )
		        ->setLabel( esc_html__( "Text Link 1", 'exfolio' ), true )
		        ->setDefault( esc_html__( "VIEW CASE", 'exfolio' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'link1[url]', '!=', '' )
		        ->get();

		$control->addLink( 'link2' )
		        ->setLabel( esc_html__( 'URL 2', 'exfolio' ) )
		        ->setPlaceholder( esc_html__( "www.your-site.com", 'exfolio' ) )
		        ->setDynamicActive( true )
		        ->setSeparator( "before" )
		        ->get();

		$control->addText( "text_link2" )
		        ->setLabel( esc_html__( "Text Link 2", 'exfolio' ), true )
		        ->setDefault( esc_html__( "VIEW CASE", 'exfolio' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'link2[url]', '!=', '' )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( esc_html__( "Items", 'exfolio' ) )
		        ->setConditions( 'dsn_views', '1' )
		        ->setSeparator( "before" )
		        ->setTitle_field( 'post_title' )
		        ->get();


	}

	/**
	 * Get Control Over
	 * Use In Child Class
	 *
	 * @param string $img_bland
	 */
	protected function getOverlay( $img_bland = '.img-box-parallax img' ) {
		$control = $this->getControl();


		$control->addColor( 'color_overlay' )
		        ->setLabel( __( 'Color Overlay' ) )
		        ->setSeparator( "before" )
		        ->get();

		$control->addNumberSlider( 'opacity_overlay', 0, 10, 1 )
		        ->setLabel( __( 'Opacity Overlay' ) )
		        ->setDefaultRange( 0 )
		        ->get();


		$control->addBlendMode( 'bland_overlay', $img_bland )
		        ->get();

	}


	protected function displayContent() {

		$control = $this->getControl();

		$this->start_controls_section(
			'content_display_content_area',
			[
				'label' => esc_html__( 'Display Content Area', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addSelect2( 'show_title_area', [
			'link_with_title'  => esc_html__( 'Link With Title', 'exfolio' ),
			'show_sub_title'   => esc_html__( 'SubTitle', 'exfolio' ),
			'show_category'    => esc_html__( 'Category', 'exfolio' ),
			'show_description' => esc_html__( 'Description', 'exfolio' ),
			'show_Button1'     => esc_html__( 'Button 1', 'exfolio' ),
			'show_Button2'     => esc_html__( 'Button 2', 'exfolio' )
		] )
		        ->setMultiple()
		        ->setLabelBlock()
		        ->setDefault( array( 'link_with_title', 'show_category' ) )
		        ->setLabel( esc_html__( 'Display Content Area', 'exfolio' ) )
		        ->get();


		$control->addChoose( 'direction_cat' )
		        ->setLabel( esc_html__( 'Direction Category', 'exfolio' ) )
		        ->setOptionChoose( '', __( 'Before Title', 'exfolio' ), 'eicon-v-align-bottom' )
		        ->setOptionChoose( '1', __( 'After Title', 'exfolio' ), 'eicon-v-align-top' )
		        ->setCondition( [ 'show_title_area' => 'show_category' ] )
		        ->setSeparator( "before" )
		        ->setDefault( '1' )
		        ->get();

		$control->addSwitcher( 'use_cat_border' )
		        ->setLabel( esc_html__( 'Use Border Category', 'exfolio' ) )
		        ->get();

		$control->addSwitcher( 'optimize-img' )
		        ->setReturn_value( "hide-bg" )
		        ->setLabel( esc_html__( 'Optimize Image', 'exfolio' ) )
		        ->get();

		$control->addNumberSlider( 'excerpt_length', 15, 300, 5 )
		        ->setLabel( esc_html__( 'Excerpt length', 'exfolio' ) )
		        ->setDefaultRange( 25 )
		        ->setSeparator( "before" )
		        ->setCondition( [ 'show_title_area' => 'show_description' ] )
		        ->get();

		$this->start_controls_tabs( 'tab_button' );

		foreach ( [ 'tab_btn-1', 'tab_btn-2' ] as $index => $btn ):

			$key = $index + 1;
			$this->start_controls_tab( $btn . '_' . $key, [
				'label'     => esc_html__( "Button" ) . ' ' . $key,
				'condition' => [ 'show_title_area' => 'show_Button' . $key ],
			] );

			$control->addSwitcher( 'with_line_' . $key )
			        ->setLabel( esc_html__( 'With Line', 'exfolio' ) )
			        ->setReturn_value( 'line-shape line-shape-before' )
			        ->get();

			$control->addSelect( 'bg_ver_button-' . $key, $control->getOptionVerBackground() )
			        ->setLabel( esc_html__( 'Version Button ', 'exfolio' ) )
			        ->setCondition( [ 'show_title_area' => 'show_Button' . $key ] )
			        ->get();

			$control->addSelect( 'bg_button-' . $key, $control->getOptionBackground() )
			        ->setLabel( esc_html__( 'BG Button', 'exfolio' ) )
			        ->setDefault( 'background-transparent' )
			        ->setCondition( [ 'show_title_area' => 'show_Button' . $key ] )
			        ->get();


			$this->end_controls_tab();

		endforeach;


		$this->end_controls_tabs();


		$control->addSelect( 'style_button_bg', $control->getStyleButton() )
		        ->setLabel( esc_html__( 'Background button 1', 'exfolio' ) )
		        ->setDefault( 'btn-2' )
		        ->setSeparator( "before" )
		        ->setCondition( [ 'show_title_area' => 'show_Button' ] )
		        ->get();


		$this->end_controls_section();
	}

	protected function query() {
		$control = $this->getControl();

		/**
		 * Query
		 */
		$this->start_controls_section(
			'content_query',
			[
				'label' => esc_html__( 'Query', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addNumber( 'offset', 0, null, 1 )
		        ->setDefault( 0 )
		        ->setLabel( esc_html__( 'Offset', 'exfolio' ), true )
		        ->setDescription( esc_html__( 'offset Display posts from the 4th one', 'exfolio' ) )
		        ->get();

		$control->addSelect( 'orderby', [
			'none'       => esc_html__( 'No order', 'exfolio' ),
			'ID'         => esc_html__( 'post id', 'exfolio' ),
			'author'     => esc_html__( 'author', 'exfolio' ),
			'menu_order' => esc_html__( 'Menu Order', 'exfolio' ),
			'title'      => esc_html__( 'title', 'exfolio' ),
			'name'       => esc_html__( 'name', 'exfolio' ),
			'date'       => esc_html__( 'date', 'exfolio' ),
			'modified'   => esc_html__( 'last modified date', 'exfolio' ),
			'rand'       => esc_html__( 'Random order', 'exfolio' ),
		] )
		        ->setLabel( esc_html__( 'Order By', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Sort retrieved posts.', 'exfolio' ) )
		        ->setDefault( "date" )
		        ->get();

		$control->addSelect( 'order', [
			'DESC' => esc_html__( 'descending', 'exfolio' ),
			'ASC'  => esc_html__( 'ascending', 'exfolio' )
		] )
		        ->setLabel( esc_html__( 'Order', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Designates the ascending or descending order of the ‘orderby‘ parameter', 'exfolio' ) )
		        ->setDefault( "DESC" )
		        ->get();

	}

	protected function _content_pagination_Navigation() {
		$control = $this->getControl();

		$this->start_controls_section(
			'paginate_swiper_section',
			[
				'label' => esc_html__( 'Pagination & Navigation', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$control->addSwitcher( 'show_nav_slider' )
		        ->setLabel( esc_html__( "Navigation slider", 'exfolio' ) )
		        ->get();

		$control->addText( 'text_next' )
		        ->setLabel( esc_html__( 'Next Text', 'exfolio' ) )
		        ->setDefault( 'NEXT' )
		        ->setConditions( 'show_nav_slider', '1' )
		        ->get();

		$control->addText( 'text_prev' )
		        ->setLabel( esc_html__( 'Next Text', 'exfolio' ) )
		        ->setDefault( 'PREV' )
		        ->setConditions( 'show_nav_slider', '1' )
		        ->get();


		$control->addSwitcher( 'show_navigation' )
		        ->setSeparatorBefore()
		        ->setLabel( esc_html__( "Pagination Bullet", 'exfolio' ) )
		        ->get();


		$control->addSwitcher( 'show_pagination' )
		        ->setLabel( esc_html__( 'Show Number', 'exfolio' ) )
		        ->get();


		$control->getJustifyContent( 'justify_content', '.control-nav' )
		        ->setDefault( 'space-between' )
		        ->getResponsive();


		$this->end_controls_section();

	}


	protected function getStyleSliderOption() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_swiper_slides',
			[
				'label' => esc_html__( 'slides', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->getAlign()
		        ->setDefault( "left" )
		        ->getResponsive();

		$control->getAlignmentItem( 'alignment_content_slider', '.slide-content' )
		        ->setLabel( esc_html__( "Alignment Content", 'exfolio' ) )
		        ->setDefault( '' )
		        ->getResponsive();


		$control->getJustifyContent( 'justify_content_slider_cat', '.head-meta , {{WRAPPER}} .slide-content' )
		        ->setLabel( esc_html__( "justify Content", 'exfolio' ) )
		        ->setDefault( '' )
		        ->getResponsive();


		$control->addSwitcher( 'add_circle' )
		        ->setLabel( esc_html__( 'Show Circle', 'exfolio' ) )
		        ->setReturn_value( 'dsn-slider-width-circle' )
		        ->setSeparatorBefore()
		        ->setPrefix_class()
		        ->get();

		$control->addSwitcher( 'use_parallax_circle' )
		        ->setLabel( esc_html__( 'Parallax With Scroll', 'exfolio' ) )
		        ->setReturn_value( 'dsn-header-animation' )
		        ->setPrefix_class()
		        ->get();


		$this->end_controls_section();
		$this->getStyleContent();
	}


	private function getStyleContent() {
		$control = $this->getControl();


		$args = array(
			'title'       => esc_html__( 'Title', 'exfolio' ),
			'description' => esc_html__( 'Description', 'exfolio' ),
			'metas span'  => esc_html__( 'Metas', 'exfolio' ),
			'dsn-btn'     => esc_html__( 'SubTitle', 'exfolio' ),
		);

		foreach ( $args as $id => $value ):

			$this->start_controls_section(
				'style_content_slides-' . $id,
				[
					'label' => $value,
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);


			$control->addColor( 'color_content-' . $id )
			        ->setLabel( esc_html__( "Color", 'exfolio' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content-' . sanitize_title( $id ), '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;


	}

}