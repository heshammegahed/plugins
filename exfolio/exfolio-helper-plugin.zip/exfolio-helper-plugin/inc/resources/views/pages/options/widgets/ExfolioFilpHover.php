<?php

use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class ExfolioFilpHover extends Widget_Base {

	use Exfolio_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_flip_hover';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return __( 'Exfolio Flip Hover', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-favorite';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'hover', 'grid', 'images' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();

		$control->addImageSize()->get();
		$control->startRepeater();
		$control->addGallery()
		        ->setLabel( esc_html__( "Gallery", 'exfolio' ) )
		        ->get();
		$control->endRepeater( 'items' )
		        ->setLabel( esc_html__( 'Grid', 'exfolio' ) )
		        ->get();


		$this->end_controls_section();

		$this->styleTab();
		$this->settingTabs();

	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addSelect( 'bg_ver_icon', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background', 'exfolio' ) )
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_icon', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Icon', 'exfolio' ) )
		        ->setDefault( 'background-transparent' )
		        ->get();


		$control->addSlider( 'width_section', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Height Section', 'exfolio' ) )
		        ->setSelectors( '.dsn-flip-animation', 'height: {{SIZE}}{{UNIT}};' )
		        ->setSeparatorBefore()
		        ->getResponsive();


		$control->addSlider( 'height_section', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Max Height Section', 'exfolio' ) )
		        ->setSelectors( '', 'max-height: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Width Image', 'exfolio' ) )
		        ->setSelectors( '', '--width-a: {{SIZE}}{{UNIT}};' )
		        ->setSeparatorBefore()
		        ->getResponsive();

		$control->addSlider( 'height_icon', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Height Image', 'exfolio' ) )
		        ->setSelectors( '', '--height-a: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addSelect( 'object-fit', [
			''        => esc_html__( 'Default', 'elementor' ),
			'fill'    => esc_html__( 'Fill', 'elementor' ),
			'cover'   => esc_html__( 'Cover', 'elementor' ),
			'contain' => esc_html__( 'Contain', 'elementor' ),
		], [
			'label' => esc_html__( 'Object Fit', 'elementor' ),

			'options'   => [
				''        => esc_html__( 'Default', 'elementor' ),
				'fill'    => esc_html__( 'Fill', 'elementor' ),
				'cover'   => esc_html__( 'Cover', 'elementor' ),
				'contain' => esc_html__( 'Contain', 'elementor' ),
			],
			'default'   => '',
			'selectors' => [
				'{{WRAPPER}} img' => 'object-fit: {{VALUE}};',
			],
		] )->setSeparator( "before" )->get();


		$control->addBlendMode( 'bland_overlay', 'img' )
		        ->get();


		$this->end_popover();


		$control->addPaddingGroup( 'item_padding_icon', '.row__item-card' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius_icon', '.row__item-card' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style_icon', '.row__item-card' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow_icon', '.row__item-card' )->getGroup();


		$this->end_controls_section();

	}

	private function settingTabs() {
		$control = $this->getControl();
		$this->start_controls_section(
			'setting_section',
			[
				'label' => esc_html__( 'Options', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);


		$control->addText( 'target_element' )
		        ->setLabel( esc_html__( 'Target', 'exfolio' ) )
		        ->get();

		$control->addNumber( 'speed', 0.5, 100, 0.1 )
		        ->setDefault( 30 )
		        ->setLabel( esc_html__( 'Speed', 'exfolio' ) )->get();


		$control->addNumberSlider( 'rotate_', - 360, 360, 1 )
		        ->setLabel( esc_html__( 'Rotate', 'exfolio' ) )
		        ->setSelectors( '.dsn-flip-animation', 'transform: rotate({{SIZE}}deg);' )
		        ->getResponsive();

		$control->addPopover( 'pop_transition' )
		        ->setLabel( esc_html__( 'Translate', 'exfolio' ) )
		        ->get();

		$this->start_popover();

		$control->addSwitcher( 'x' )
		        ->setLabel( esc_html__( 'TranslateX', 'exfolio' ) )
		        ->setDefault( '1' )
		        ->get();
		$control->addSwitcher( 'y' )
		        ->setLabel( esc_html__( 'TranslateY', 'exfolio' ) )
		        ->get();
		$this->end_popover();


		$control->addPopover( 'pop_skew' )
		        ->setLabel( esc_html__( 'Skew', 'exfolio' ) )
		        ->get();

		$this->start_popover();

		$control->addSwitcher( 'skewx' )
		        ->setLabel( esc_html__( 'skewX', 'exfolio' ) )
		        ->setDefault( '1' )
		        ->get();


		$control->addSwitcher( 'skewy' )
		        ->setLabel( esc_html__( 'skewY', 'exfolio' ) )
		        ->get();
		$this->end_popover();

		$control->addSwitcher( 'scale' )
		        ->setLabel( esc_html__( 'Scale', 'exfolio' ) )
		        ->get();

		$control->addSwitcher( 'contrast' )
		        ->setLabel( esc_html__( 'Contrast', 'exfolio' ) )
		        ->setDefault( '1' )
		        ->get();
		$control->addSwitcher( 'brightness' )
		        ->setLabel( esc_html__( 'Brightness', 'exfolio' ) )
		        ->setDefault( '1' )
		        ->get();
		$this->end_controls_section();
	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		echo exfolio_shortcode_render_group( 'flip-hover', array( 'widget-base' => $this ) );

	}


}
