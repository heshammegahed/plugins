<?php

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Page Header in Elementor Document Settings
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'exfolio_document_settings_page_layout' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'exfolio_document_settings_page_layout' );
function exfolio_document_settings_page_layout( PageBase $page ) {

	$control = new ExfolioControl( $page );

	$page->start_controls_section(
		'page_layout_section',
		array(
			'label' => esc_html__( 'Layout', 'exfolio' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		)
	);

	$control->addSelect( 'page_layout', [
		''              => esc_html__( "Full Width", "exfolio" ),
		'container'     => esc_html__( "Container", "exfolio" ),
		'dsn-container' => esc_html__( "Container Fluid", "exfolio" ),
	] )
	        ->setDefault( ( exfolio_is_work() || exfolio_is_built_with_elementor() ) ? '' : 'container' )
	        ->setLabel( esc_html__( "Page Layout", "exfolio" ) )
	        ->get();


	$control->addSelect( 'global_background_color', [
		"auto"    => esc_html__( "Auto", "exfolio" ),
		'v-dark'  => esc_html__( "Dark", "exfolio" ),
		'v-light' => esc_html__( "Light", "exfolio" ),
	] )
	        ->setDefault( "auto" )
	        ->setLabel( esc_html__( "Background Color", "exfolio" ) )
	        ->get();


	$control->addSwitcher( 'show_cart' )
	        ->setLabel( esc_attr__( 'Show Cart', 'exfolio' ) )
	        ->setLabel_on( esc_attr__( 'Show', 'exfolio' ) )
	        ->setLabel_off( esc_attr__( 'Hide', 'exfolio' ) )
	        ->get();

	$control->addSwitcher( 'show_sidebar' )
	        ->setReturn_value( 'show' )
	        ->setLabel( esc_attr__( 'Show Sidebar', 'exfolio' ) )
	        ->setLabel_on( esc_attr__( 'Show', 'exfolio' ) )
	        ->setLabel_off( esc_attr__( 'Hide', 'exfolio' ) )
	        ->setDefault( 'show' )
	        ->get();

	$control->addSelect( 'choose_sidebar', [
		"blog-sidebar-1" => esc_html__( "Blog Sidebar", "exfolio" ),
		'wc-sidebar-1'   => esc_html__( "Woocommerce Sidebar", "exfolio" )
	] )
	        ->setDefault( "auto" )
	        ->setLabel( esc_html__( "Choose Sidebar", "exfolio" ) )
	        ->setConditions( 'show_sidebar', 'show' )
	        ->setDefault( 'blog-sidebar-1' )
	        ->get();

	$page->end_controls_section();

}