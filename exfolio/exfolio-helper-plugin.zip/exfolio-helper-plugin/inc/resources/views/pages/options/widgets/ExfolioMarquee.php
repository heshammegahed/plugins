<?php

use Elementor\Controls_Manager;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class ExfolioMarquee extends \Elementor\Widget_Base {

	use \inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_marquee';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'exfolio Marquee', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-accordion';

	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'marquee' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Accordion', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();


		$control->addTextarea( 'description' )
		        ->setLabel( esc_html__( "Description", 'exfolio' ) )
		        ->setDefault( 'Get In touch <span class="icon">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z" fill="currentColor"></path>
                                        </svg>
                                    </span>' )
		        ->setTitle_field( 'title' )
		        ->setDynamicActive( true )
		        ->get();

		$control->addHtmlTag()
		        ->setSeparator( "before" )
		        ->get();

		$control->addSize()
		        ->setDefault( 'sm-title-block' )
		        ->get();


		$this->end_controls_section();

		$this->styleTab();

	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'exfolio' ),
				'tab'   => \Elementor\Controls_Manager::TAB_SETTINGS,
			]
		);


		$control->addSwitcher( "allowCss3Support" )
		        ->setLabel( esc_html__( "Allow CSS 3 Support", 'exfolio' ) )
		        ->setDescription( esc_html__( "If you wish to always animate using jQuery", 'exfolio' ) )
		        ->setDefault( "1" )
		        ->get();

		$control->addSelect( "direction", [
			"left"  => esc_html__( "Left", 'exfolio' ),
			"right" => esc_html__( "Right", 'exfolio' ),
			"up"    => esc_html__( "Up", 'exfolio' ),
			"down"  => esc_html__( "Down", 'exfolio' )
		] )
		        ->setLabel( esc_html__( "Direction", 'exfolio' ) )
		        ->setDefault( "left" )
		        ->get();

		$control->addNumber( "speed", 0, false, 10 )
		        ->setLabel( esc_html__( "Speed", 'exfolio' ) )
		        ->setDefault( 0 )
		        ->get();

		$control->addNumber( "duration", 0, false, 100 )
		        ->setLabel( esc_html__( "Duration", 'exfolio' ) )
		        ->setDescription( esc_html__( "duration in milliseconds of the marquee in milliseconds", "exfolio" ) )
		        ->setDefault( 5000 )
		        ->get();

		$control->addNumber( "gap", 0, false, 10 )
		        ->setLabel( esc_html__( "gap", 'exfolio' ) )
		        ->setDescription( esc_html__( "gap in pixels between the tickers", "exfolio" ) )
		        ->setDefault( 20 )
		        ->get();


		$control->addNumber( "delayBeforeStart", 0, false, 10 )
		        ->setLabel( esc_html__( "Delay Before Start", 'exfolio' ) )
		        ->setDescription( esc_html__( "pause time before the next animation turn in milliseconds", 'exfolio' ) )
		        ->setDefault( 1000 )
		        ->get();

		$control->addSwitcher( "startVisible" )
		        ->setLabel( esc_html__( "Start Visible", 'exfolio' ) )
		        ->setDescription( esc_html__( "the marquee is visible initially positioned next to the border towards it will be moving", 'exfolio' ) )
		        ->setDefault( "1" )
		        ->get();

		$control->addSwitcher( "duplicated" )
		        ->setLabel( esc_html__( "Duplicated", 'exfolio' ) )
		        ->setDefault( "1" )
		        ->setDescription( esc_html__( "true or false - should the marquee be duplicated to show an effect of continues flow", 'exfolio' ) )
		        ->get();

		$control->addNumber( "duplicatedNumber", 0, false, 1 )
		        ->setLabel( esc_html__( "Duplicated Number", 'exfolio' ) )
		        ->setConditions( "duplicated", "1" )
		        ->setDefault( 1 )
		        ->get();

		$control->addSwitcher( "pauseOnHover" )
		        ->setLabel( esc_html__( "Pause On Hover", 'exfolio' ) )
		        ->setDescription( esc_html__( "on hover pause the marquee", 'exfolio' ) )
		        ->get();

		$control->addSwitcher( "pauseOnCycle" )
		        ->setLabel( esc_html__( "Pause On Cycle", 'exfolio' ) )
		        ->setDescription( esc_html__( "on cycle pause the marquee", 'exfolio' ) )
		        ->get();


		$this->end_controls_section();
		$this->__style_content_controller( $control );

	}


	public function __style_content_controller( ExfolioControl $control ) {


		$id = "dsn-text-marquee";
		$this->start_controls_section(
			'style_content_service_' . $id,
			[
				'label' => esc_html__( 'Description', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addHeadingColor( 'title_color', '.' . $id )
		        ->setLabel( __( 'Custom Color', 'exfolio' ) )
		        ->get();

		$control->addTypography( 'item_typo_content_' . $id, '.' . $id )
		        ->getGroup();


		$this->end_controls_section();


		$this->start_controls_section(
			'style_content_service_icon',
			[
				'label' => esc_html__( "icon ( SVG )", 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$control->addIconColor( 'icon_color_select' )
		        ->setPrefix_class()
		        ->get();


		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'icon_color_select' => ''
				],
				'selectors' => [
					'{{WRAPPER}}  i'        => 'color: {{VALUE}};',
					'{{WRAPPER}}  svg'      => 'fill: {{VALUE}};',
					'{{WRAPPER}}  svg path' => 'fill: {{VALUE}};',
				],

			]
		);

		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-text-marquee svg', 'width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addMarginGroup( 'item_margin_icon', 'svg' )
		        ->setSeparator( "before" )
		        ->getResponsive();

		$control->addPaddingGroup( 'item_padding_icon', 'svg' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius_icon', 'svg' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style_icon', 'svg' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow_icon', 'svg' )->getGroup();

		$this->end_controls_section();
	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$this->add_inline_editing_attributes( "description" );

		echo exfolio_shortcode_render_group( 'marquee', array( 'widget-base' => $this ) );

	}


	public function get_script_depends() {
		return [ \inc\exfolioFrontEnd::MARQUEE ];
	}

}
