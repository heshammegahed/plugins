<?php

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;
use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
};

/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class  ExfolioFeatureImage extends Widget_Base {

	use Exfolio_Widget_Base;

	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_featured-image';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return __( 'exfolio Featured image', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-featured-image';

	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'list' ] );
	}


	protected function register_controls() {

		$control = $this->getControl();
		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'fallback',
			[
				'label' => esc_html__( 'Fallback', 'elementor-pro' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$thumbnail_id = get_post_thumbnail_id();

		if ( get_post_type() === 'dsn-custom-skin' ) {
			$settings = $this->get_settings_for_display();
			if ( empty( $settings['fallback']['url'] ) ) {
				return;
			}
			Group_Control_Image_Size::print_attachment_image_html( $settings, 'fallback' );
		} else if ( $thumbnail_id ) {
			echo exfolio_shortcode_render_group( 'custom_post/image', array( 'widget-base' => $this ) );
		}else{
			echo '<div class="box-image-link"><div class="box-image-bg"></div></div>';
		}

	}


}
