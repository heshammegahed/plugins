<?php

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Page Header in Elementor Document Settings
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end',
	'exfolio_document_settings_page_footer_animate' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end',
	'exfolio_document_settings_page_footer_animate' );
function exfolio_document_settings_page_footer_animate( PageBase $page ) {

	$control = new ExfolioControl( $page );

	$page->start_controls_section(
		'page_footer_section_animate',
		array(
			'label'     => esc_html__( 'Footer Animate', 'exfolio' ),
			'tab'       => Controls_Manager::TAB_SETTINGS,
			'condition' => exfolio_is_work() ? [] : [ 'show_footer' => '1' ]
		)
	);


	$control->addSwitcher( 'motion_effect_footer' )
	        ->setLabel( esc_html__( 'Motion Effect Footer', 'exfolio' ) )
	        ->setReturn_value( 'footer-animate' )
	        ->get();

	$control->addSwitcher( 'motion_effect_svg' )
	        ->setLabel( esc_html__( 'Effect Half Circle', 'exfolio' ) )
	        ->setReturn_value( 'svg-animate' )
	        ->setConditions( 'motion_effect_footer', '!=', '', 'and' )
	        ->get();


	$control->addSelect( 'dsn_footer_bg_ver_svg', [
		''             => __( 'Default', 'exfolio' ),
		'v-light'      => __( 'Light', 'exfolio' ),
		'v-light-head' => __( 'Light (Static)', 'exfolio' ),
		'v-dark'       => __( 'Dark', 'exfolio' ),
		'v-dark-head'  => __( 'Dark  (Static)', 'exfolio' ),
	] )
	        ->setDefault( '' )
	        ->setLabelBlock()
	        ->setLabel( __( 'Version Background Section', 'exfolio' ) )
	        ->setDescription( __( 'If you choose the wallpaper version, it is best to choose the type of background section',
		        'exfolio' ) )
	        ->setConditions( 'motion_effect_footer', '!=', '', 'and' )
	        ->setConditions( 'motion_effect_svg', '!=', '', 'and' )
	        ->get();


	$control->addIconColor( 'dsn_footer_bg_svg' )
	        ->setLabelBlock()
	        ->setLabel( __( 'Background Section', 'exfolio' ) )
	        ->setConditions( 'motion_effect_footer', '!=', '', 'and' )
	        ->setConditions( 'motion_effect_svg', '!=', '', 'and' )
	        ->get();

	$page->add_control(
		'icon_color',
		[
			'label'     => esc_html__( 'Color', 'elementor' ),
			'type'      => Controls_Manager::COLOR,
			'default'   => '',
			'condition' => [
				'dsn_footer_bg_svg'    => '',
				'motion_effect_footer' => 'footer-animate',
				'motion_effect_svg'    => '1',
			],
			'selectors' => [
				'{{WRAPPER}} .dsn-footer svg' => 'fill: {{VALUE}};',
			],

		]
	);

	$page->end_controls_section();

}