<?php


use Elementor\Controls_Manager;
use inc\resources\views\pages\options\widgets\control\ExfolioLayout;
use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;
use inc\resources\views\pages\options\widgets\posts\PostControl;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class ExfolioPostGrid extends ExfolioLayout {

	use Exfolio_Widget_Base;
	use PostControl;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_custom-posts';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Exfolio Posts Grid', 'exfolio' );

	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(),
			[ 'portfolio', 'posts', 'cpt', 'item', 'loop', 'query', 'cards' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();


		$this->__content_controller( $control );


		$this->getLayout();
		$this->__title_content_controller( $control );
		$this->__excerpt_content_controller( $control );
		$this->__meta_content_controller( $control );
		$this->__link_content_controller( $control );
		$this->end_controls_section();
		$this->pagination();
		$this->filterBar();
		$this->animateGrid();
		$this->styleLayoutTab();
		$this->__card_controller( $control );
		$this->__image_style_controller( $control );
		$this->__style_controller( $control );
		$this->query( $control );


		return;


//		$this->getScroll();




	}


	private function pagination() {
		$control = $this->getControl();

		$this->start_controls_section(
			'pagination_section',
			[
				'label' => esc_html__( 'Pagination',
					'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control->addSelect( 'pagination_type',
			[
				'none' => __( 'None', 'exfolio' ),
				'nav'  => __( 'Pagination With Number', 'exfolio' ),
				'ajax' => __( 'Button Ajax', 'exfolio' ),
			] )
		        ->setLabel( esc_html__( 'Pagination', 'exfolio' ) )
		        ->setDefault( 'none' )
		        ->get();

		$control->addText( 'next_post' )
		        ->setLabel( esc_html__( 'Next Post Title', 'exfolio' ), true )
		        ->setDefault( __( 'NEXT',
			        'exfolio' ) )
		        ->setConditions( 'pagination_type',
			        'nav' )
		        ->get();

		$control->addText( 'prev_post' )
		        ->setLabel( esc_html__( 'Prev Post Title', 'exfolio' ), true )
		        ->setDefault( __( 'PREV', 'exfolio' ) )
		        ->setConditions( 'pagination_type', 'nav' )
		        ->get();


		$control->addText( 'load_more_post' )
		        ->setLabel( esc_html__( 'Load More Title', 'exfolio' ), true )
		        ->setDefault( __( 'Load More', 'exfolio' ) )
		        ->setConditions( 'pagination_type', 'ajax' )
		        ->get();


		$control->addText( 'no_more_post' )
		        ->setLabel( esc_html__( 'No More Title', 'exfolio' ), true )
		        ->setDynamicActive( true )
		        ->setDefault( __( 'No More', 'exfolio' ) )
		        ->setConditions( 'pagination_type', 'ajax' )
		        ->get();

		$control->getJustifyContent( 'pagination_justify_content', '.dsn-p-pag' )
		        ->setSeparator( "before" )
		        ->setConditions( 'pagination_type', '!==', 'none' )
		        ->getResponsive();


		$control->addSlider( 'dsn-paginate-space', [
			'label' => esc_html__( 'Spacing', 'exfolio' ),
			'range' => [
				'px' => [ 'max' => 100, ],
			],
		] )
		        ->setSelectors( '.dsn-p-pag', '--dsn-row-item:{{SIZE}}{{UNIT}}' )
		        ->setConditions( 'pagination_type', '!==', 'none' )
		        ->getResponsive();


		$this->end_controls_section();
	}

	private function filterBar() {
		$control = $this->getControl();

		$this->start_controls_section(
			'filter_bar_section',
			[
				'label' => esc_html__( 'Filter Bar', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control->addSwitcher( 'filter_bar' )
		        ->setLabel( esc_html__( 'Filter Bar', 'exfolio' ) )
		        ->get();

		$control->addText( 'filter_title' )
		        ->setLabel( esc_html__( 'Filter Title', 'exfolio' ),
			        true )
		        ->setDynamicActive( true )
		        ->setDefault( __( 'Filter', 'exfolio' ) )
		        ->setConditions( 'filter_bar',
			        '1' )
		        ->get();

		$control->addText( 'all_filter' )
		        ->setLabel( esc_html__( 'Button All Filter', 'exfolio' ), true )
		        ->setDefault( __( 'All', 'exfolio' ) )
		        ->setConditions( 'filter_bar', '1' )
		        ->get();

		$control->getJustifyContent( 'filter_bar_justify_content', '.dsn-filtering' )
		        ->setSeparator( "before" )
		        ->setConditions( 'filter_bar', '1' )
		        ->getResponsive();

		$this->end_controls_section();
	}


	private function styleLayoutTab() {
		$control = $this->getControl();


		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Layout', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->getGridSpace();





		$control->getAlign()
		        ->setDefault( "left" )
		        ->getResponsive();



		$control->addPaddingGroup( 'item_padding_box', '.root-posts .dsn-posts .box-content' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorder( 'item_border_style_box', '.root-posts .dsn-posts .box-content' )
		        ->getGroup();

		$control->addSwitcher( 'remove_last_border' )
		        ->setLabel( esc_html__( "Remove Last Border", "exfolio" ) )
		        ->setReturn_value( 'dsn-remove-last-border' )
		        ->setPrefix_class()
		        ->get();

		$control->addBorderRadiusGroup( 'item_border_radius_box', '.root-posts .dsn-posts .dsn-item-post' )
		        ->getResponsive();

		$this->end_controls_section();


	}


	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$shortcode = new exfolioShortCode( array( 'widget-base' => $this ) );
		$id_temp   = $shortcode->getVal( 'choose_template_posts' );

		if ( ! $id_temp ) {
			return;
		}


		$option_query = $this->getOptionQueries( $shortcode );

		$myPosts = new WP_Query( $option_query );

		exfolio_render_widget_motion_effect( $this, 'dsn-posts' );


		$this->addPrefixClassLayout( 'dsn-posts', $shortcode );
		$this->addAnimateFade( 'dsn-item-content', $shortcode );
		$hasFilter = $shortcode->getVal( 'filter_bar' ) && ! $shortcode->getVal( 'scroll_horizontal' );

		$this->add_render_attribute( 'dsn-posts',
			[
				'class' => [
					'dsn-posts',
					$hasFilter ? 'use-filter dsn-isotope' : '',
					$shortcode->getVal( 'scroll_horizontal' ),
				]
			] );


		?>
        <div class="root-posts<?php echo esc_attr( $hasFilter ? ' has-filter' : '' ) ?>">

			<?php


			/**
			 * Filter
			 */
			if ( ! $shortcode->getVal( 'scroll_horizontal' ) ) {
				$this->add_inline_editing_attributes( 'filter_title', 'none' );
				$this->add_inline_editing_attributes( 'all_filter', 'none' );
				echo exfolio_shortcode_render( 'custom_post/filter', $shortcode, [
					'my-posts' => $myPosts,
				] );
			}


			/**
			 * Post Content
			 */
			printf( '<div %1$s>%2$s</div>',
				$this->get_render_attribute_string( 'dsn-posts' ),
				exfolio_shortcode_render_group( 'custom_post', array( 'widget-base' => $this ), $myPosts ) );


			/**
			 * Paginate
			 */
			echo exfolio_shortcode_render( 'custom_post/paginate', $shortcode, [
				'my-posts'     => $myPosts,
				'option_query' => $option_query
			] );
			?>


        </div>
		<?php
	}



	public function get_style_depends(): array {

		$this->EnqueueCssPosts();
		return parent::get_style_depends(); // TODO: Change the autogenerated stub
	}
}