<?php

require_once __DIR__ . '/document/page_header.php';
require_once __DIR__ . '/document/page_title.php';
require_once __DIR__ . '/document/page_layout.php';
require_once __DIR__ . '/document/page_footer.php';
require_once __DIR__ . '/document/page_footer_animate.php';