<?php

namespace inc\resources\views\pages\options\widgets\control;

trait ExfolioSwiper {



	protected function setOptionSwiper( $id, $default = false ) : self {
		$this->swiper_option[ $id ] = $this->shortcode->getVal( $id, $default );
		return $this;
	}



	protected function setOptionSwiperBoolean( $id, $default = false ) : self {
		$this->swiper_option[ $id ] = boolval( $this->shortcode->getVal( $id, $default ) );

		return $this;
	}



	protected function setOptionSwiperResponsive( $id, $default_mobile = false, $default_tablet = null, $default = null ) : self {

		if ( $default_tablet === null )
			$default_tablet = $default_mobile;
		if ( $default === null )
			$default = $default_mobile;


		$this->swiper_option[ $id ] = $this->shortcode->getVal( $id . '_mobile', $default_mobile );

		$this->swiper_option['breakpoints'][0][ $id ]   = $this->shortcode->getVal( $id . '_mobile', $default_tablet );
		$this->swiper_option['breakpoints'][576][ $id ] = $this->shortcode->getVal( $id . '_mobile', $default_tablet );
		$this->swiper_option['breakpoints'][768][ $id ] = $this->shortcode->getVal( $id . '_tablet', $default_tablet );
		$this->swiper_option['breakpoints'][992][ $id ] = $this->shortcode->getVal( $id, $default );

		return $this;
	}


	protected function setOptionSwiperResponsiveNumberSlider( $id, $default_mobile = false, $default_tablet = null, $default = null ) : self {

		if ( $default_tablet === null )
			$default_tablet = $default_mobile;
		if ( $default === null )
			$default = $default_mobile;


		$this->swiper_option[ $id ]                     = (float) $this->shortcode->getValueNumberSlide( $id . '_mobile', $default_mobile );
		$this->swiper_option['breakpoints'][0][ $id ]   = (float) $this->shortcode->getValueNumberSlide( $id . '_mobile', $default_tablet );
		$this->swiper_option['breakpoints'][576][ $id ] = (float) $this->shortcode->getValueNumberSlide( $id . '_mobile', $default_tablet );
		$this->swiper_option['breakpoints'][768][ $id ] = (float) $this->shortcode->getValueNumberSlide( $id . '_tablet', $default_tablet );
		$this->swiper_option['breakpoints'][992][ $id ] = (float) $this->shortcode->getValueNumberSlide( $id, $default );

		return $this;
	}


	protected function setOptionSwiperResponsiveBoolean( $id, $default_mobile = false, $default_tablet = null, $default = null ) : self {
		$this->setOptionSwiperResponsive( $id, $default_mobile, $default_tablet, $default );


		$this->swiper_option[ $id ]                     = boolval( $this->swiper_option[ $id ] );
		$this->swiper_option['breakpoints'][0][ $id ]   = boolval( $this->swiper_option['breakpoints'][0][ $id ] );
		$this->swiper_option['breakpoints'][576][ $id ] = boolval( $this->swiper_option['breakpoints'][576][ $id ] );
		$this->swiper_option['breakpoints'][768][ $id ] = boolval( $this->swiper_option['breakpoints'][768][ $id ] );
		$this->swiper_option['breakpoints'][992][ $id ] = boolval( $this->swiper_option['breakpoints'][992][ $id ] );

		return $this;
	}


	protected function autoPlay( $id, $default = false, $isLoop = true ) :self{
		$val = $this->shortcode->getVal( $id, $default );
		if ( ! $isLoop )
			$this->swiper_option['autoplay'][ $id ] = $val;
		else
			$this->swiper_option['autoplay'][ $id ] = boolval( $val );


		return $this;
	}


}
