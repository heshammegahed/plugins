<?php


namespace inc\resources\views\pages\options;


use Elementor\Elements_Manager;
use Elementor\Plugin;
use inc\resources\views\pages\options\controls\DsnSelectControl;
use inc\resources\views\pages\options\inc\notices;
use inc\resources\views\pages\options\widgets\control\ExfolioRegisterElement;
use inc\resources\views\pages\options\widgets\control\ExfolioColumn;
use inc\resources\views\pages\options\widgets\control\ExfolioSection;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * exfolio Widget Extension
 * The main class that initiates and runs the plugin.
 *
 */
class exfolioWidgetLoader extends ExfolioRegisterElement {


	use notices;

	/**
	 * Instance
	 *
	 * @access private
	 * @static
	 * @var exfolioWidgetLoader The single instance of the class.
	 */
	private static $_instance = null;


	/**
	 * Register Block Name
	 */
	const DSN_BLOCK = array(
		'Heading',
		'Button',
		'Image',
		'List',
		'JustifyGallery',
		'sliders'      => 'MediaSlider',
		'custom_posts' => [
			'PostTitle',
			'FeatureImage',
			'PostExcerpt',
			'PostCat',
			'PostDate',
			'PostUrl',
		],
		'posts'        => [
			'control' => 'Post',
		],
		'posts/custom' => [
			'PostGrid',
			'PostSwiper'
		],
		'posts/slider' => [
			'control' => 'Slider',
			'SliderProject',
			'SliderThreeJS',
		],
		'Icon',
		'Testimonial',
		'navigation'   => [
			'Arrow'
		],
		'team'         => [
			'control' => 'Team',
			'GridTeam',
			'SwiperTeam'
		],
		'brand'        => [
			'control' => 'Brand',
			'GridBrand',
			'SwiperBrand'
		],
		'Social',
		'MotionHover',
		'Accordion',
		'FilpHover',
		'MarqueeImage',
		'Skills',
		'Marquee',
		'AnimateLine',
		'BGMask',
		'Logo',
		'Map',

//		'service'      => [
//			'control' => 'Service',
//			'ServiceGrid',
//
//		],

//		'Title',
//		'posts'   => [
//			'control' => 'Post',
//			'PostGrid',
//			'PostHover',
//			'PostSwiper'
//		],






//		'Experience',

//		'CircleTextRotation',


//
//		'Head',
//
//		'GridMasonry',

//		'SkillImg',
//
//
//


//		'Tabs',
//
//		'woocommerce' => [
//			'Products',
//			'Category',
//			'Breadcrumb',
//		],
//		'Facts',
		//		'Compare',
////		'PricingTable',
////		'MoveSection',
////		'Awards',
//		'Feature',


	);

	/**
	 * Minimum ELEMENTOR Version
	 */
	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';


	/**
	 * Minimum PHP Version
	 */
	const MIN_PHP_VERSION = '7.0';


	/**
	 * Instance
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @access public
	 * @static
	 *
	 * @return exfolioWidgetLoader An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;

	}


	/**
	 * Initializing the exfolioWidgetLoader class.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		require_once __DIR__ . '/widgets/control/ExfolioControl.php';
		add_action( 'widget_loader', [ $this, 'register_widget' ] );
	}


	function preload_style( $tag, $handle, $src ): string {
		// the handles of the enqueued scripts we want to async
		$async_scripts = array( 'exfolio-fonts' );


		if ( in_array( $handle, $async_scripts ) ) {
			return sprintf( '<link id="exfolio-fonts" rel="preload" href="%1$s" as="style" onload="this.onload=null;this.rel=\'stylesheet\'"><noscript><link href="%1$s" rel="stylesheet"></noscript>',
				$src );
		}

		return $tag;
	}



	/**
	 *
	 */

	/**
	 * Initialize the Widget
	 * Retrieve the current widget initial configuration.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function register_widget() {


		if ( ! $this->elementorLoaded() || ! $this->PHPVer() ) {
			return;
		}


		add_action( 'elementor/controls/register', function ( $controls_manager ) {
			require_once( __DIR__ . '/controls/DsnSelectControl.php' );
			$controls_manager->register( new DsnSelectControl() );


		} );


		/**
		 * registering new Elementor widgets Category
		 */
		add_action( 'elementor/elements/categories_registered', function ( Elements_Manager $elements_manager ) {

			$elements_manager->add_category(
				'exfolio_cat',
				[
					'title' => esc_html__( 'Exfolio Widget(Design Grid)', 'exfolio' ),
					'icon'  => 'fa fa-plug',
				]
			);

		} );


		/**
		 * registering new Elementor widgets
		 */

		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );


		$this->registerWidgetSection();
		$this->registerRenderSection();


		add_action( 'elementor/elements/elements_registered', [ $this, 'register_elements' ] );


	}


	/**
	 * Register oEmbed Widget.
	 *
	 * Include widget file and register widget class.
	 *
	 *
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function register_widgets( $widgets_manager ) {

		require_once __DIR__ . '/widgets/control/ExfolioSlider.php';
		require_once __DIR__ . '/widgets/control/ExfolioLayout.php';

		/**
		 * Control Widget
		 */


		foreach ( self::DSN_BLOCK as $key => $block ):


			if ( $block ) {
				if ( is_array( $block ) ) {
					foreach ( $block as $key2 => $instance ) {
						if ( $key2 === 'control' ) {
							require_once __DIR__ . '/widgets/' . $key . '/' . $instance . 'Control.php';
							continue;
						}

						$this->getInstanceWidget( $key, $instance, $widgets_manager );
					}
				} else {

					$this->getInstanceWidget( $key, $block, $widgets_manager );
				}


			}

		endforeach;


	}

	/**
	 * check version < 3.5.0
	 * @return bool|int
	 */
	private function CheckVersionElement() {
		return version_compare( ELEMENTOR_VERSION, "3.5.0", '<' );
	}


	private function getInstanceWidget( $key, $instance, $widgets_manager ) {

		$instance = 'Exfolio' . $instance;
		if ( is_string( $key ) ) {
			$key .= '/';
		} else {
			$key = '';
		}

		require_once __DIR__ . '/widgets/' . $key . $instance . '.php';

		if ( $this->CheckVersionElement() ) {
			Plugin::instance()->widgets_manager->register_widget_type( new $instance() );
		} else {
			$widgets_manager->register( new $instance() );
		}
	}


	/**
	 * Register Custom Elements
	 *
	 * @access public
	 *
	 * @return void
	 */

	public function register_elements() {
		require_once 'widgets/control/ExfolioColumn.php';
		require_once 'widgets/control/ExfolioSection.php';
		Plugin::instance()->elements_manager->register_element_type( new ExfolioColumn() );
		Plugin::instance()->elements_manager->register_element_type( new ExfolioSection() );
	}


}

exfolioWidgetLoader::instance();