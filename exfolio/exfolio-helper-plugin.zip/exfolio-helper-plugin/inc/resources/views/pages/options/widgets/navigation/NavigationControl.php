<?php


use inc\resources\views\pages\options\widgets\control\ExfolioControl;

trait  NavigationControl {

	public function __content_controller( ExfolioControl $control ) {


		$control->addImageSize()
		        ->setDefault( 'thumbnail' )
		        ->getGroup();


		$control->startRepeater();
		$control->addImage()->get();

		$control->addSelect( 'border_type', [
			''                           => esc_html__( 'Default', 'ohixm' ),
			'border-bottom border-right' => esc_html__( 'Bottom Right', 'ohixm' ),
			'border-right'               => esc_html__( 'Right', 'ohixm' ),
			'border-bottom'              => esc_html__( 'Bottom', 'ohixm' ),
		] )
		        ->setLabel( esc_html__( "Border Type", 'ohixm' ) )
		        ->setDefault( '' )
		        ->get();


		$control->addLink( 'link' )
		        ->setLabel( esc_html__( 'Link', 'ohixm' ), true )
		        ->setDefault_url()
		        ->setDefault_is_external( true )
		        ->setDefault_is_nofollow( true )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( "Items" )
		        ->setTitle_field_WithImage( 'image', 'link.url' )
		        ->get();


	}

	public function __style_controller( ExfolioControl $control ) {
		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Service', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Service', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-section' )
		        ->get();

		$control->addPaddingGroup( 'item_padding', '.brand-item' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.brand-item' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.brand-item' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.brand-item' )->getGroup();

	}

}