<?php

use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class ExfolioMotionHover extends Widget_Base {

	use Exfolio_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_motion_effect';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return __( 'Exfolio Motion Hover Effect', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-favorite';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'icon' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();
		$style   = [];
		for ( $x = 1; $x <= 22; $x ++ ):
			$style[ $x . '' ] = "Style " . $x;
		endfor;
		$control->addSelect( 'style_hover_post', $style )
		        ->setLabel( esc_html__( "Additional effects", 'exfolio' ) )
		        ->setSeparatorAfter()
		        ->setDefault( '1' )
		        ->get();


		$control->getGroupImage();


		$control->addTextarea( 'title' )
		        ->setLabel( esc_html__( 'Title', 'exfolio' ) )
		        ->setPlaceholder( esc_html__( 'Enter your title', 'exfolio' ) )
		        ->setDefault( esc_html__( 'Add Your Heading Text Here', 'exfolio' ) )
		        ->get();

		$control->addLink( 'link' )
		        ->setLabel( esc_html__( 'Link', 'exfolio' ) )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSize()
		        ->setSeparator( "before" )
		        ->get();


		$control->addHtmlTag()->get();
		$control->addLineText()
		        ->get();


		$control->addSelect( 'dsn_title_animate', [
			''         => __( 'None', 'exfolio' ),
			'dsn-up'   => __( 'Fade', 'exfolio' ),
			'dsn-text' => __( 'Text', 'exfolio' ),
			'dsn-fill' => __( 'Fill Text', 'exfolio' ),
		] )
		        ->setLabel( __( 'Animate Text', 'exfolio' ) )
		        ->setDefault( '' )->setSeparator( "before" )
		        ->get();

		$control->addSwitcher( 'dsn_uppercase' )
		        ->setLabel( __( 'Text Uppercase', 'exfolio' ) )
		        ->setReturn_value( "text-uppercase" )
		        ->setPrefix_class()
		        ->get();

		$this->end_controls_section();

		$this->__image_style_controller();
		$this->styleTab();
	}


	public function __image_style_controller() {
		$control = $this->getControl();
		$this->start_controls_section(
			'style_image_section',
			[
				'label' => esc_html__( 'Image', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$control->addSlider( 'width_img',
			$control->getDefaultWidthHeight() )
		        ->setLabel( esc_html__( 'Width', 'ohixm' ) )
		        ->setSelectors( '.hover-reveal', 'width:{{SIZE}}{{UNIT}};max-width:{{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSlider( 'height_img',
			$control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( esc_html__( 'Height', 'ohixm' ) )
		        ->setSelectors( '.hover-reveal', 'height:{{SIZE}}{{UNIT}};max-height:{{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius_image', '.hover-reveal__img' )
		        ->getResponsive();

		$this->end_controls_section();
	}

	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$control->addPaddingGroup( 'item_clip_path', '.dsn-heading-title', [ 'selectors' => [] ] )
		        ->setSelectors( '.dsn-heading-title',
			        'clip-path:inset({{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}})' )
		        ->setSeparatorBefore()
		        ->setLabel( esc_html__( "Clip Path", 'exfolio' ) )
		        ->getResponsive();

		$control->addHeadingColor( 'title_color', '.dsn-heading-title' )
		        ->setLabel( __( 'Custom Color', 'exfolio' ) )
		        ->get();

		$control->addSlider( 'space', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Max Width', 'elementor' ) )
		        ->setSelectors( '.dsn-heading-title', 'max-width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addTypography( 'title_typography' )->getGroup();
		$control->addTextShadow( 'title_Text_shadow' )->getGroup();
		$control->addBlendMode( 'title_blend_mode', '' )
		        ->setSelectors( '', 'mix-blend-mode: {{VALUE}}' )
		        ->get();

		$control->addSwitcher( 'use_as_stroke' )
		        ->setReturn_value( 'letter-stroke' )
		        ->setLabel( __( 'Use As Stroke', 'exfolio' ) )
		        ->get();

		$control->addSwitcher( 'use_as_wrapper' )
		        ->setLabel( __( 'No Wrapper', 'exfolio' ) )
		        ->setSelectors( ".dsn-heading-title", "white-space: nowrap;" )
		        ->get();


		$this->end_controls_section();

		$this->start_controls_section(
			'style_section_bg',
			[
				'label' => esc_html__( 'Background', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background', 'exfolio' ) )
		        ->setDefault( '' )
		        ->setPrefix_class()
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Button', 'exfolio' ) )
		        ->setDefault( 'background-transparent' )
		        ->setPrefix_class()
		        ->get();


		$control->addSwitcher( "text-fill-color" )
		        ->setLabel( esc_html__( "Text Fill Color" ) )
		        ->setSelectors( '.dsn-heading-title', '-webkit-background-clip: text;-webkit-text-fill-color: transparent;
									background-clip: text;text-fill-color: transparent;' )
		        ->get();

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'background-text',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .dsn-heading-title',
			]
		);

		$this->end_controls_section();


	}


	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$this->add_inline_editing_attributes( 'title' );
		echo exfolio_shortcode_render_group( 'motion-effect', array( 'widget-base' => $this ) );
	}

	public function get_script_depends() {
		return [ \inc\exfolioFrontEnd::MotionHoverEffects ];
	}


}
