<?php

use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class ExfolioIcon extends Widget_Base {

	use Exfolio_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_icon';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return __( 'Exfolio Icon', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-favorite';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'icon' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Title', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();
		$this->add_control(
			'icon',
			[
				'label'   => __( 'Icon', 'exfolio' ),
				'type'    => Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);
		$control->getAlign()
		        ->setSeparatorBefore()
		        ->setDefault( "left" )
		        ->getResponsive();

		$this->add_control(
			'opacity',
			[
				'label'     => esc_html__( 'Opacity', 'elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .dsn-icon' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->styleTab();

	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style Icon', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addSelect( 'bg_ver_icon', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background', 'exfolio' ) )
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_icon', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Icon', 'exfolio' ) )
		        ->setDefault( 'background-transparent' )
		        ->get();
		$control->addSwitcher( 'use_stroke' )
		        ->setLabel( esc_html__( "Color Stroke", "exfolio" ) )
		        ->setReturn_value( "dsn-icon-stroke" )
		        ->setPrefix_class()
		        ->get();

		$control->addIconColor( 'icon_color_select' )
		        ->setPrefix_class()
		        ->setDefault( 'dsn-icon-theme-color' )
		        ->get();

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'icon_color_select' => ''
				],
				'selectors' => [
					'{{WRAPPER}} .dsn-icon i'                                    => 'color: {{VALUE}};',
					'{{WRAPPER}} .dsn-icon svg , {{WRAPPER}} .dsn-icon svg path' => 'fill: {{VALUE}};'
				],

			]
		);


		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-icon', '--dsn-icon-size: {{SIZE}}{{UNIT}};' )
		        ->setSeparatorBefore()
		        ->getResponsive();

		$control->addSlider( 'height_icon', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setDefaultDesktop( 20 )
		        ->setSelectors( '.dsn-icon', '--dsn-icon-height: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addPaddingGroup( 'item_padding_icon', '.dsn-icon ,{{WRAPPER}} .dsn-icon' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius_icon', '.dsn-icon ,{{WRAPPER}} .dsn-icon' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style_icon', '.dsn-icon ,{{WRAPPER}} .dsn-icon' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow_icon', '.dsn-icon ,{{WRAPPER}} .dsn-icon' )->getGroup();


		$this->end_controls_section();

	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		echo exfolio_shortcode_render_group( 'icon', array( 'widget-base' => $this ) );

	}

	protected function content_template() {
		echo exfolio_shortcode_js_group( 'icon', array(), '' );
	}

}
