<?php


use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use inc\exfolioFrontEnd;
use inc\resources\views\pages\options\widgets\control\Exfolio_Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class ExfolioJustifyGallery extends Widget_Base {

	use Exfolio_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_gallery';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return esc_html__( 'Gallery Justified', 'exfolio' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-gallery-justified';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'image', 'photo', 'gallery', 'justified', 'slider' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();

		$control->getGroupGallery();


		$this->add_control(
			'popup_image',
			[
				'label'     => esc_html__( 'Popup Image', 'exfolio' ),
				'type'      => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$control->addImageSize( 'size_img_popup' )
		        ->setDefault( 'full' )
		        ->getGroup();

		$control->addText( 'group_popup' )
		        ->setLabel( esc_html__( 'Group Gallery', 'exfolio' ) )
		        ->get();


		$this->end_controls_section();

		$this->styleSettings();

	}


	private function styleSettings() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Additional Options', 'exfolio' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$control->addNumberSlider( 'rowHeight', 0, 1000, 10 )
		        ->setLabel( esc_html__( 'Row Height', 'exfolio' ) )
		        ->setDescription( esc_html__( 'The preferred rows height in pixel.', 'exfolio' ) )
		        ->setDefaultRange( 320 )
		        ->get();

		$control->addNumberSlider( 'gutter', 0, 1000, 10 )
		        ->setLabel( esc_html__( 'Margins', 'exfolio' ) )
		        ->setDescription( esc_html__( 'Decide the margins between the images.', 'exfolio' ) )
		        ->setDefaultRange( 15 )
		        ->get();

		$control->addSelect( 'lastRow', [
			'left'   => esc_html__( 'Left', 'exfolio' ),
			'center' => esc_html__( 'Center', 'exfolio' ),
			'right'  => esc_html__( 'Right', 'exfolio' ),
			'hide'   => esc_html__( 'Hide', 'exfolio' ),
		] )
		        ->setLabel( esc_html__( 'Last row', 'exfolio' ) )
		        ->setDefault( 'left' )
		        ->get();


		$this->end_controls_section();


	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		echo exfolio_shortcode_render_group( 'justified-gallery', array( 'widget-base' => $this ) );
	}

	public function get_script_depends(): array {
		return $this->getDepends();
	}

	public function get_style_depends(): array {
		return $this->getDepends();
	}

	private function getDepends(): array {
		return [ exfolioFrontEnd::FANCYBOX, exfolioFrontEnd::FJ_Gallery ];
	}

}
