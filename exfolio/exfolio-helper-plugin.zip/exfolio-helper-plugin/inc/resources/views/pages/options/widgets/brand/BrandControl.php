<?php

namespace inc\resources\views\pages\options\widgets\brand;


use Elementor\Controls_Manager;
use inc\resources\views\pages\options\widgets\control\ExfolioControl;


trait  BrandControl {

	public function __content_controller( ExfolioControl $control ) {


		$control->addImageSize()
		        ->setDefault( 'thumbnail' )
		        ->getGroup();


		$control->startRepeater();
		$control->addImage()->get();

		$control->addSelect( 'border_type', [
			''                           => esc_html__( 'Default', 'ohixm' ),
			'border-bottom border-right' => esc_html__( 'Bottom Right', 'ohixm' ),
			'border-right'               => esc_html__( 'Right', 'ohixm' ),
			'border-bottom'              => esc_html__( 'Bottom', 'ohixm' ),
		] )
		        ->setLabel( esc_html__( "Border Type", 'ohixm' ) )
		        ->setDefault( '' )
		        ->get();


		$control->addLink( 'link' )
		        ->setLabel( esc_html__( 'Link', 'ohixm' ), true )
		        ->setDefault_url()
		        ->setDefault_is_external( true )
		        ->setDefault_is_nofollow( true )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( "Items" )
		        ->setTitle_field_WithImage( 'image', 'link.url' )
		        ->get();


	}

	public function __style_controller( ExfolioControl $control ) {


		$control->addSlider( 'width_icon_wrapper', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'width', 'elementor' ) )
		        ->setSelectors( '.brand-item', '--width-wrapper: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSlider( 'height_icon_wrapper', $control->getDefaultWidthHeight('vh') )
		        ->setLabel( __( 'Height', 'elementor' ) )
		        ->setSelectors( '.brand-item', '--height-wrapper: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Service', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Service', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-section' )
		        ->get();

		$control->addSwitcher( 'use_stroke' )
		        ->setLabel( esc_html__( "Color Stroke", "ohixm" ) )
		        ->setReturn_value( "dsn-icon-stroke" )
		        ->setPrefix_class()
		        ->get();

		$control->addIconColor( 'icon_color_select' )
		        ->setPrefix_class()
		        ->setDefault( 'dsn-icon-theme-color' )
		        ->get();

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'icon_color_select' => ''
				],
				'selectors' => [
					'{{WRAPPER}} .dsn-icon i'                                    => 'color: {{VALUE}};',
					'{{WRAPPER}} .dsn-icon svg , {{WRAPPER}} .dsn-icon svg path' => 'fill: {{VALUE}};'
				],

			]
		);

		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-icon', '--dsn-icon-size: {{SIZE}}{{UNIT}};' )
		        ->setSeparatorBefore()
		        ->getResponsive();

		$control->addSlider( 'height_icon', $control->getDefaultWidthHeight('vh') )
		        ->setLabel( __( 'Height Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-icon', '--dsn-icon-height: {{SIZE}}{{UNIT}};' )
		        ->setSeparatorBefore()
		        ->getResponsive();



		$control->addPaddingGroup( 'item_padding', '.brand-item' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.brand-item' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.brand-item' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.brand-item' )->getGroup();

	}

}