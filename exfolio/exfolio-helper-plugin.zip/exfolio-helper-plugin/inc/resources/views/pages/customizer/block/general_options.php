<?php

$panels = $dsn_panel . "-general-option";



Kirki::add_panel( $panels, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'General Style', 'exfolio' ),
	'icon'  => 'dashicons-buddicons-topics',

) );



exfolio_resources_customize( 'option/style', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-style',
) );

exfolio_resources_customize( 'option/portfolio', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-portfolio',
) );


exfolio_resources_customize( 'option/menu', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-menu',
) );

exfolio_resources_customize( 'option/color_site', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-color_site',

) );