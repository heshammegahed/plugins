<?php
/**
 *  Home Page
 */

Kirki::add_section( $dsn_section, array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Home', 'exfolio' ),
    'icon'=>'dashicons-admin-home'
) );


exfolio_custom_Label( $dsn_section, 'Home' );


Kirki::add_field( $dsn_customize, [
    'type'     => 'select',
    'settings' => 'home_show_sidebar',
    'label'    => esc_html__( 'Sidebar', 'exfolio' ),
    'section'  => $dsn_section,
    'default'  => 'show',
    'multiple' => 1,
    'choices'  => [
        'show' => esc_html__( 'Show', 'exfolio' ),
        'hide' => esc_html__( 'Hide', 'exfolio' )
    ]
] );

Kirki::add_field( $dsn_customize, [
    'type'     => 'radio-buttonset',
    'settings' => 'home_style_setting',
    'label'    => esc_html__( 'Background Color', 'exfolio' ),
    'section'  => $dsn_section,
    'default'  => 'v-dark',
    'priority' => 10,
    'choices'  => [
        'v-dark'  => esc_html__( 'Dark', 'exfolio' ),
        'v-light' => esc_html__( 'Light', 'exfolio' ),
    ],
] );


Kirki::add_field( $dsn_customize, [
    'type'              => 'text',
    'settings'          => 'home_custom_title',
    'label'             => esc_html__( 'Title', 'exfolio' ),
    'section'           => $dsn_section,
    'default'           => 'Our Blog.',
//    'sanitize_callback' => 'exfolio_sanitize_minimal_decoration',
//    'transport'         => 'postMessage',
    'js_vars'           => [
        [
            'element'  => '#hero_title .title',
            'function' => 'html'
        ]
    ]
] );


Kirki::add_field( $dsn_customize, [
    'type'      => 'text',
    'settings'  => 'home_custom_subtitle',
    'label'     => esc_html__( 'Subtitle', 'exfolio' ),
    'section'   => $dsn_section,
    'default'   => 'NEWS & IDEAS',
//    'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => '#hero_content .metas span',
            'function' => 'html'
        ]
    ]
] );

