<?php



$panels = $dsn_panel . "-header-option";
Kirki::add_panel( $panels, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Header', 'exfolio' ),
	'icon'  => 'dashicons-welcome-widgets-menus'
) );

exfolio_resources_customize( 'option/header/logo', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-logo',
) );



exfolio_resources_customize( 'option/header/logo-admin', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-logo-admin',
) );



exfolio_resources_customize( 'option/header/code', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-code',
) );