<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Ajax Options', 'exfolio' ),
	'icon'  => 'dashicons-align-none'

) );


Kirki::add_field( $dsn_customize, [
	'type'        => 'toggle',
	'settings'    => 'ajax_pages',
	'label'       => esc_html__( 'Load Pages With Ajax', 'exfolio' ),
	'description' => esc_html__( 'When navigate like (slider , next pages , link) loads ', 'exfolio' ),
	'section'     => $dsn_section,
	'default'     => false,
] );