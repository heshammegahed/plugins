<?php
Kirki::add_section( $dsn_section . '_html', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Code HTml', 'exfolio' )

) );




Kirki::add_section( $dsn_section . '_css', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Add Code CSS', 'exfolio' )

) );


Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'css_head_code',
    'label'     => esc_html__( 'Code CSS Header', 'exfolio' ),
    'section'   => $dsn_section . '_css',
    'default'   => '',
    'choices'   => [
        'language' => 'css',
    ],
    'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => '#exfolio_code_css',
            'function' => 'html',
        ]
    ]
] );

Kirki::add_section( $dsn_section . '_js', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Add Code JS', 'exfolio' )

) );
Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'js_head_code',
    'label'     => esc_html__( 'Code JS Header', 'exfolio' ),
    'section'   => $dsn_section . '_js',
    'default'   => '',
    'choices'   => [
        'language' => 'js',
    ],
    'transport' => 'auto',
    
] );
