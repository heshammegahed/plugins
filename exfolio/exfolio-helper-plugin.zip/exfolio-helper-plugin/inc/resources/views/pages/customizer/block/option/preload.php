<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Preload', 'exfolio' ),
	'icon'  => 'dashicons-welcome-view-site',

) );


Kirki::add_field( $dsn_customize, [
	'type'        => 'toggle',
	'settings'    => 'page_preloader',
	'label'       => esc_html__( 'Page Preloader', 'exfolio' ),
	'description' => esc_html__( 'Enable preloader mask while the page is loading.', 'exfolio' ),
	'section'     => $dsn_section,
	'default'     => '1',
] );