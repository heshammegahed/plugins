<?php


Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Archive', 'exfolio' ),
	'icon'  => 'dashicons-archive'

) );


exfolio_custom_Label( $dsn_section, 'Archive' );


Kirki::add_field( $dsn_customize, [
	'type'     => 'select',
	'settings' => 'archive_show_sidebar',
	'label'    => esc_html__( 'Sidebar', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => 'show',
	'multiple' => 1,
	'choices'  => [
		'show' => esc_html__( 'Show', 'exfolio' ),
		'hide' => esc_html__( 'Hide', 'exfolio' )
	]
] );


Kirki::add_field( $dsn_customize, [
	'type'     => 'radio-buttonset',
	'settings' => 'archive_style_setting',
	'label'    => esc_html__( 'Background Color', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => 'v-dark',
	'priority' => 10,
	'choices'  => [
		'v-dark'  => esc_html__( 'Dark', 'exfolio' ),
		'v-light' => esc_html__( 'Light', 'exfolio' ),
	],
] );
