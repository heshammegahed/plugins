<?php


Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Map Settings', 'exfolio' ),
	'icon'  => 'dashicons-location-alt'

) );


Kirki::add_field( $dsn_customize, [
	'type'     => 'image',
	'settings' => 'map_marker_icon',
	'label'    => esc_html__( 'Map marker', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => EXFOLIO__PLUGIN_DIR_URL . '/assets/img/map-marker.png',
] );

Kirki::add_field( $dsn_customize, [
	'type'        => 'textarea',
	'settings'    => 'map_api',
	'label'       => esc_html__( 'Google Maps API Key', 'exfolio' ),
	'description' => esc_html__( 'Without it, the map may not be displayed. If you have an api key paste it here. https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY ', 'exfolio' ),
	'section'     => $dsn_section,

] );

