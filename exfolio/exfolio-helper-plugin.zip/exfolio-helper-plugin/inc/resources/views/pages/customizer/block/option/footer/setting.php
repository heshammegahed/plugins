<?php
/**
 * Normal Static Setting
 */
Kirki::add_section( $dsn_section, array(
	'panel'       => $dsn_panel,
	'title'       => esc_html__( 'Footer Default', 'exfolio' ),
	'description' => esc_html__( 'When you create a page, it\'s going to be default.', 'exfolio' )
) );

Kirki::add_field( $dsn_customize, [
	'type'            => 'radio',
	'settings'        => 'type_footer',
	'label'           => esc_html__( "Type Footer", "exfolio" ),
	'section'         => $dsn_section,
	'default'         => 'default',
	'priority'        => 10,
	'choices'         => [
		'default' => esc_html__( "Default", "exfolio" ),
		'custom'  => esc_html__( "Custom", "exfolio" )
	],
	'transport'       => 'auto',
	'partial_refresh' => [
		'type_footer' => [
			'selector'        => '#dsn_footer',
			'render_callback' => 'default',
		]
	]

] );


$footer_ids = exfolio_get_post_array( exfolio_footer_slug() );
new \Kirki\Field\Select( [
	'settings' => 'choose_template_footer',
	'label'    => esc_html__( "Choose Template Footer", "exfolio" ),
	'section'  => $dsn_section,
	'priority' => 10,
	'choices'  => $footer_ids,

	'active_callback' => [
		[
			'setting'  => 'type_footer',
			'operator' => '==',
			'value'    => 'custom',
		],
	]
] );

new \Kirki\Field\Select( [
	'settings' => 'choose_portfolio_footer',
	'label'    => esc_html__( "Choose Portfolio Footer", "exfolio" ),
	'section'  => $dsn_section,
	'priority' => 10,
	'choices'  => $footer_ids,

	'active_callback' => [
		[
			'setting'  => 'type_footer',
			'operator' => '==',
			'value'    => 'custom',
		],
	]
] );

