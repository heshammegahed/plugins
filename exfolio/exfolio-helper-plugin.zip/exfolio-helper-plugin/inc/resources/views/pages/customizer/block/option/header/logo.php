<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Logo', 'exfolio' )

) );
Kirki::add_field( $dsn_customize, [
	'type'     => 'image',
	'settings' => 'custom_logo',
	'label'    => esc_html__( 'Light Logo', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => '',
	'choices'  => [
		'save_as' => 'id',
	],
] );


Kirki::add_field( $dsn_customize, [
	'type'     => 'image',
	'settings' => 'custom_logo_dark',
	'label'    => esc_html__( 'Dark Logo', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => '',
	'choices'  => [
		'save_as' => 'id',
	],
] );


Kirki::add_field( $dsn_customize, [
	'type'        => 'number',
	'settings'    => 'width_number',
	'label'       => esc_html__( 'Logo Width', 'exfolio' ),
	'description' => esc_html__( '0 for auto width', 'exfolio' ),
	'section'     => $dsn_section,
	'default'     => 0,
	'transport'   => "auto",
	'choices'     => [
		'min'  => 0,
		'step' => 10,
	],

	'active_callback' => [
		[
			'setting'  => 'custom_logo',
			'operator' => '!=',
			'value'    => '',
		]
	],
] );


Kirki::add_field( $dsn_customize, [
	'type'        => 'number',
	'settings'    => 'height_number',
	'label'       => esc_html__( 'Logo Height', 'exfolio' ),
	'description' => esc_html__( '0 for auto Height', 'exfolio' ),
	'section'     => $dsn_section,
	'default'     => 50,
	'choices'     => [
		'min'  => 0,
		'step' => 10,
	],

	'active_callback' => [
		[
			'setting'  => 'custom_logo',
			'operator' => '!=',
			'value'    => '',
		]
	],
] );

Kirki::add_field( $dsn_customize, [
	'type'            => 'text',
	'settings'        => 'title-logo-page',
	'label'           => esc_html__( 'Title Logo ', 'exfolio' ),
	'section'         => $dsn_section,
	'default'         => get_bloginfo( 'name' ),
	'transport'       => 'postMessage',
	'active_callback' => [
		[
			'setting'  => 'custom_logo',
			'operator' => '==',
			'value'    => '',
		]
	],
	'js_vars'         => array(
		array(
			'element'  => '.main-logo h4',
			'function' => 'html',
		),
	),
] );


Kirki::add_field( $dsn_customize, [
	'type'     => 'toggle',
	'settings' => 'typography_logo',
	'label'    => esc_html__( 'typography Logo Text', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => false,
] );

Kirki::add_field( $dsn_customize, array(
	'type'      => 'typography',
	'settings'  => 'logo_font',
	'section'   => $dsn_section,
	'label'     => esc_html__( 'Logo Font', 'exfolio' ),
	'transport' => 'auto',

	'choices' => [
		'fonts' => [
			'standard' => [ 'sans-serif' ],
		],
	],

	'default'         => array(
		'font-family' => 'Roboto',
		'font-size'   => '30px',
	),
	'output'          => array(
		array(
			'element' => '.main-logo h4',
		),
	),
	'active_callback' => [
		[
			'setting'  => 'typography_logo',
			'operator' => '==',
			'value'    => '1',
		]
	],

) );

exfolio_custom_Label( $dsn_section, 'SubText Logo' );


Kirki::add_field( $dsn_customize, [
	'type'      => 'text',
	'settings'  => 'subtitle-logo-page',
	'label'     => esc_html__( 'SubTitle Logo ', 'exfolio' ),
	'section'   => $dsn_section,
	'default'   => get_bloginfo( 'description', 'display' ),
	'transport' => 'postMessage',

	'js_vars' => array(
		array(
			'element'  => '.main-logo p.site-description',
			'function' => 'html',
		),
	),
] );


Kirki::add_field( $dsn_customize, [
	'type'     => 'toggle',
	'settings' => 'typography_subtitle_logo',
	'label'    => esc_html__( 'typography SubTitle Logo', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => false,
] );

Kirki::add_field( $dsn_customize, array(
	'type'      => 'typography',
	'settings'  => 'logo_font',
	'section'   => $dsn_section,
	'label'     => esc_html__( 'Logo Font', 'exfolio' ),
	'transport' => 'auto',

	'choices' => [
		'fonts' => [
			'standard' => [ 'sans-serif' ],
		],
	],

	'default'         => array(
		'font-family' => 'Roboto',
		'font-size'   => '15px',
	),
	'output'          => array(
		array(
			'element' => '.main-logo .site-description',
		),
	),
	'active_callback' => [
		[
			'setting'  => 'typography_subtitle_logo',
			'operator' => '==',
			'value'    => '1',
		]
	],

) );