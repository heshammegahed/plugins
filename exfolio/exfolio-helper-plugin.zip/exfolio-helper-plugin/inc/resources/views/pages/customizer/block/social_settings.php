<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Social Settings', 'exfolio' ),
	'icon'  => 'dashicons-networking'

) );


Kirki::add_field( $dsn_customize, [
	'type'     => 'toggle',
	'settings' => 'effect_dsn_socials',
	'label'    => esc_html__( 'Show Social', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => "1",
] );

$active_callback = [
	[
		'setting'  => 'effect_dsn_socials',
		'operator' => '==',
		'value'    => '1',
	]
];


Kirki::add_field( $dsn_customize, [
	'type'      => 'repeater',
	'label'     => esc_html__( 'All Social', 'exfolio' ),
	'section'   => $dsn_section,
	'transport' => 'postMessage',

	'row_label'       => [
		'type'  => 'field',
		'value' => esc_html__( 'Social Settings', 'exfolio' ),
		'field' => 'name',
	],
	'button_label'    => esc_html__( '"Add new" (Social) ', 'exfolio' ),
	'settings'        => 'dsn_socials',
	'fields'          => [

		'init_name' => [
			'type'      => 'text',
			'label'     => esc_html__( 'initial Social Name', 'exfolio' ),
			'default'   => '',
			'transport' => 'postMessage',

		],
		'icon'      => [
			'type'        => 'text',
			'label'       => esc_html__( 'Icon Social', 'exfolio' ),
			'description' => __( 'You can control this icons from <a href="https://fontawesome.com/icons?d=gallery&m=free" target="_blank" >This Page </a> copy into class like fab fa-500px', 'exfolio' ),
			'default'     => '',
			'transport'   => 'postMessage',


		],
		'link'      => [
			'type'    => 'textarea',
			'label'   => esc_html__( 'URL', 'exfolio' ),
			'default' => '',

		]
	],
	'default'         => exfolio_default_social(),
	'active_callback' => $active_callback,
] );
