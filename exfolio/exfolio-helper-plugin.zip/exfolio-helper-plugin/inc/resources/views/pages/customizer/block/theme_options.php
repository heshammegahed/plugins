<?php

$panels = $dsn_panel . "-theme-option";
Kirki::add_panel( $panels, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Theme Options', 'exfolio' ),
	'icon'  => 'dashicons-admin-settings',

) );


exfolio_resources_customize( 'option/preload', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-preload',
) );

exfolio_resources_customize( 'option/cursor', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-cursor',
) );

exfolio_resources_customize( 'option/scrolling', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-scrolling',
) );
exfolio_resources_customize( 'option/ajax_options', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-ajax_options',

) );