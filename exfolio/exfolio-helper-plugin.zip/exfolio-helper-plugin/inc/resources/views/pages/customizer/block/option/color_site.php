<?php

Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Color', 'exfolio' ),
	'icon'  => 'dashicons-admin-customizer',
) );

$dsn_color = [
	'bg-color'        => [
		'label'   => __( 'background Color Dark', 'exfolio' ),
		'default' => '#000',
	],
	'assistant-color' => [
		'label'   => __( 'The assistant background Color Dark', 'exfolio' ),
		'default' => '#101010',
	],
	'heading-color'   => [
		'label'   => __( 'Heading Color Dark', 'exfolio' ),
		'default' => '#fff',
	],
	'font-color'      => [
		'label'   => __( 'Body Color Dark', 'exfolio' ),
		'default' => '#bbb',
	],
	'theme-color'     => [
		'label'   => __( 'Theme Color Dark', 'exfolio' ),
		'default' => '#14bfb5',
	],
	'border-color'    => [
		'label'   => __( 'Border Color Dark', 'exfolio' ),
		'default' => '#ffffff0a',
	],
];

$dsn_color_light = [
	'bg-color'        => [
		'label'   => __( 'background Color Light', 'exfolio' ),
		'default' => '#f9f9f9',
	],
	'assistant-color' => [
		'label'   => __( 'The assistant background Color Light', 'exfolio' ),
		'default' => '#e6e6e6',
	],
	'heading-color'   => [
		'label'   => __( 'Heading Color Light', 'exfolio' ),
		'default' => '#000',
	],
	'font-color'      => [
		'label'   => __( 'Body Color Light', 'exfolio' ),
		'default' => '#0009',
	],
	'theme-color'     => [
		'label'   => __( 'Theme Color Light', 'exfolio' ),
		'default' => '#d90a2c',
	],
	'border-color'    => [
		'label'   => __( 'Border Color Light', 'exfolio' ),
		'default' => '#bebebe',
	],
];

Kirki::add_field( $dsn_section, [
	'type'     => 'switch',
	'settings' => 'dsn_custom_color',
	'label'    => esc_html__( 'Custom Color Theme', 'exfolio' ),
	'section'  => $dsn_section,
	'default'  => '',


	'choices' => [
		'on'  => esc_html__( 'Enable', 'exfolio' ),
		'off' => esc_html__( 'Disable', 'exfolio' ),
	],
] );

foreach ( $dsn_color as $key => $value ):
	Kirki::add_field( $dsn_section, [
		'type'     => 'color',
		'settings' => $key,
		'label'    => $value['label'],
		'section'  => $dsn_section,
		'default'  => $value['default'],

		'active_callback' => [
			[
				'setting'  => 'dsn_custom_color',
				'operator' => '==',
				'value'    => '1',
			],
		],
	] );
endforeach;

exfolio_custom_Label( $dsn_section, __( 'Version Light', 'exfolio' ), '', [
	[
		'setting'  => 'dsn_custom_color',
		'operator' => '==',
		'value'    => '1',
	],
] );


foreach ( $dsn_color_light as $key => $value ):
	Kirki::add_field( $dsn_section, [
		'type'     => 'color',
		'settings' => $key . '-light',
		'label'    => $value['label'],
		'section'  => $dsn_section,
		'default'  => $value['default'],

		'active_callback' => [
			[
				'setting'  => 'dsn_custom_color',
				'operator' => '==',
				'value'    => '1',
			],
		],
	] );
endforeach;


if ( get_theme_mod( 'dsn_custom_color' ) ) {
	add_action( 'wp_head', function () use ( $dsn_color, $dsn_color_light ) { ?>
        <style id="exfolio_style_color">
             :root .v-light, :root .v-light-head {
            <?php
				foreach ($dsn_color_light as $key => $value):
			printf('--%s:%s;' , $key , get_theme_mod($key. '-light' , $value['default']));
		 endforeach;
			?>

            }

            :root .v-light.background-theme, :root .v-light-head.background-theme,
            :root .v-light .background-theme, :root .v-light-head .background-theme,
            :root .v-light .calendar_wrap table tr td#today, :root .v-light-head .calendar_wrap table tr td#today {
                --heading-color: #fff;
                --font-color: #fff;
                color: var(--font-color);
            }


            :root .v-dark, :root .v-dark-head {
            <?php
				foreach ($dsn_color as $key => $value):

                printf('--%s:%s;' , $key , get_theme_mod($key , $value['default']));
             endforeach;
			?>

            }

            :root .v-dark.background-theme, :root .v-dark-head.background-theme,
            :root .v-dark .background-theme, :root .v-dark-head .background-theme {
                --font-color: #000;
            }

        </style>
	<?php }, 100 );
}