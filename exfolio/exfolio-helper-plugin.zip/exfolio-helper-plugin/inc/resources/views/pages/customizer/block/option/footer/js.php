<?php
/**
 * Feature Dynamic Setting
 */
Kirki::add_section( $dsn_section, array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Footer JS Code', 'exfolio' ),
) );

Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'js_footer_code',
    'label'     => esc_html__( 'Code JS Footer', 'exfolio' ),
    'section'   => $dsn_section,
    'transport' => 'auto',
    'default'   => '',
    'choices'   => [
        'language' => 'js',
    ],

] );


