import * as hoverImage from "./HoverImgFx";


window.dsnGrid.motionHoverEffect = hoverImage;