<?php

class OhixmFrontEnd {

	const FANCYBOX = 'fancybox';
	const SWIPER = 'swiper';
	const FJ_Gallery = 'fjGallery';
	const THREE_JS = 'threejs';

	const MARQUEE = 'jquery-marquee';
	const MotionHoverEffects = 'motion-hover-effects';
	const ANIMATED_HEADLINE = 'animatedheadline';


	public function __construct() {
		add_action( 'wp_enqueue_scripts', [ $this, 'register_script' ], 99, 20 );
		add_action( 'wp_enqueue_scripts', [ $this, 'register_style' ], 99, 20 );
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_script_enable' ], 99, 20 );
		add_action( 'elementor/frontend/before_enqueue_styles', [ $this, 'register_style' ] );
		add_action( 'elementor/frontend/before_register_scripts', [ $this, 'register_script' ] );
		add_filter( 'body_class', [ $this, 'body_class' ], 99 );
	}




	public function register_script() {

		//--> fancybox
		wp_register_script( self::FANCYBOX, OHIXM_MODULES_PATH . '/fancybox/fancybox.min.js', array( 'jquery' ), '4.0.26', true );

		//--> Swiper
		wp_register_script( self::SWIPER, OHIXM_MODULES_PATH . '/swiper/swiper.min.js', array( 'jquery' ), '11.1.9', true );

		//--> Flickr's Justified Gallery
		wp_register_script( self::FJ_Gallery, OHIXM_MODULES_PATH . '/fjGallery/fjGallery.min.js', array(), '1.0.7', true );

		//--> animate headline
		wp_register_script( self::ANIMATED_HEADLINE, OHIXM_MODULES_PATH . '/animatedheadline/animatedheadline.min.js', array( 'jquery' ), false, true );
		wp_register_script( self::MARQUEE, OHIXM_MODULES_PATH . '/jquery-marquee/jquery.marquee.min.js', array( 'jquery' ), false, true );


		//--> THREE JS
		wp_register_script( self::THREE_JS, OHIXM_MODULES_PATH . '/threejs/threejs.min.js', array( 'jquery' ), false, true );

		//--> motion-hover-effects
		wp_register_script( self::MotionHoverEffects, OHIXM_MODULES_PATH . '/motion-hover-effects/index.min.js', array(
			'jquery',
			'dsn-grid'
		), false, true );

		wp_enqueue_script( self::SWIPER );


	}

	public function register_style() {

		//--> fancybox
		wp_register_style( self::FANCYBOX, OHIXM_MODULES_PATH . '/fancybox/fancybox.css', array(), '4.0.26' );
		//--> Swiper
		wp_register_style( self::SWIPER, OHIXM_MODULES_PATH . '/swiper/swiper.min.css', array(), '11.1.9' );
		//--> Flickr's Justified Gallery
		wp_register_style( self::FJ_Gallery, OHIXM_MODULES_PATH . '/fjGallery/fjGallery.css', array(), '1.0.7' );
		//--> animate headline
		wp_register_style( self::ANIMATED_HEADLINE, OHIXM_MODULES_PATH . '/animatedheadline/jquery.animatedheadline.css' );
		wp_enqueue_style( self::SWIPER );

	}

	public function enqueue_script_enable() {

		if ( ! ohixm_is_elementor_preview_mode() && get_theme_mod( 'button_style_theme' ) ) {
			wp_enqueue_script( "hdev-scripts" );
			wp_enqueue_script( 'smooth-scrollbar' );
			wp_localize_script( "hdev-scripts", "hdevParam", [
				"query"         => $_GET,
				"defaultTheme"  => ohixm_getStyleDefault(),
				"defaultScroll" => get_theme_mod( 'event_smooth_scrolling' ) ? "on" : "off"
			] );
		}
	}

	public function body_class( $classes ) {
		if ( $dotBg = ohixm_doc_elementor()->getVal( 'bg_dotes' ) ) {
			$classes[] = $dotBg;
		}


		return $classes;
	}
}

new OhixmFrontEnd();