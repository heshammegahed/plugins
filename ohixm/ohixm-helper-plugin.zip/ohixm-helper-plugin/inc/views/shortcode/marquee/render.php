<?php
$attr = get_query_var( 'attr' );


$shortcode = new ohixmShortCode( $attr );
$widget    = $shortcode->getWidgetBase();


$val = $shortcode->getVal( 'description' );
if ( ! $val ) {
	return false;
}


$option = [
	"speed"            => $shortcode->getVal( "speed", 0 ),
	"duplicatedNumber"            => $shortcode->getVal( "duplicatedNumber", 1 ),
	"duration"         => $shortcode->getVal( "duration", 5000 ),
	"gap"              => $shortcode->getVal( "gap", 20 ),
	"delayBeforeStart" => $shortcode->getVal( "delayBeforeStart", 1000 ),
	"direction"        => $shortcode->getVal( "direction", "left" ),
	"duplicated"       => boolval( $shortcode->getVal( "duplicated", true ) ),
	"pauseOnHover"     => boolval( $shortcode->getVal( "pauseOnHover" ) ),
	"startVisible"     => boolval( $shortcode->getVal( "startVisible", true ) ),
	"pauseOnCycle"     => boolval( $shortcode->getVal( "pauseOnCycle" ) ),
	"allowCss3Support" => boolval( $shortcode->getVal( "allowCss3Support", true ) ),

];


$widget->add_render_attribute( "description", 'class', [
	"dsn-text-marquee d-flex align-items-center",
	$shortcode->getSize(),
	$shortcode->getVal( 'title_color' )
] );


printf( '<div class="p-relative dsn-marquee over-hidden" data-dsn-option=\'%1$s\'><%2$s %3$s>%4$s</%2$s></div>',
	json_encode( $option ), $shortcode->getHtmlTag(), $widget->get_render_attribute_string( "description" ), $val );