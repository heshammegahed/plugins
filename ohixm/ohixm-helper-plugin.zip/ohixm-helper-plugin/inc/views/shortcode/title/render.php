<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new ohixmShortCode( $attr );


$widget      = $shortcode->getWidgetBase();
$title       = $shortcode->getVal( 'title' );
$num_title   = $shortcode->getVal( 'num_title' );
$description = $shortcode->getVal( 'description' );
$direction   = $shortcode->getVal( 'direction', '' );

if ( ! $title && ! $description ) {
	return;
}


$description_before = '';
$description_after  = '';

$size      = $shortcode->getSize();
$html_tag  = $shortcode->getHtmlTag();
$line_text = $shortcode->getLinetext();

$line_text_into = $shortcode->getVal( 'dsn_line_title_into' );


$line_text = $shortcode->getLinetext();


if ( $size ) {
	$widget->add_render_attribute( 'title', 'class', $size );
	$widget->add_render_attribute( 'num_title', 'class', $size );
}

if ( $line_text ) {
	$widget->add_render_attribute( 'title', 'class', $line_text );

}
if ( $line_text_into ) {
	$widget->add_render_attribute( 'span_title', 'class', $line_text_into );
}


$widget->add_render_attribute( 'section-title', 'class', [
	'section-title d-flex  ',
	$shortcode->getVal( 'space_section', 'mb-70' )
] );


$widget->add_render_attribute( 'num_title', 'class', [
	'dsn-heading-number p-relative title-block-lg d-block color-inherit-bg',
	$shortcode->getVal( 'dsn_title_animate', '' ),
	$shortcode->getVal( 'num_title_color'  , 'theme-color'),
	$shortcode->getLinetext('' , 'dsn_line_number')

] );


$widget->add_render_attribute( 'title', 'class', [
	'dsn-heading-title p-relative title-block-lg d-block color-inherit-bg',
	$shortcode->getVal( 'dsn_title_animate', '' ),
	$shortcode->getVal( 'use_as_stroke' ),
	$shortcode->getVal( 'title_color' )

] );

$widget->add_render_attribute( 'description', 'class', [
	'description p-relative color-inherit-bg',
	$shortcode->getVal( 'dsn_description_animate', '' ),
	$shortcode->getVal( 'description_color', 'heading-color' )
] );


$widget->add_render_attribute( 'span_description', 'class', $shortcode->getVal( 'dsn_line_description_into', 'p-10 background-theme' ) );


if ( $title ) {
	$title = sprintf( '<%1$s %2$s><span %3$s>%4$s</span></%1$s>',
		$html_tag,
		$widget->get_render_attribute_string( 'title' ),
		$widget->get_render_attribute_string( 'span_title' ),
		$title
	);
}
if ( $num_title ) {
	$num_title = sprintf( '<%1$s %2$s>%3$s</%1$s>',
		'span',
		$widget->get_render_attribute_string( 'num_title' ),
		$num_title
	);
}

if ( $description ) {
	if ( $direction ) {
		$widget->add_render_attribute( 'description', 'class', 'mb-10' );
		$description_before = sprintf( '<p %1$s><span %2$s>%3$s</span></p>',
			$widget->get_render_attribute_string( 'description' ),
			$widget->get_render_attribute_string( 'span_description' ),
			$description
		);
	} else {
		$widget->add_render_attribute( 'description', 'class', 'mt-10' );
		$description_after = sprintf( '<p %1$s><span %2$s>%3$s</span></p>',
			$widget->get_render_attribute_string( 'description' ),
			$widget->get_render_attribute_string( 'span_description' ),
			$description
		);
	}
}


printf( '<div %1$s> %5$s<div class="sub-section-title "> %2$s %3$s %4$s </div></div>',
	$widget->get_render_attribute_string( 'section-title' ),
	$description_before,
	$title,
	$description_after,
	$num_title
);