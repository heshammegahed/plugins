<#


var description = settings.description;
var description_before = '' ;
var description_after = '' ;



view.addInlineEditingAttributes( 'title' );


var title_html = '<' + settings.dsn_html_tag  + ' ' + view.getRenderAttributeString( 'title' ) + '>' + title + '</' + settings.dsn_html_tag + '>';

#>
<script>
    const html_tag = settings.dsn_html_tag;
    const title = settings.title;

    if (title) {
        view.addRenderAttribute( 'title', 'class', [ 'section-title d-flex',  settings.font_size , settings.dsn_line_text , settings.title_color , settings.use_as_troke ] );
        print( '<' + settings.dsn_html_tag  + ' ' + view.getRenderAttributeString( 'title' ) + '>' + title + '</' + settings.dsn_html_tag + '>' );
    }


</script>

<div class="section-title d-flex flex-column flex-wrap"></div>