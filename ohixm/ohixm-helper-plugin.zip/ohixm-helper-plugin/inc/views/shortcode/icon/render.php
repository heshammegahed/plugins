<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new ohixmShortCode( $attr );
$widget    = $shortcode->getWidgetBase();

$widget->add_render_attribute( 'icon', 'class', [
	'dsn-icon',
	$shortcode->getVal( 'bg_ver_icon' ),
	$shortcode->getVal( 'bg_icon' ),
] );
?>

<div class="d-flex">
    <div <?php $widget->print_render_attribute_string( 'icon' ) ?> >
		<?php $shortcode->printIcon( $shortcode->getVal( 'icon' ) ) ?>
    </div>
</div>
