<#
var title = settings.title;

if ( '' !== settings.link.url ) {
title = '<a href="' + settings.link.url + '">' + title + '</a>';
}


if(settings.use_as_title_cover){
    view.addRenderAttribute('title' , {
    'class'                : 'title-cover',
    'data-dsn-grid'        : 'move-section',
    'data-dsn-opacity'     : settings.optcity_to,
    'data-dsn-duration'    : settings.duration_title,
    'data-dsn-move'        : settings.move_to_duration,
    'data-dsn-triggerhook' : settings.triggerhook_duration,
    });
}

view.addRenderAttribute( 'title', 'class', [ 'dsn-heading-title',  settings.font_size , settings.dsn_line_text , settings.title_color , settings.use_as_troke ] );

view.addInlineEditingAttributes( 'title' );

var title_html = '<' + settings.dsn_html_tag  + ' ' + view.getRenderAttributeString( 'title' ) + '>' + title + '</' + settings.dsn_html_tag + '>';

print( title_html );
#>