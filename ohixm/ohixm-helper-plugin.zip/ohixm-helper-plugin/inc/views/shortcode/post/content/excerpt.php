<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

$show_excerpt = $shortcode->getVal( 'show_excerpt' );

if ( ! $show_excerpt ) {
	return;
}


if ( $ex = ohixm_excerpt( $shortcode->getValueNumberSlide( 'excerpt_length', 25 ) ) ) {
	printf( '<p class="section_description mt-15 max-w570 ">%1$s</p>', $ex );
}