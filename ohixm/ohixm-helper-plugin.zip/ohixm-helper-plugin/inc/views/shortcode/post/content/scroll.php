<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );
$widget    = $shortcode->getWidgetBase();


if ( ! $shortcode->getVal( 'scroll_horizontal' ) || ! $shortcode->getVal( $option['id'] . '_section_title' ) ) {
	return;
}


$idUp   = $option['id'] . '_up_title';
$idDown = $option['id'] . '_down_title';


$widget->add_render_attribute( $idUp, [
	'class' => 'dsn-animate-up letter-stroke'
] );
$widget->add_render_attribute( $idDown, [
	'class' => 'dsn-animate-down letter-stroke'
] );


?>

<article
        class="dsn-item-post <?php echo esc_attr( $option['id'] ) ?>-section dsn-container grid-item p-relative align-self-center">

	<?php
	if ( $val = $shortcode->getVal( $idUp, $option['up'] ) )
		printf( '<h2 %1$s>%2$s</h2>', $widget->get_render_attribute_string( $idUp ), $val );

	if ( $val = $shortcode->getVal( $idDown, $option['down'] ) )
		printf( '<h2 %1$s>%2$s</h2>', $widget->get_render_attribute_string( $idDown ), $val );
	?>


</article>
