<?php

/**
 * @var $attr ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

$meta_data             = $shortcode->getVal( 'meta_data', array() );
$show_category         = in_array( 'category', $meta_data );
$separator_between_cat = $shortcode->getVal( 'separator_between_cat', ', ' );


if ( $show_category && $cat = \DesignGrid\OhixmOption::PostCategory( '' ) ) {
	printf( '<div class="p-relative d-inline-block dsn-category dsn-bg metas mb-10 entry-meta">%s</div>', $cat );
}