<a href="<?php echo esc_url( get_the_permalink() ) ?>"
   class="effect-ajax dsn-post-link move-circle border-color-heading background-theme" data-dsn="parallax"
   data-dsn-ajax="work" title="<?php echo esc_attr( get_the_title() ) ?>">
    <svg width="11" height="18" viewBox="0 0 11 18" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M0 17.82C2.56667 14.94 5.31667 10.08 6.23333 9C5.31667 7.92 2.56667 3.06 0 0.18L0.183333 0C2.75 2.88 10.6333 8.64 11 9C10.6333 9.36 2.75 15.12 0.183333 18L0 17.82Z" fill="#FFF4E2"/>
    </svg>

</a>
