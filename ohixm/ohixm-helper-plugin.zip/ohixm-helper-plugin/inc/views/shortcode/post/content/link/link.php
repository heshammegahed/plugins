<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

if ( ! $shortcode->getVal( 'show_link', '1' ) ) {
	return;
}


$button = new \ohixmShortCode( $shortcode );
$button->setWidgetBase( $shortcode->getWidgetBase() );


$array_block = [
	'text'              => $shortcode->getVal( 'text_link', esc_html__( "View Case", 'ohixm' ) ),
	'style_btn'         => 'dsn-def-btn dsn-hover-icon',
	'bg_icon'           => 'background-transparent',
	'icon_align'        => 'right',
	'icon'              => [ "value" => "fas fa-long-arrow-alt-right", "library" => "fa-solid" ],
	'width_icon'        => [ 'unit' => 'px', 'size' => 14 ]
];


$button->getWidgetBase()->add_render_attribute( 'link', [
	'href'          => get_the_permalink( $shortcode->getSubVal( 'ID' ) ),
	'class'         => 'effect-ajax',
	'data-dsn-ajax' => 'work'

], null, true );


$button->setBlock( $array_block );
?>
<div class="d-flex mt-20 dsn-def-btn dsn-hover-icon dsn-icon-heading-color">
	<?php echo ohixm_shortcode_render_group( 'button', array( 'widget-base' => $button ) ); ?>
</div>

