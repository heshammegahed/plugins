<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$widget    = $shortcode->getWidgetBase();

if ( ! $shortcode->getVal( 'show_link', '1' ) ) {
	return;
}

?>
<a href="<?php echo esc_url( get_the_permalink() ) ?>" class="effect-ajax dsn-post-link move-circle background-theme"
   data-dsn="parallax"
   data-dsn-ajax="work" title="<?php echo esc_attr( get_the_title() ) ?>">
	<?php $shortcode->printVal( 'text_link', esc_html__( "View Case", 'ohixm' ) ) ?>

</a>
