<?php

/**
 * @var $shortcode ohixmShortCode
 */

use Elementor\Group_Control_Image_Size;

$shortcode = get_query_var('attr');
$widget    = $shortcode->getWidgetBase();


$slider_image = 'slide-image';
$widget->add_render_attribute('slide-image', [
    'class' => 'box-image-bg before-z-index dsn-swiper-parallax-transform',
    'data-overlay' => ohixm_overlay()
], null, true);




?>
<a class="effect-ajax box-image-link bg-shadow w-100" href="<?php echo esc_url(get_the_permalink()) ?>"
   data-dsn-ajax="work"
   title="<?php echo esc_attr(get_the_title()) ?>">


    <?php

    ohixm_get_img(
        array(
            'before' => sprintf('<div %1$s>', $widget->get_render_attribute_string($slider_image)),
            'after' => '</div>',
            'before_v' => sprintf('<div %1$s> %2$s', $widget->get_render_attribute_string($slider_image), '<div data-dsn="video">'),
            'after_v' => '</div></div>',
            'type' => 'img',
            'size' => $shortcode->getVal('image_size', 'large'),

            'attr' => array(
                'class' => 'cover-bg-img dsn-swiper-parallax-transform ',
                'data-dsn-position' => esc_attr(ohixm_position_image()),
            ),
        )
    );
    ?>
</a>