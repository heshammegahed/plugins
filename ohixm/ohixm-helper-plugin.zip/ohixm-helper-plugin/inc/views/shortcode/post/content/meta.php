<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var('attr');

$meta_data = $shortcode->getVal('meta_data', array());
$show_date = in_array('date', $meta_data);
$show_category = in_array('category', $meta_data);

$separator_between = $shortcode->getVal('separator_between', '||');


if (!$show_date && !$show_category) {
    return;
}

$category = ohixm_shortcode_render('post/content/category', $shortcode);
$transform_style = $shortcode->getVal('transform_style', '');

?>


<div class="post-meta  max-w750">

    <?php

    if (!$transform_style && !has_post_thumbnail()) {
        ohixm_shortcode_render('post/content/date', $shortcode, null, false);
        if ($show_date && $category):
            printf('<span class="mr-5 ml-5 separator-between">%s</span>', $separator_between);
        endif;
    }

    echo $category;
    ?>

</div>