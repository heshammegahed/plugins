<?php
$attr    = get_query_var( 'attr' );
$myposts = get_query_var( 'content' );


$shortcode = new ohixmShortCode( $attr );
$shortcode->setSubBlock( [ 'id_post' => get_the_ID() ] );


$widget = $shortcode->getWidgetBase();


$swiper_item = $shortcode->get_render_swiper_slide_attribute();

$shortcode->add_parallax_attributes( 'dsn-item-content', 'box' );
$widget->add_render_attribute( 'dsn-item-content', 'class', 'box-content d-flex ' );


$shortcode->add_parallax_attributes( 'dsn-post-content', 'content' );
$widget->add_render_attribute( 'dsn-post-content', 'class', 'post-content number-item  dsn-bg p-relative z-index-1 d-flex flex-column' );

$shortcode->add_parallax_attributes( 'slide-image', 'image' );

if ( $shortcode->getVal( 'style_post' ) === "cards" && $shortcode->getVal( 'style_cards_post' ) === "box-content-hover" )
	$widget->add_render_attribute( 'dsn-post-content', 'class', 'container' );


$is_card             = $shortcode->getVal( 'style_post', 'cards' ) === 'cards';
$isHover             = $shortcode->getVal( 'style_post' ) === "hover-list";
$style_cards_post    = $shortcode->getVal( 'style_cards_post', 'box-image-normal' );
$is_box_image_normal = $style_cards_post === 'box-image-normal';
$is_box_image_ohixm  = $style_cards_post === 'box-image-normal image-ohixm';


$transform_style = $shortcode->getVal( 'transform_style', '' );


echo ohixm_shortcode_render( 'post/content/scroll', $shortcode, [
	'id'   => 'start',
	'up'   => 'OUR',
	'down' => 'WORK'
] );


if ( $myposts->have_posts() ) :
	while ( $myposts->have_posts() ) :
		$myposts->the_post();
		$widget->add_render_attribute( 'dsn-item-post', 'class', [
			'dsn-item-post  grid-item over-hidden p-relative box-hover-image',
			'post-' . get_the_ID(),
			$is_card ? $style_cards_post . ' v-dark-head' : '',
			$shortcode->getVal( 'show_link', '1' ) ? 'dsn-show-link' : '',
			DesignGrid\OhixmOption::PostCategorySlug(),
			$shortcode->getVal( 'bg_ver_btn', '' ),
			$shortcode->getVal( 'bg_btn', 'background-main' ),
			$transform_style ? "dsn-cat-free" : ""
		], true );


		$widget->add_render_attribute( 'dsn-item-post', $swiper_item );

		?>

        <article <?php $widget->print_render_attribute_string( 'dsn-item-post' ) ?> >

            <div <?php $widget->print_render_attribute_string( 'dsn-item-content' ) ?>>
                <div class="p-relative v-dark-head d-flex box-image-link container-img ">
					<?php


					if ( has_post_thumbnail() )
						ohixm_shortcode_render( 'post/content/date', $shortcode, null, false );


					if ( ! $shortcode->getVal( "hide_image" ) && ! $isHover )
						echo ohixm_shortcode_render( 'post/content/image', $shortcode );

					if ( $transform_style ) {
						echo ohixm_shortcode_render( 'post/content/meta', $shortcode );
					}


					?>
                </div>

                <div <?php $widget->print_render_attribute_string( 'dsn-post-content' ) ?>>

                    <div class="post-title-info">
						<?php
						if ( ! $transform_style )
							echo ohixm_shortcode_render( 'post/content/meta', $shortcode );




						if ( $isHover ) {
							$widget->add_render_attribute( 'hover-title', [
								'class'       => 'p-relative dsn-style-hover',
								"data-dsn-fx" => $shortcode->getVal( 'style_hover_post', '1' ),
								"data-img"    => ohixm_get_scr_img( get_the_ID(), $shortcode->getVal( 'image_size', 'large' ) )
							]  , null ,true);
							printf( '<div %1$s>%2$s</div>',
								$widget->get_render_attribute_string( 'hover-title' ),
								ohixm_shortcode_render( 'post/content/title', $shortcode )
							);
						} else
							echo ohixm_shortcode_render( 'post/content/title', $shortcode );
						?>
                    </div>

					<?php if ( in_array( $style_cards_post, [
							'box-image-normal',
							'box-content-hover',
							'box-image-normal image-ohixm'
						] ) || ! $is_card ): ?>
                        <div class="post-description-info ">
							<?php
							echo ohixm_shortcode_render( 'post/content/excerpt', $shortcode );

							echo ohixm_shortcode_render( 'post/content/link/link', $shortcode );
							?>
                        </div>
					<?php endif; ?>

                </div>
            </div>


        </article>

	<?php endwhile;
endif;
wp_reset_postdata();
echo ohixm_shortcode_render( 'post/content/scroll', $shortcode, [
	'id'   => 'end',
	'up'   => 'AWESOME',
	'down' => 'DESIGNS'
] );