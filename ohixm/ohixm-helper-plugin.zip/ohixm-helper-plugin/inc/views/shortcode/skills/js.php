<#


view.addRenderAttribute('bg-mask' , 'class' , ['dsn-bg-mask' ,settings.background_mask ]);


view.addRenderAttribute( 'bg-mask', 'style', '--width-mask:'+settings.width_mask.size+settings.width_mask.unit+';' );
view.addRenderAttribute( 'bg-mask', 'style', '--width-calc-mask:'+settings.calc_width_mask.size+settings.calc_width_mask.unit+';' );

view.addRenderAttribute( 'bg-mask', 'style', '--height-mask:'+settings.height_mask.size+settings.height_mask.unit+';' );
view.addRenderAttribute( 'bg-mask', 'style', '--height-calc-mask:'+settings.calc_height_mask.size+settings.calc_height_mask.unit+';' );

view.addRenderAttribute( 'bg-mask', 'style', '--top-mask:'+settings.top_mask.size+settings.top_mask.unit+';' );
view.addRenderAttribute( 'bg-mask', 'style', '--left-mask:'+settings.left_mask.size+settings.left_mask.unit+';' );

view.addRenderAttribute( 'bg-mask', 'style', '--margin-top-mask:'+settings.margin_top_mask.size+settings.margin_top_mask.unit+';' );
view.addRenderAttribute( 'bg-mask', 'style', '--margin-left-mask:'+settings.margin_left_mask.size+settings.margin_left_mask.unit+';' );


#>

<div {{{ view.getRenderAttributeString( 'bg-mask' ) }}} ></div>