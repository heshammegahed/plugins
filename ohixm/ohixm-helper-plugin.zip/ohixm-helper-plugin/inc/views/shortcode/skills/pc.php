<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );

$widget = $shortcode->getWidgetBase();

$title_key = $shortcode->getItemKey( 'title', $option['index'] );

$widget->add_render_attribute( $title_key, 'class', 'dsn-title-award ' . $shortcode->getVal( 'dsn-title-skills', 'sm-title-block' ) );


if ( $title = $shortcode->getSubVal( 'title', esc_html__( 'Enter Text Skills', 'mestc' ) ) ) {

	printf( '<div class="d-flex head-content align-items-center mb-15">%3$s<h6 %1$s>%2$s</h6></div>', $widget->get_render_attribute_string( $title_key ), $title,
		$shortcode->getAttachImage( $shortcode->getSubVal( 'image' ), $shortcode->getSubVal( 'image_size' ) )
	);
}

if ( $num = $shortcode->getSubVal( 'number', '50' ) ) :


	$widget->add_render_attribute( 'fill', [
		'class' => [
			'fill dsn-animate-skill box-shadow',
			$shortcode->getVal( 'bg_item', 'background-transparent' ),
			$shortcode->getVal( 'bg_ver_item', '' )
		],
		'style' => 'width:' . $num . '%;'

	], null, true );


	printf( '<div class="bar-progress"><span %3$s data-width="%2$s" ><span %1$s>%2$s</span></span></div>', $widget->get_render_attribute_string( 'number' ), $num . "%", $widget->get_render_attribute_string( 'fill' ) );
endif;


