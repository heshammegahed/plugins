<?php

/**
 * @var $shortcode mestcShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );

$widget = $shortcode->getWidgetBase();


$content_key = $shortcode->getItemKey( 'description', $option['index'] );
$widget->add_render_attribute( $content_key, 'class', 'max-w750 testimonial-content p-large' );
$content = $shortcode->getSubVal( 'description' );
if ( $content ) {
	printf( '<div %s><p %s>%s</p></div>', $widget->get_render_attribute_string( 'quote' ), $widget->get_render_attribute_string( $content_key ), $content );
}