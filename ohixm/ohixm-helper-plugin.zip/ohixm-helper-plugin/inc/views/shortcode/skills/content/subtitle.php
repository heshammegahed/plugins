<?php

/**
 * @var $shortcode mestcShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );


$widget       = $shortcode->getWidgetBase();
$subtitle_key = $shortcode->getItemKey( 'subtitle', $option['index'] );
$widget->add_render_attribute( $subtitle_key, 'class', 'background-section' );
$subtitle = $shortcode->getSubVal( 'subtitle', esc_html__( 'subTitle', 'arctit' ) );
if ( $subtitle ) {
	printf( '<p class="subtitle p-relative line-shape  line-shape-after mb-15"><span %1$s>%2$s</span></p>', $widget->get_render_attribute_string( $subtitle_key ), $subtitle );
}