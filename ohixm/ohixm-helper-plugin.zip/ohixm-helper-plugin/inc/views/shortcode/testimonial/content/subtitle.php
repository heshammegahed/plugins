<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );


$widget       = $shortcode->getWidgetBase();
$subtitle_key = $shortcode->getItemKey( 'subtitle', $option['index'] );
$widget->add_render_attribute( $subtitle_key, 'class', 'sm-title-block p-relative mb-15' );
$subtitle = $shortcode->getSubVal( 'subtitle', esc_html__( 'subTitle', 'ohixm' ) );

if ( $subtitle ) {
	printf( '<h4 %1$s>%2$s</h4>', $widget->get_render_attribute_string( $subtitle_key ), $subtitle );
}