<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new ohixmShortCode( $attr, $items_key );


$items = $shortcode->getVal( 'items', array() );

if ( ! count( $items ) || ! is_array( $items ) ) {
	return;
}


$widget = $shortcode->getWidgetBase();

/**
 * testimonials
 */
$widget->add_render_attribute( 'testimonials', [
	'class'           => 'dsn-testimonials ohixm-swiper-slider dsn-swiper p-relative has-parallax-image',
	'data-dsn-option' => json_encode( $shortcode->getSwiperOption() )
] );

/**
 * testimonials-content
 */
$widget->add_render_attribute( 'swiper-slide', [
	'class' => [
		'swiper-slide',
		$shortcode->getVal( 'bg_ver_item', '' ),
		$shortcode->getVal( 'bg_item', 'background-transparent' ),
		$shortcode->getValBackdropFilter()
	]
] );


$widget->add_render_attribute( 'box-text', 'class', 'label box-text' );
$shortcode->add_parallax_attributes( 'box-text', 'content' );

$widget->add_render_attribute( 'image', 'class', 'avatar box-img dsn-auto' );
$shortcode->add_parallax_attributes( 'image', 'image' );


$widget->add_render_attribute( 'quote', 'class', 'quote' );
$shortcode->add_parallax_attributes( 'quote', 'description' );


?>

<div <?php $widget->print_render_attribute_string( 'testimonials' ) ?>>

    <div class="testimonials-content">


        <div class="testimonial-inner">
            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" viewBox="0 0 509 396.83"
                 enable-background="new 0 0 509 396.83" xml:space="preserve">
					<g>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M105.098,396.83c-2.062,0-4.122,0-6.183,0 c0.123-48.731,0.116-97.466,0.493-146.195c0.062-7.844-3.65-8.881-10.09-8.843c-29.772,0.182-59.545,0.047-89.318,0.026 C0,161.382,0,80.947,0,0c81.742,0,163.484,0,245.227,0c0.023,83.874,0.496,167.752-0.071,251.624 c-0.436,64.131-47.354,121.936-109.503,136.974C125.404,391.076,115.279,394.073,105.098,396.83z M127.891,360.509 c6.063-1.545,10.049-2.226,13.799-3.568c42.174-15.098,74.277-58.896,74.735-104.55c0.718-71.273,0.187-142.558,0.454-213.837 c0.03-7.696-2.596-10.07-10.136-10.038c-55.961,0.236-111.927,0.287-167.887-0.042c-8.413-0.049-10.398,3.014-10.363,10.831 c0.254,54.408,0.317,108.815-0.047,163.22c-0.061,8.994,3.321,10.93,11.452,10.803c25.744-0.405,51.505,0.184,77.245-0.329 c8.78-0.174,10.986,2.931,10.911,11.301c-0.363,40.63-0.164,81.264-0.163,121.897C127.891,350.262,127.891,354.325,127.891,360.509 z"/>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                              d="M368.871,396.83c-2.061,0-4.122,0-6.184,0 c0.057-48.133-0.099-96.267,0.354-144.395c0.081-8.996-3.268-10.854-11.386-10.722c-26.047,0.42-52.108-0.083-78.152,0.299 c-7.577,0.108-10.083-2.194-10.053-9.942c0.294-77.357,0.262-154.713,0.322-232.07C345.353,0,426.929,0,509,0 c0,89.562,0,179.125,0,268.687c-1.256,3.464-2.793,6.854-3.73,10.401c-15.376,58.112-51.126,95.756-109.9,110.431 C386.48,391.735,377.7,394.382,368.871,396.83z M391.554,360.501c5.951-1.528,9.958-2.176,13.686-3.57 c43.103-16.135,74.464-59.44,74.864-105.611c0.616-70.931,0.138-141.869,0.404-212.803c0.03-7.722-2.58-10.037-10.111-10.005 c-55.963,0.24-111.926,0.285-167.889-0.036c-8.406-0.048-10.429,3.048-10.392,10.853c0.245,54.405,0.31,108.813-0.049,163.216 c-0.059,9.03,3.45,10.9,11.528,10.778c25.741-0.39,51.504,0.193,77.245-0.325c8.785-0.178,10.956,2.917,10.878,11.284 c-0.368,40.629-0.167,81.263-0.165,121.897C391.554,350.25,391.554,354.318,391.554,360.501z"/>
                    </g>
				  </svg>
            <div class="swiper">
                <div class="swiper-wrapper">
					<?php foreach ( $items as $index => $item ) : $shortcode->setSubBlock( $item );
						$image = $shortcode->getAttachImage( $shortcode->getSubVal( 'image' ),
							$shortcode->getVal( 'image_size', 'thumbnail' ), array( 'class' => 'cover-bg-img' ) )
						?>
                        <div <?php $widget->print_render_attribute_string( 'swiper-slide' ) ?> >
							<?php
							if ( $image && ( $shortcode->getVal( 'style_image' ) || ohixm_is_elementor_preview_mode() ) ) {
								printf( '<div %s>%s</div>', $widget->get_render_attribute_string( 'image' ), $image . ' <svg width="25" height="22" viewBox="0 0 25 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M22.6562 10.9375H18.75V7.8125C18.75 6.08887 20.1514 4.6875 21.875 4.6875H22.2656C22.915 4.6875 23.4375 4.16504 23.4375 3.51562V1.17188C23.4375 0.522461 22.915 0 22.2656 0H21.875C17.5586 0 14.0625 3.49609 14.0625 7.8125V19.5312C14.0625 20.8252 15.1123 21.875 16.4062 21.875H22.6562C23.9502 21.875 25 20.8252 25 19.5312V13.2812C25 11.9873 23.9502 10.9375 22.6562 10.9375ZM8.59375 10.9375H4.6875V7.8125C4.6875 6.08887 6.08887 4.6875 7.8125 4.6875H8.20312C8.85254 4.6875 9.375 4.16504 9.375 3.51562V1.17188C9.375 0.522461 8.85254 0 8.20312 0H7.8125C3.49609 0 0 3.49609 0 7.8125V19.5312C0 20.8252 1.0498 21.875 2.34375 21.875H8.59375C9.8877 21.875 10.9375 20.8252 10.9375 19.5312V13.2812C10.9375 11.9873 9.8877 10.9375 8.59375 10.9375Z"/>
</svg>' );
							}
							?>
                            <div class="testimonial-item">

                                <div class="testimonial-content mb-25">

									<?php
									echo ohixm_shortcode_render( 'testimonial/content/subtitle', $shortcode, [
										'index' => $index
									] );
									echo ohixm_shortcode_render( 'testimonial/content/description', $shortcode, [
										'index' => $index
									] );
									?>
                                </div>
                                <div class="content-inner">
                                    <div class="d-flex align-items-center ">
										<?php

										if ( $image ) {
											printf( '<div %s>%s</div>', $widget->get_render_attribute_string( 'image' ),
												$image . ' <div class="icon"> <svg width="25" height="22" viewBox="0 0 25 22" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M22.6562 10.9375H18.75V7.8125C18.75 6.08887 20.1514 4.6875 21.875 4.6875H22.2656C22.915 4.6875 23.4375 4.16504 23.4375 3.51562V1.17188C23.4375 0.522461 22.915 0 22.2656 0H21.875C17.5586 0 14.0625 3.49609 14.0625 7.8125V19.5312C14.0625 20.8252 15.1123 21.875 16.4062 21.875H22.6562C23.9502 21.875 25 20.8252 25 19.5312V13.2812C25 11.9873 23.9502 10.9375 22.6562 10.9375ZM8.59375 10.9375H4.6875V7.8125C4.6875 6.08887 6.08887 4.6875 7.8125 4.6875H8.20312C8.85254 4.6875 9.375 4.16504 9.375 3.51562V1.17188C9.375 0.522461 8.85254 0 8.20312 0H7.8125C3.49609 0 0 3.49609 0 7.8125V19.5312C0 20.8252 1.0498 21.875 2.34375 21.875H8.59375C9.8877 21.875 10.9375 20.8252 10.9375 19.5312V13.2812C10.9375 11.9873 9.8877 10.9375 8.59375 10.9375Z"/>
</svg> </div>' );
										}

										if ( $name = $shortcode->getSubVal( 'name', 'The Name' ) ) {
											$name_key = $shortcode->getItemKey( 'name', $index );
											$widget->add_render_attribute( $name_key, 'class',
												'testimonial-name sm-title-block circle-before' );
											$name = sprintf( '<h4 %s>%s</h4>',
												$widget->get_render_attribute_string( $name_key ), $name );
										}


										if ( $position = $shortcode->getSubVal( 'position', 'The Position' ) ) {
											$position_key = $shortcode->getItemKey( 'position', $index );
											$widget->add_render_attribute( $position_key, 'class',
												'testimonial-position circle-before' );
											$position = sprintf( '<h5 %s>%s</h5>',
												$widget->get_render_attribute_string( $position_key ), $position );
										}

										if ( $name || $position ) {
											printf( '<div %s>%s</div>',
												$widget->get_render_attribute_string( 'box-text' ), $name . $position );
										}

										?>

                                    </div>
                                </div>

                            </div>

                        </div>
					<?php endforeach; ?>
                </div>
            </div>
        </div>

		<?php $shortcode->print_content_paginate_render(); ?>
    </div>
</div>
