<?php

/**
 * @var $shortcode ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );

$widget = $shortcode->getWidgetBase();
if ( ! $shortcode->getVal( 'show_link', '1' ) ) {
	return;
}

$link_key = $shortcode->getItemKey( 'link', $option['index'] );
$is_link  = $shortcode->getOptionArray( $shortcode->getSubVal( 'link' ), 'url' );

if ( ! $is_link && empty( $is_link ) ) {
	return '';
}


$widget->add_link_attributes( 'link', $shortcode->getSubVal( 'link', array() ), true );

$widget->add_render_attribute( 'link', [
//	'data-dsn' => "parallax",
	'class'    => 'background-theme'
]  , null ,true)

?>
<div class="d-flex justify-content-end dsn-list-icon">
    <a <?php $widget->print_render_attribute_string( 'link' ) ?>>
        <svg width="26" height="27" viewBox="0 0 26 27" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M2.08968 4.96224L2.08968 2.64591C2.08968 1.66512 2.88266 0.872146 3.85823 0.877364L24.1366 0.872147C25.1173 0.872147 25.9103 1.66512 25.9051 2.6407L25.9051 22.9138C25.9051 23.8946 25.1121 24.6876 24.1366 24.6824L21.8202 24.6824C20.829 24.6824 20.0308 23.8633 20.0517 22.8721L20.349 10.607L5.3555 25.6005C4.66164 26.2944 3.54521 26.2944 2.85135 25.6005L1.18193 23.9311C0.488072 23.2373 0.488073 22.1208 1.18193 21.427L16.1755 6.43343L3.89996 6.73079C2.90352 6.75688 2.08446 5.95868 2.08968 4.96224Z"
                  fill="var(--heading-color)"/>
        </svg>
    </a>
</div>

