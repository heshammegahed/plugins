<#
var title = settings.title;
var description = settings.description;
var description_before = '' ;
var description_after = '' ;


view.addRenderAttribute( 'title', 'class', [ 'dsn-heading-title d-inline-block',  settings.font_size , settings.dsn_line_text , settings.title_color , settings.use_as_troke ] );

view.addInlineEditingAttributes( 'title' );


var title_html = '<' + settings.dsn_html_tag  + ' ' + view.getRenderAttributeString( 'title' ) + '>' + title + '</' + settings.dsn_html_tag + '>';

#>

<div class="section-title d-flex flex-column flex-wrap"></div>