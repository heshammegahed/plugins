<?php

use Elementor\Group_Control_Image_Size;

$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content', array() );


$shortcode = new ohixmShortCode( $attr, $items_key );


$items = $shortcode->getVal( 'items', array() );

if ( ! count( $items ) || ! is_array( $items ) ) {
	return;
}

$widget = $shortcode->getWidgetBase();

$use_overlay_hover = $shortcode->getVal( 'use_overlay_hover', '1' );
$bg_ver_btn        = $shortcode->getVal( 'bg_ver_btn', '' );
$bg_btn            = $shortcode->getVal( 'bg_btn', 'background-main' );


$swiper_item = $shortcode->get_render_swiper_slide_attribute();
$isList      = $shortcode->getVal( 'use_list' );

$widget->add_render_attribute( 'service-item', 'class', [
	'service-item p-relative grid-item style-box box-hover-image',
	$bg_ver_btn,
	$bg_btn,
	$shortcode->getValBackdropFilter()
] );
$widget->add_render_attribute( 'service-item', $swiper_item );


$widget->add_render_attribute( 'service-item-inner', 'class', [ 'service-item-inner  h-100' ] );
$shortcode->add_parallax_attributes( 'service-item-inner', 'content' );

$startList = $isList ? '<div class="p-relative">' : '';
$endList   = $isList ? '</div>' : '';


foreach ( $items as $index => $item ) :
	$shortcode->setSubBlock( $item );


	//-->title
	$title = ohixm_shortcode_render( 'service/title', $shortcode, [
		'index' => $index,
	] );


	$description = ohixm_shortcode_render( 'service/description', $shortcode, [
		'index' => $index,
	] );

	$icon = $shortcode->getIcon( $shortcode->getSubVal( 'icon' ) );

	if ( $isList ) {
		$link = ohixm_shortcode_render( 'service/link-list', $shortcode, [
			'index' => $index,
		] );
	} else {
		$link = ohixm_shortcode_render( 'service/ohixm', $shortcode, [
			'index' => $index,
		] );
	}

	?>


    <div <?php $widget->print_render_attribute_string( 'service-item' ) ?> >

        <div <?php $widget->print_render_attribute_string( 'service-item-inner' ) ?>>
			<?php
			if ( $shortcode->getVal( 'with_image' ) ) {
				$imageBg = $shortcode->getSubVal( 'image', [ 'id' => false, "url" => false ] );
				if ( $imageBg['id'] || $imageBg['url'] ) {
					printf( "<div class='box-img-shadow p-absolute'><div class='img-box-parallax  before-z-index'>%s</div></div>", $shortcode->getAttachImage( $imageBg, $shortcode->getSubVal( 'image_size' ), [
						'class' => 'cover-bg-img'
					] ) );
				}
			}


			if ( $icon ) {
				printf( '<div class="dsn-icon d-block "><div class="icon-wrapper dsn-auto number-item dsn-background-inherit dsn-bg-before %1$s"><div class="dsn-bg"></div>%2$s</div></div>',
					$shortcode->getVal( 'bg_ver_icon' ) . ' ' . $shortcode->getVal( 'bg_icon', 'background-transparent' )
					, $icon );
			}

			printf( '<div class="service-content p-relative">%1$s %2$s %3$s</div>', $startList . $title, $description . $endList, $link );

			?>

        </div>
    </div>

<?php endforeach; ?>