<?php
/**
 * @var $shortcode \ohixmShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );



if ( ! $option['show_button'] || ! $shortcode->getVal( 'dsn_views' ) ) {
	return '';
}

$index  = $option['index'];
$widget = $shortcode->getWidgetBase();

$link_tag_2 = $shortcode->getItemKey( 'link2', $index );
$widget->add_link_attributes( $link_tag_2, $shortcode->getSubVal( 'link2', array() ) );
$widget->add_render_attribute( $link_tag_2, [
	'class'    => [ 'dsn-btn move-circles text-center  swiper-animate-head  mr-15' ],
	'data-dsn' => 'parallax',
] );


$widget->add_render_attribute( $link_tag_2, [
	'class' => [
		'btn-slider-2 border-color-default',
		$shortcode->getVal( 'bg_ver_button-2', '' ),
		$shortcode->getVal( 'bg_button-2', 'background-transparent' ),
	],
] );

$text_link = $shortcode->getItemKey( 'text_link2', $index );

printf( '<a %1$s><span %2$s>%3$s</span></a>',
	$widget->get_render_attribute_string( $link_tag_2 ),
	$widget->get_render_attribute_string( $text_link ),
	$shortcode->getSubVal( 'text_link2', esc_html__( "VIEW CASE", 'ohixm' ) )

);