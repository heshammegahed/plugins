<?php

/**
 * @var $shortcode \mestcShortCode
 */
$shortcode = get_query_var( 'attr' );
$option    = get_query_var( 'content' );
