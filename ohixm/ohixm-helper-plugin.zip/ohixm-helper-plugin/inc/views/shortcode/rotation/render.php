<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new ohixmShortCode( $attr );
$widget    = $shortcode->getWidgetBase();

?>

<svg class="circle-text-rotation" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
     width="143.687px" height="139.25px" viewBox="0 0 143.687 139.25" enable-background="new 0 0 143.687 139.25"
     xml:space="preserve">
    <g>
        <use xlink:href="#circlePath" fill="none"/>
        <text fill="#000">
            <textPath xlink:href="#circlePath" <?php $widget->print_render_attribute_string( 'text' ); ?>>
                <?php $shortcode->printVal('text', 'Enter text'); ?>
            </textPath>
        </text>
    </g>
</svg>