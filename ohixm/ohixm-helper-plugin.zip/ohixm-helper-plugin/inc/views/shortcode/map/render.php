<?php
$attr      = get_query_var( 'attr' );
$items_key = get_query_var( 'content' );


$shortcode = new ohixmShortCode( $attr );

$lat  = $shortcode->getVal( 'lat' );
$lang = $shortcode->getVal( 'lng' );
$zoom = $shortcode->getVal( 'zoom', 14 );

$widget = $shortcode->getWidgetBase();
$widget->add_render_attribute( 'map', [
	'class'         => 'map-custom',
	'data-dsn-lat'  => esc_attr( $lat ),
	'data-dsn-len'  => esc_attr( $lang ),
	'data-dsn-zoom' => esc_attr( $zoom ),
] );

printf( '<div %s></div>', $widget->get_render_attribute_string( 'map' ) );
