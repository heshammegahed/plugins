<div id="dsn_header_template" class="dialog-header dialog-lightbox-header">
    <img src="https://s3.envato.com/files/267820262/design%20grid%20small.png" alt="design_grid" width="35"
         height="35">
    <div class="tabs">
        <div class="tab-item dsn-active" data-dsn-filter="*"><?php esc_html_e( "all" ) ?></div>
		<?php
		foreach ( $categories as $key => $value ):
			printf( '<div class="tab-item" data-dsn-filter=".dsn-%1$s">%2$s</div>', $key, $value );
		endforeach;

		?>


    </div>
    <div class="dsn-icon-temp-close">
        <i class="eicon-close" aria-hidden="true" title="Close"></i>
        <span class="elementor-screen-only">Close</span>
    </div>
</div>