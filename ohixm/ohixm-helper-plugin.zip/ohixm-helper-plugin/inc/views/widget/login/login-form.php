<?php


$title    = isset( $instance['title'] ) ? $instance['title'] : '';
$username = isset( $instance['username'] ) ? $instance['username'] : '';


/**
 * @var array $out
 */
$out = isset( $ohixmLogin ) ? $ohixmLogin : [];


?>
    <p>
        <label for='<?php echo esc_attr( $id_title ) ?>'><?php _e( 'Title:', 'ohixm' ); ?></label>
        <input type='text' class='widefat' id='<?php echo esc_attr( $id_title ) ?>'
               name='<?php echo esc_attr( $name_title ) ?>'
               value='<?php echo esc_attr( $title ) ?>'/>

    </p>
<?php
foreach ( $out as $value ):
	echo $value;
endforeach;
