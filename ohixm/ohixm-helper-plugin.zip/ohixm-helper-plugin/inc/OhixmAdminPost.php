<?php


class OhixmAdminPost {

	private $workSlug, $workCatSlug, $footerSlug = "dsn-footer";

	public function __construct() {
		/**
		 * Work
		 */
		$this->workSlug    = ohixm_project_slug();
		$this->workCatSlug = ohixm_category_slug();
		add_theme_support( 'post-thumbnails', $this->workSlug );

		add_action( 'init', [ $this, 'adminPost' ] );
		add_action( 'wp_nav_menu_item_custom_fields', [ $this, 'menu_item_text_ajax' ], 10, 2 );
		add_action( 'wp_update_nav_menu_item', [ $this, 'save_menu_item_text_ajax' ], 10, 2 );
		add_action( 'init', [ $this, 'enqueue_post' ] );

		add_filter( 'manage_' . $this->workSlug . '_posts_columns', [ $this, "posts_columns" ] );
		add_action( 'manage_' . $this->workSlug . '_posts_custom_column', [ $this, "posts_custom_columns" ] );


	}


	public function adminPost() {
		$this->createWork();
		$this->createFooter();
		flush_rewrite_rules();
	}

	private function createWork() {
		register_post_type( $this->workSlug, array(
			'menu_icon'       => OHIXM__PLUGIN_DIR_URL . '/assets/img/portfolio.svg',
			'hierarchical'    => true,
			'capability_type' => 'post',
			'supports'        => array( 'title', 'editor', 'author', 'thumbnail', 'revisions', 'excerpt' ),
			'labels'          => array(
				'name'         => esc_html__( 'Works', 'ohixm' ),
				'new_item'     => esc_html__( 'New Work', 'ohixm' ),
				'add_new'      => esc_html__( 'Add Work', 'ohixm' ),
				'add_new_item' => esc_html__( 'Add New Work', 'ohixm' ),
			),
			'rewrite'         => array( 'slug' => ohixm_custom_project_slug(), 'with_front' => false ),
			'show_in_rest'    => true,
			'public'          => true,

		) );
		$this->createCategory( $this->workCatSlug, $this->workSlug, ohixm_custom_category_slug() );
	}


	private function createCategory( string $catSlug, string $postType, string $custSlug ) {


		register_taxonomy( $catSlug, $postType, array(
			'hierarchical' => true,
			'labels'       => array(
				'name'                       => esc_html__( 'Categories', 'ohixm' ),
				'singular_name'              => esc_html__( 'Categories', 'ohixm' ),
				'search_items'               => esc_html__( 'Search Categories', 'ohixm' ),
				'popular_items'              => esc_html__( 'Popular Categories', 'ohixm' ),
				'all_items'                  => esc_html__( 'All Categories', 'ohixm' ),
				'parent_item'                => null,
				'parent_item_colon'          => null,
				'edit_item'                  => esc_html__( 'Edit Categories', 'ohixm' ),
				'update_item'                => esc_html__( 'Update Categories', 'ohixm' ),
				'add_new_item'               => esc_html__( 'Add New Categories', 'ohixm' ),
				'new_item_name'              => esc_html__( 'New Categories Name', 'ohixm' ),
				'separate_items_with_commas' => esc_html__( 'Separate Categories with commas', 'ohixm' ),
				'add_or_remove_items'        => esc_html__( 'Add or remove Categories', 'ohixm' ),
				'choose_from_most_used'      => esc_html__( 'Choose from the most used Categories', 'ohixm' ),
				'not_found'                  => esc_html__( 'No Categories found.', 'ohixm' ),
				'menu_name'                  => esc_html__( 'Categories', 'ohixm' ),
			),
			'show_ui'      => true,
			'query_var'    => true,
			'show_in_rest' => true,
			'rewrite'      => array( 'slug' => $custSlug, 'with_front' => false ),
		) );
	}

	private function createFooter() {
		register_post_type( $this->footerSlug, array(
			'menu_icon'           => 'dashicons-embed-generic',
			'hierarchical'        => true,
			'capability_type'     => 'post',
			'supports'            => array( 'title', 'thumbnail', 'revisions' ),
			'labels'              => array(
				'name'         => esc_html__( 'Footer', 'ohixm' ),
				'new_item'     => esc_html__( 'New Footer', 'ohixm' ),
				'add_new'      => esc_html__( 'Add Footer', 'ohixm' ),
				'add_new_item' => esc_html__( 'Add New Footer', 'ohixm' ),
			),
			'rewrite'             => array( 'slug' => $this->footerSlug, 'with_front' => false ),
//			'publicly_queryable'  => false,
			'show_in_rest'        => false,
			'exclude_from_search' => true,
			'public'              => true,
		) );


	}


	function menu_item_text_ajax( $item_id ) {
		$menu_item_desc = get_post_meta( $item_id, '_menu_item_text_ajax', true );
		?>
        <div style="clear: both;padding-top: 10px;margin-bottom: 10px">
            <span class="description" style="margin-bottom: 5px"><?php _e( "Text Ajax", 'ohixm' ); ?></span><br/>
            <input type="hidden" class="nav-menu-id" value="<?php echo $item_id; ?>"/>
            <div class="logged-input-holder">
                <input type="text" name="menu_item_text_ajax[<?php echo $item_id; ?>]"
                       id="menu-item-desc-<?php echo $item_id; ?>" value="<?php echo esc_attr( $menu_item_desc ); ?>"/>
            </div>
        </div>
		<?php
	}


	function save_menu_item_text_ajax( $menu_id, $menu_item_db_id ) {
		if ( isset( $_POST['menu_item_text_ajax'][ $menu_item_db_id ] ) ) {
			$sanitized_data = sanitize_text_field( $_POST['menu_item_text_ajax'][ $menu_item_db_id ] );
			update_post_meta( $menu_item_db_id, '_menu_item_text_ajax', $sanitized_data );
		} else {
			delete_post_meta( $menu_item_db_id, '_menu_item_text_ajax' );
		}
	}

	public function enqueue_post() {

		if ( ! class_exists( '\Elementor\Plugin' ) && get_theme_mod( 'ajax_pages' ) )
			return;

		if ( is_admin() )
			return;


		add_action( 'wp_enqueue_scripts', function () {


			foreach ( ohixm_get_post_array( ohixm_footer_slug() ) as $id => $title ):

				$post = \Elementor\Core\Files\CSS\Post::create( $id );
				$name = $post->get_name() . '-' . $post->get_post_id();
				wp_enqueue_style( $name, $post->get_url() );

			endforeach;
			if ( ! ohixm_is_built_with_elementor() )
				wp_enqueue_style( "elementor-frontend" );
		}, 99 );

	}


	public function posts_columns( $defaults ) {
		$defaults['wdm_post_thumbs'] = __( 'Featured Image' ); //name of the column

		return $defaults;
	}

	public function posts_custom_columns( $column_name ) {


		if ( $column_name === 'wdm_post_thumbs' ) {
			the_post_thumbnail( array( 80, 80 ) ); //size of the thumbnail
		}
	}
}


new OhixmAdminPost();
