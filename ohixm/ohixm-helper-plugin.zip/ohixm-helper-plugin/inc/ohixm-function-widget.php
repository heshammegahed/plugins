<?php

add_action( 'widgets_init', function () {

	$before_widget = '<div id="%1$s" class="widget %2$s">';
	$after_widget  = '</div>';
	$before_title  = '<h4 class="title-s heading title-style">';
	$after_title   = '</h4>';

	/**
	 *
	 * Woocommerce  Sidebar Blog
	 *
	 */
	register_sidebar( array(
		'id'            => 'wc-sidebar-1',
		'name'          => esc_html__( 'Ohixm Woocommerce Sidebar', 'ohixm' ),
		'description'   => esc_html__( 'This is the widgetized Woocommerce sidebar.', 'ohixm' ),
		'before_widget' => $before_widget,
		'after_widget'  => $after_widget,
		'before_title'  => $before_title,
		'after_title'   => $after_title,
	) );


	/**
	 *
	 * Woocommerce  Cart
	 *
	 */
	register_sidebar( array(
		'id'            => 'wc-sidebar-cart',
		'name'          => esc_html__( 'ohixm Sidebar Menu', 'ohixm' ),
		'description'   => esc_html__( 'This is the widgetized Cart Woocommerce. & Search & Login', 'ohixm' ),
		'before_widget' => $before_widget,
		'after_widget'  => $after_widget,
		'before_title'  => $before_title,
		'after_title'   => $after_title,
	) );


} );


ohixm_get_template_render( 'widget/OhixmLogin' );

add_action( 'widgets_init', function() {
	register_widget( 'OhixmLogin' );
});