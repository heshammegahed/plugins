<?php


/**
 *
 *
 *
 *
 * Class follow_me_widget
 *
 *
 *
 */
class OhixmLogin extends WP_Widget {

	private $ohixm_title;

	/**
	 * profile_widget constructor.
	 */
	public function __construct() {
		$this->ohixm_title = esc_html__( 'Ohixm Login', 'ohixm' );


		$widget_ops = array(
			'classname'                   => 'widget_ohixm_login ohixm-login',
			'description'                 => esc_html__( 'Custom Login Ajax.', 'ohixm' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'ohixm_ohixm_login', esc_html__( 'ohixm Ohixm Login', 'ohixm' ), $widget_ops );

	}


	/**
	 *
	 * ========================================
	 *      front-end display of widget
	 * ========================================
	 *
	 * @param array $args
	 * @param array $instance
	 */
	public function widget( $args, $instance ) {

		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}


		echo ohixm_view( 'widget/login/login-widget', array(
			'args'        => $args,
			'instance'    => $instance,
			'ohixm_title' => $this->ohixm_title
		) );
	}


	private function ohixm_login_view( $ohixmLogin, $instance, $name, $label, $default = '' ) {
		return sprintf( '<p><label for="%1$s">%2$s</label><input type="text" class="widefat" id="%1$s" name="%3$s" value="%4$s"/></p>',
			$this->get_field_id( $name ),
			$label,
			$this->get_field_name( $name ),
			isset( $instance[ $name ] ) ? $instance[ $name ] : $default
		);
	}

	private function ohixm_login_view_text( $ohixmLogin, $instance, $name, $label, $default = '' ) {
		return sprintf( '<p><label for="%1$s">%2$s</label><textarea type="text" class="widefat" id="%1$s" name="%3$s">%4$s</textarea></p>',
			$this->get_field_id( $name ),
			$label,
			$this->get_field_name( $name ),
			isset( $instance[ $name ] ) ? $instance[ $name ] : $default
		);
	}


	/**
	 *
	 * ========================================
	 *      back-end display of widget
	 * ========================================
	 *
	 * @param array $instance
	 *
	 * @return string
	 */
	public function form( $instance ) {

		$id   = $this->get_field_id( 'title' );
		$name = $this->get_field_name( 'title' );
		$out  = [];

		$out[] = $this->ohixm_login_view( $this, $instance, 'username', esc_html__( 'Username', 'ohixm' ), esc_html__( 'Username or Email Address', 'ohixm' ) );
		$out[] = $this->ohixm_login_view( $this, $instance, 'password', esc_html__( 'Password', 'ohixm' ), esc_html__( 'Password', 'ohixm' ) );
		$out[] = $this->ohixm_login_view( $this, $instance, 'remember', esc_html__( 'Remember', 'ohixm' ), esc_html__( 'Remember Me', 'ohixm' ) );
		$out[] = $this->ohixm_login_view( $this, $instance, 'login', esc_html__( 'Login', 'ohixm' ), esc_html__( 'Login', 'ohixm' ) );
		$out[] = $this->ohixm_login_view( $this, $instance, 'forget_password', esc_html__( 'Forget Password', 'ohixm' ), esc_html__( 'Forget Password', 'ohixm' ) );
		$out[] = $this->ohixm_login_view( $this, $instance, 'register', esc_html__( 'Register', 'ohixm' ), esc_html__( 'Register', 'ohixm' ) );
		$out[] = $this->ohixm_login_view_text( $this, $instance, 'wrong', esc_html__( 'Wrong Message', 'ohixm' ), esc_html__( 'Wrong username or password', 'ohixm' ) );
		$out[] = $this->ohixm_login_view_text( $this, $instance, 'success', esc_html__( 'Success Message', 'ohixm' ), esc_html__( 'Login Success, redirecting...', 'ohixm' ) );


		echo ohixm_view( 'widget/login/login-form', array(
			'instance'    => $instance,
			'ohixmLogin'  => $out,
			'id_title'    => $id,
			'name_title'  => $name,
			'ohixm_title' => $this->ohixm_title
		) );
	}


	public function update( $new_instance, $old_instance ) {

		$instance           = $old_instance;
		$instance['title']  = sanitize_text_field( $new_instance['title'] );
		$instance['username']  = sanitize_text_field( $new_instance['username'] );
		$instance['password']  = sanitize_text_field( $new_instance['password'] );
		$instance['remember']  = sanitize_text_field( $new_instance['remember'] );
		$instance['login']  = sanitize_text_field( $new_instance['login'] );
		$instance['forget_password']  = sanitize_text_field( $new_instance['forget_password'] );
		$instance['register']  = sanitize_text_field( $new_instance['register'] );
		$instance['wrong']  = sanitize_text_field( $new_instance['wrong'] );
		$instance['success']  = sanitize_text_field( $new_instance['success'] );


		return $instance;
	}


}

