<?php
/**
 * Normal Static Setting
 */
Kirki::add_section( $dsn_section, array(
	'panel'       => $dsn_panel,
	'title'       => esc_html__( 'Footer Default', 'ohixm' ),
	'description' => esc_html__( 'When you create a page, it\'s going to be default.', 'ohixm' )
) );

Kirki::add_field( $dsn_customize, [
	'type'            => 'radio',
	'settings'        => 'type_footer',
	'label'           => esc_html__( "Type Footer", "ohixm" ),
	'section'         => $dsn_section,
	'default'         => 'default',
	'priority'        => 10,
	'choices'         => [
		'default' => esc_html__( "Default", "ohixm" ),
		'custom'  => esc_html__( "Custom", "ohixm" )
	],
	'transport'       => 'auto',
	'partial_refresh' => [
		'type_footer' => [
			'selector'        => '#dsn_footer',
			'render_callback' => 'default',
		]
	]

] );

new \Kirki\Field\Select( [
	'settings' => 'choose_template_footer',
	'label'    => esc_html__( "Choose Template Footer", "ohixm" ),
	'section'  => $dsn_section,
	'priority' => 10,
	'choices'  => ohixm_get_post_array( ohixm_footer_slug() ),

	'active_callback' => [
		[
			'setting'  => 'type_footer',
			'operator' => '==',
			'value'    => 'custom',
		],
	]
] );

