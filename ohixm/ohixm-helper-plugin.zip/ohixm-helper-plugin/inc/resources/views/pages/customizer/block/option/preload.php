<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Preload', 'ohixm' ),
	'icon'  => 'dashicons-welcome-view-site',

) );


Kirki::add_field( $dsn_customize, [
	'type'        => 'toggle',
	'settings'    => 'page_preloader',
	'label'       => esc_html__( 'Page Preloader', 'ohixm' ),
	'description' => esc_html__( 'Enable preloader mask while the page is loading.', 'ohixm' ),
	'section'     => $dsn_section,
	'default'     => '1',
] );