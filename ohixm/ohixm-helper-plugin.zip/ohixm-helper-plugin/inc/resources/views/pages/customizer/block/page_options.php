<?php


$panels = $dsn_panel . "-pages-option";

Kirki::add_panel( $panels, array(
	'title'       => esc_html__( 'Pages Settings', 'ohixm' ),
	'description' => esc_html__( 'Options Pages Theme', 'ohixm' ),
	'panel'       => $dsn_panel,
	'icon'        => 'dashicons-screenoptions'
) );


ohixm_resources_customize( 'option/page/home', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-home',
) );

ohixm_resources_customize( 'option/page/archive', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-archive',
) );


ohixm_resources_customize( 'option/page/404', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-404',
) );


ohixm_custom_Label( $dsn_section, 'Code Html' );

Kirki::add_field( $dsn_customize, [
	'type'      => 'code',
	'settings'  => 'html_head_code',
	'label'     => esc_html__( 'Code HTML Header', 'ohixm' ),
	'section'   => $dsn_section,
	'default'   => '',
	'transport' => 'postMessage',
	'choices'   => [
		'language' => 'html',
	],
	'priority'  => 160,
] );


Kirki::add_field( $dsn_customize, [
	'type'      => 'code',
	'settings'  => 'html_footer_code',
	'label'     => esc_html__( 'Code HTML Footer', 'ohixm' ),
	'section'   => $dsn_section,
	'default'   => '',
	'transport' => 'postMessage',
	'choices'   => [
		'language' => 'html',
	],
	'priority'  => 161,
] );


