<?php
Kirki::add_section( $dsn_section, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'Style', 'ohixm' ),
	'icon'  => 'dashicons-admin-customizer',

) );


Kirki::add_field( $dsn_customize, [
	'type'     => 'radio',
	'settings' => 'global_style_setting',
	'label'    => esc_html__( "Theme Color", "ohixm" ),
	'section'  => $dsn_section,
	'default'  => 'v-dark',
	'priority' => 10,
	'choices'  => [
		'v-dark'  => esc_html__( "Dark", "ohixm" ),
		'v-light' => esc_html__( "Light", "ohixm" )
	]

] );

Kirki::add_field( $dsn_customize, [
	'type'     => 'toggle',
	'settings' => 'button_style_theme',
	'label'    => esc_html__( 'Show Button Style Theme', 'ohixm' ),
	'section'  => $dsn_section,
	'default'  => 0,

] );


Kirki::add_field( $dsn_customize, [
	'type'        => 'toggle',
	'settings'    => 'dsn_lazy_image',
	'label'       => esc_html__( 'Lazy Load Image', 'ohixm' ),
	'description' => esc_html__( 'This feature stops offscreen images from loading until a visitor scrolls to them. Make your page load faster, use less bandwidth and fix the “defer offscreen images” recommendation from a Google PageSpeed test.', 'ohixm' ),
	'section'     => $dsn_section,
	'default'     => 0,

] );