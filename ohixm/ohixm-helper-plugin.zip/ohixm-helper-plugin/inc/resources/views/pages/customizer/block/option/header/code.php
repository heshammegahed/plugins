<?php
Kirki::add_section( $dsn_section . '_html', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Code HTml', 'ohixm' )

) );




Kirki::add_section( $dsn_section . '_css', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Add Code CSS', 'ohixm' )

) );


Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'css_head_code',
    'label'     => esc_html__( 'Code CSS Header', 'ohixm' ),
    'section'   => $dsn_section . '_css',
    'default'   => '',
    'choices'   => [
        'language' => 'css',
    ],
    'transport' => 'postMessage',
    'js_vars'   => [
        [
            'element'  => '#ohixm_code_css',
            'function' => 'html',
        ]
    ]
] );

Kirki::add_section( $dsn_section . '_js', array(
    'panel' => $dsn_panel,
    'title' => esc_html__( 'Add Code JS', 'ohixm' )

) );
Kirki::add_field( $dsn_customize, [
    'type'      => 'code',
    'settings'  => 'js_head_code',
    'label'     => esc_html__( 'Code JS Header', 'ohixm' ),
    'section'   => $dsn_section . '_js',
    'default'   => '',
    'choices'   => [
        'language' => 'js',
    ],
    'transport' => 'auto',
    
] );
