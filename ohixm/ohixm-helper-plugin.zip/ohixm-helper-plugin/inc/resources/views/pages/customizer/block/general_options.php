<?php

$panels = $dsn_panel . "-general-option";



Kirki::add_panel( $panels, array(
	'panel' => $dsn_panel,
	'title' => esc_html__( 'General Style', 'ohixm' ),
	'icon'  => 'dashicons-buddicons-topics',

) );



ohixm_resources_customize( 'option/style', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-style',
) );

ohixm_resources_customize( 'option/portfolio', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-portfolio',
) );


ohixm_resources_customize( 'option/menu', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-menu',
) );

ohixm_resources_customize( 'option/color_site', array(
	'dsn_panel'     => $panels,
	'dsn_customize' => $dsn_customize,
	'dsn_section'   => $dsn_section . '-color_site',

) );