<?php

namespace Dsn\Element;


use Elementor\Controls_Manager;
use ohixmShortCode;
use Elementor\Widget_Base;

class  OhixmLayout extends Widget_Base {

	use Ohixm_Widget_Base;

	private $swiper_option = array();


	/**
	 * @var null|ohixmShortCode
	 */
	private $shortcode = null;

	protected $style_item = '.dsn-grid-layout';
	protected $style_layout = '.dsn-grid-layout';
	protected $default_mobile = true;

	protected $range_col = 30;
	protected $range_row = 30;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_layouts';
	}


	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'ohixm' ] );
	}

	/**
	 * @return array
	 */
	protected function getLayoutStyle(): array {
		return array(
			'dsn-grid'                                        => esc_html__( "Grid", 'ohixm' ),
			'dsn-isotope'                                     => esc_html__( "Masonry", 'ohixm' ),
			'dsn-masonry-grid dsn-isotope'                    => esc_html__( "Masonry Grid", 'ohixm' ),
			'dsn-masonry-grid dsn-masonry-grid-2 dsn-isotope' => esc_html__( "Masonry Grid 2", 'ohixm' ),
			'flexibly-hover'                                  => esc_html__( "Flexible Hover", 'ohixm' ),
		);
	}

	public function add_parallax_attributes( $element, $id, ohixmShortCode $shortcode ): OhixmLayout {
		$this->shortcode = $shortcode;
		if ( ! $this->shortcode->getVal( 'parallax' ) ) {
			return $this;
		}

		$parallax = $this->shortcode->getVal( 'parallax_' . $id, array( 'unit' => '%', 'size' => 0 ) );
		$size     = $this->shortcode->getOptionArray( $parallax, 'size' );
		if ( $size ):
			$unit = $this->shortcode->getOptionArray( $parallax, 'unit', '%' );
			if ( $unit !== '%' ) {
				$unit = '';
			}

			$this->add_render_attribute( $element, 'data-swiper-parallax', $size . $unit );
		endif;
		$scale = $this->shortcode->getValueNumberSlide( 'scale_' . $id, 1 );

		if ( $scale !== 1 && $scale !== '' ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-scale', $scale );
		}

		$opacity = $this->shortcode->getValueNumberSlide( 'opacity_' . $id, 1 );
		if ( $opacity < 1 && $opacity !== '' ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-opacity', $opacity );
		}

		if ( $duration_ = $this->shortcode->getValueNumberSlide( 'duration_' . $id ) ) {
			$this->add_render_attribute( $element, 'data-swiper-parallax-duration', $duration_ );
		}


		$this->add_render_attribute( $element, 'class', 'dsn-swiper-parallax-transform' );

		return $this;
	}


	public function addPrefixClassLayout( $element, ohixmShortCode $shortcode ) {

		$with_def = '';
		if ( ! $this->default_mobile ) {
			$with_def = 'dsn-n-default';
		}

		$scroll_horizontal = $shortcode->getVal( 'scroll_horizontal' );
		$scroll_vertical   = $shortcode->getVal( 'scroll_vertical' );
		$this->add_render_attribute( $element, [
			'class' => [
				'dsn-grid-layout',
				$with_def,
				$shortcode->getVal( 'layout_style', 'dsn-grid' ),
				$shortcode->getVal( 'full_width_last_item', '' ),
				$scroll_horizontal,
				$scroll_vertical
			],

			'data-dsn-iso' => $this->get_id(),

		] );


		if ( $scroll_horizontal || $scroll_vertical ) {
			$this->add_render_attribute( $element,
				[
					'class'           => [ $scroll_horizontal, $scroll_vertical ],
					'data-dsn-option' => json_encode( [
						'speed'         => (float) $shortcode->getValueNumberSlide( 'speed_scroll', 0 ),
						'center_screen' => boolval( $shortcode->getVal( 'center_screen' ) ),
						'start'         => $shortcode->getValueNumberSlide( 'start_scroll', 0 )
					] )
				] );
		}


	}

	public function addAnimateFade( $element, ohixmShortCode $shortcode ) {
		if ( $shortcode->getVal( 'use_animate_fade' ) ) {
			$this->add_render_attribute( $element, 'class', 'dsn-up' );
		}
	}


	protected function animateGrid() {
		$control = $this->getControl();


		$this->start_controls_section(
			'scroll_section',
			[
				'label' => esc_html__( 'Motion Effect', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_SETTINGS,
			]
		);

		$this->getScrollHorizontal();


		$control->addHidden( 'hidde-over' )
		        ->setDefault( 'over-hidden' )
		        ->setPrefix_class()
		        ->setConditions( 'scroll_horizontal', '!=', '' )
		        ->get();

		$this->end_controls_section();
	}


	protected function getScrollHorizontal() {
		$control = $this->getControl();


		$control->addSwitcher( 'scroll_horizontal' )
		        ->setLabel( esc_html__( 'Scroll Horizontal', 'ohixm' ) )
		        ->setReturn_value( 'use-horizontal-scroll' )
		        ->get();


		$control->addSwitcher( 'scroll_vertical' )
		        ->setLabel( esc_html__( 'Scroll Vertical', 'ohixm' ) )
		        ->setReturn_value( 'use-v-scroll' )
		        ->get();


		$control->addSwitcher( 'scroll_flexible' )
		        ->setLabel( esc_html__( 'Scroll flexible', 'ohixm' ) )
		        ->setReturn_value( 'use-flexible-scroll' )
		        ->setConditions( 'scroll_horizontal', '!=', '' )
		        ->setPrefix_class()
		        ->get();


		$control->addSwitcher( 'center_screen' )
		        ->setLabel( esc_html__( 'Center Screen', 'ohixm' ) )
		        ->setConditions( 'scroll_vertical', '!=', '' )
		        ->get();


		$control->addNumberSlider( 'speed_scroll', - 100, 100, 10 )
		        ->setLabel( esc_html__( 'Speed Scroll', 'ohixm' ) )
		        ->setDefaultDesktopRange( 0 )
		        ->setConditions( 'scroll_horizontal', '!=', '' )
		        ->setConditions( 'scroll_vertical', '!=', '' )
		        ->get();


		$control->addNumberSlider( 'start_scroll', - 1000, 1000, 1 )
		        ->setLabel( esc_html__( 'Offset Top Scroll', 'ohixm' ) )
		        ->setDefaultDesktopRange( 0 )
		        ->setConditions( 'scroll_horizontal', '!=', '' )
		        ->setConditions( 'scroll_vertical', '!=', '' )
		        ->get();

	}


	protected function getLayout() {

		$control = $this->getControl();
//
//		$control->addHidden( 'init_layout' )
//		        ->setDefault( true )
//		        ->setSelectors( '', 'position: relative;overflow: hidden;' )
//		        ->get();

		$control->addSelect( 'layout_style', $this->getLayoutStyle() )
		        ->setLabel( esc_html__( "Layout Style", 'ohixm' ) )
		        ->setDefault( "dsn-grid" )
		        ->setSeparator( "before" )
		        ->get();


		$control->addNumberSlider( 'number_ohixm', 1, 9, 1 )
		        ->setLabel( esc_html__( "Columns", 'ohixm' ) )
		        ->setDefaultRange( 1 )
		        ->setSelectors( $this->style_layout, '--dsn-width-item: {{SIZE}};' )
		        ->setConditions( 'layout_style', '!=', 'flexibly-hover' )
		        ->getResponsive();

		$control->addSwitcher( 'full_width_last_item' )
		        ->setLabel( esc_html__( "full width last item", 'ohixm' ) )
		        ->setReturn_value( "full-width-last-item" )
		        ->setConditions( 'layout_style',  'dsn-grid' )
		        ->get();

		$control->addSwitcher( 'use_animate_fade' )
		        ->setLabel( esc_html__( "use Animate Fade", 'ohixm' ) )
		        ->setReturn_value( "dsn-layout-fade-up" )
		        ->setPrefix_class()
		        ->get();


	}

	protected function getGridSpace() {
		$control = $this->getControl();
		$control->addNumberSlider( 'col_layout_gap', 0, 100, 1 )
		        ->setLabel( esc_html__( "Columns Gap", 'ohixm' ) )
		        ->setSelectors( $this->style_layout, '--dsn-col-item: {{SIZE}}px;' )
		        ->setDefaultRange( $this->range_col )
//		        ->setConditions( 'layout_style', '!=', 'flexibly-hover' )
		        ->getResponsive();

		$control->addNumberSlider( 'row_layout_gap', 0, 100, 1 )
		        ->setLabel( esc_html__( "Row Gap", 'ohixm' ) )
		        ->setSelectors( $this->style_layout, '--dsn-row-item: {{SIZE}}px;' )
		        ->setDefaultRange( $this->range_row )
//		        ->setConditions( 'layout_style', '!=', 'flexibly-hover' )
		        ->getResponsive();


	}


}