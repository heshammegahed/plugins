<?php

namespace Dsn\Ohixm\Element;


use OhixmControl;
use DesignGrid\OhixmOption;
use Elementor\Controls_Manager;

trait  PostControl {

	public function __content_controller( OhixmControl $control ) {


		$control->addSelect( 'style_post', [
			'cards'             => esc_html__( "Cards", 'ohixm' ),
			'cards cards-odd'   => esc_html__( "Cards Odd", 'ohixm' ),
			'classic'           => esc_html__( "classic", 'ohixm' ),
			'classic classic-2' => esc_html__( "classic 2", 'ohixm' ),
			'list'              => esc_html__( "List", 'ohixm' )
		] )
		        ->setLabel( esc_html__( "Skin", 'ohixm' ) )
		        ->setDefault( "cards" )
		        ->setPrefix_class( 'dsn-style-' )
		        ->get();


		$control->addSelect( 'style_list_post', [
			''                => esc_html__( "Image Left", 'ohixm' ),
			'dsn-image-right' => esc_html__( "Image Right", 'ohixm' ),
			'dsn-image-odd'   => esc_html__( "Image Reverse", 'ohixm' ),

		] )
		        ->setLabel( esc_html__( "Style List", 'ohixm' ) )
		        ->setDefault( '' )
		        ->setConditions( 'style_post', 'list' )
		        ->setPrefix_class()
		        ->get();

		$control->addSwitcher( 'style_list_post_number' )
		        ->setLabel( esc_html__( "With Number", 'ohixm' ) )
		        ->setReturn_value( 'list-with-number' )
		        ->setConditions( 'style_post', 'list' )
		        ->setPrefix_class()
		        ->get();

		$control->addSelect( 'query_post', [
			'post'               => esc_html__( 'post', 'ohixm' ),
			ohixm_project_slug() => esc_html__( 'ohixm Portfolio', 'ohixm' ),
		] )
		        ->setLabel( esc_html__( "Query", 'ohixm' ) )
		        ->setDefault( "post" )
		        ->get();

		$control->addNumber( 'post_per_page', - 1, null, 1 )
		        ->setLabel( esc_html__( 'Post Per Page', 'ohixm' ) )
		        ->setDescription( esc_html__( 'number of posts to show per page , (-1 or 0) (show all posts) is used.',
			        'ohixm' ) )
		        ->setDefault( 6 )
		        ->get();

		$control->addImageSize()
		        ->getGroup();


	}

	public function __title_content_controller( OhixmControl $control ) {
		$control->addHtmlTag()
		        ->setSeparator( "before" )
		        ->get();

		$control->addSize()
		        ->setDefault( 'title-block' )
		        ->get();
	}

	public function __excerpt_content_controller( OhixmControl $control ) {

		$control->addSwitcher( 'show_excerpt' )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( "Excerpt", 'ohixm' ) )
		        ->get();

		$control->addNumberSlider( 'excerpt_length', 15, 300, 5 )
		        ->setLabel( esc_html__( 'Excerpt length', 'ohixm' ) )
		        ->setDefaultRange( 25 )
		        ->setCondition( [ 'show_excerpt' => '1' ] )
		        ->get();


	}


	public function __link_content_controller( OhixmControl $control ) {

		$control->addSwitcher( 'show_link' )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( "Read More", 'ohixm' ) )
		        ->setDefault( '1' )
		        ->get();

		$control->addText( 'text_link' )
		        ->setLabel( esc_html__( 'Read More Text', 'ohixm' ) )
		        ->setDefault( esc_html__( "View Case", 'ohixm' ) )
		        ->setConditions( 'show_link', '1' )
		        ->get();

	}

	public function __meta_content_controller( OhixmControl $control ) {
		$control->addSelect2( 'meta_data', [
			'date'     => esc_html__( 'Date', 'ohixm' ),
			'category' => esc_html__( 'Category', 'ohixm' )
		] )->setMultiple()->setDefault( array() )->setSeparator( "before" )->setLabel( esc_html__( 'Meta Data',
			'ohixm' ) )->get();

		$control->addText( 'separator_between' )->setLabel( esc_html__( 'Separator Between',
			'ohixm' ) )->setDefault( '||' )->setConditions( 'meta_data', 'contains',
			'date' )->setConditions( 'meta_data', 'contains', 'category' )->setRelation( 'and' )->get();


	}


	public function __card_controller( OhixmControl $control ) {
		$this->start_controls_section(
			'style_card_section',
			[
				'label' => esc_html__( 'Card', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$control->addSelect( 'bg_ver_btn',
			$control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-main' )
		        ->get();

		$control->addPaddingGroup( 'item_padding', '.root-posts .dsn-posts .box-content .post-content' )
		        ->setSeparator( "before" )
		        ->getResponsive();

		$control->addMarginGroup( 'item_margin', '.root-posts .dsn-posts .box-content .post-content' )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.root-posts .dsn-posts .box-content .post-content' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.root-posts .dsn-posts .box-content .post-content' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.root-posts .dsn-posts .box-content .post-content' )->getGroup();


		$this->end_controls_section();


	}

	public function __image_style_controller( OhixmControl $control ) {
		$this->start_controls_section(
			'style_image_section',
			[
				'label' => esc_html__( 'Image', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$control->addSwitcher( 'hide_image' )
		        ->setLabel( esc_html__( "Hide Image", 'ohixm' ) )
		        ->get();

		$this->Spacing( 'image_space', '.dsn-post-type-classic .box-image-bg' )
		     ->setConditions( 'style_post', 'classic' )
		     ->setConditions( 'style_post', 'list' )
		     ->setConditions( 'hide_image', '' )
		     ->getResponsive();

		$control->addSwitcher( 'box_shadow_head' )
		        ->setLabel( esc_attr__( 'Use Shadow Head', 'ohixm' ) )
		        ->setReturn_value( 'box-shadow-image' )
		        ->setConditions( 'hide_image', '' )
		        ->setPrefix_class()
		        ->get();

		$control->addSelect( 'animate_image', [
			''                    => esc_html__( 'Default', 'ohixm' ),
			'box-image-transform' => esc_html__( 'Transform', 'ohixm' ),
			'box-image-parallax'  => esc_html__( 'Parallax', 'ohixm' ),
		] )
		        ->setLabel( esc_html__( 'Animate Image', 'ohixm' ) )
		        ->setDefault( '' )
		        ->setPrefix_class()
		        ->setConditions( 'hide_image', '' )
		        ->get();

		$control->addBorderRadiusGroup( 'item_border_radius_image', '.root-posts .dsn-posts .box-content .box-image-bg img , {{WRAPPER}} .root-posts .dsn-posts .box-content .box-image-bg:before ' )
		        ->getResponsive();

		$this->end_controls_section();
	}


	public function __style_controller( OhixmControl $control ) {
		$args = array(
			'post-title'          => esc_html__( 'Title', 'ohixm' ),
			'entry-meta a'        => esc_html__( 'Meta Data', 'ohixm' ),
			'section_description' => esc_html__( 'Description', 'ohixm' ),
			'dsn-post-link'       => esc_html__( 'Link', 'ohixm' ),
		);

		foreach ( $args as $id => $value ):


			$this->start_controls_section(
				'style_content_post_' . sanitize_title( $id ),
				[
					'label' => $value,
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);

			if ( $id !== 'post-title' ) {
				$this->Spacing( 'spacing_content_' . sanitize_title( $id ),
					'.' . ( $id === 'post-meta a' ? 'post-meta' : $id ), $id === 'post-meta a' ? 'bottom' : 'top' )
				     ->getResponsive();
			} else {
				$control->addMarginGroup( 'item_margin_' . sanitize_title( $id ), '.root-posts .dsn-posts .box-content .post-title-info' )
				        ->getResponsive();
			}

			if ( $id === 'section_description' ) {
				$control->addSwitcher( 'border_left' )
				        ->setLabel( "Border Left" )
				        ->setReturn_value( 'border-before' )
				        ->get();
			}

			if ( $id === 'entry-meta a' ) {


				$control->addSelect( "transform_style", [
					''     => esc_html__( "Normal", "ohixm" ),
					'free' => esc_html__( "Free", "ohixm" ),
				] )
				        ->setLabel( esc_html__( "Transform", 'ohixm' ) )
				        ->setDefault( '' )
				        ->get();


				$control->addSelect( "category_style_" . sanitize_title( $id ), [
					''             => esc_html__( "Default", "ohixm" ),
					'dsn-line-cat' => esc_html__( "Line", "ohixm" ),
					'dsn-bg-cat'   => esc_html__( "Background", "ohixm" ),
				] )
				        ->setLabel( esc_html__( "Style Cat", 'ohixm' ) )
				        ->setDefault( '' )
				        ->setPrefix_class()
				        ->get();

			}


			$control->addColor( 'color_content_' . sanitize_title( $id ) )
			        ->setLabel( esc_html__( "Color", 'ohixm' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content_' . sanitize_title( $id ), '.' . $id )
			        ->getGroup();

			$control->addTextShadow( 'text_content_shadow_' . sanitize_title( $id ), '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;
	}


	protected function query( OhixmControl $control ) {


		/**
		 * Query
		 */
		$this->start_controls_section(
			'content_query',
			[
				'label' => esc_html__( 'Query', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control->addSelect2( 'include_tax', OhixmOption::getTermsArray( [
			'taxonomy' => [
				'category',
				ohixm_category_slug()
			]
		], "term_id" ) )
		        ->setMultiple()
		        ->setLabelBlock()
		        ->setDefault( [] )
		        ->setPlaceholder( esc_html__( "All", "ohixm" ) )
		        ->setLabel( esc_html__( 'Taxonomy Query', 'ohixm' ) )
		        ->setDescription( esc_html__( 'Show posts associated with certain taxonomy.', 'ohixm' ) )
		        ->get();

		$control->addSelect( 'operator_tax', [
			"IN"         => "IN",
			"NOT IN"     => "NOT IN",
			"AND"        => "AND",
			"EXISTS"     => "EXISTS",
			"NOT EXISTS" => "NOT EXISTS",
		] )
		        ->setDefault( "NOT IN" )
		        ->setLabelBlock()
		        ->setLabel( esc_html__( 'Operator Tax', 'ohixm' ), true )
		        ->get();

		$control->addNumber( 'offset', 0, null, 1 )
		        ->setDefault( 0 )
		        ->setSeparatorBefore()
		        ->setLabel( esc_html__( 'Offset', 'ohixm' ), true )
		        ->setDescription( esc_html__( 'offset Display posts from the 4th one', 'ohixm' ) )
		        ->get();

		$control->addSelect( 'orderby', [
			'none'       => esc_html__( 'No order', 'ohixm' ),
			'ID'         => esc_html__( 'post id', 'ohixm' ),
			'author'     => esc_html__( 'author', 'ohixm' ),
			'menu_order' => esc_html__( 'Menu Order', 'ohixm' ),
			'title'      => esc_html__( 'title', 'ohixm' ),
			'name'       => esc_html__( 'name', 'ohixm' ),
			'date'       => esc_html__( 'date', 'ohixm' ),
			'modified'   => esc_html__( 'last modified date', 'ohixm' ),
			'rand'       => esc_html__( 'Random order', 'ohixm' ),
		] )
		        ->setLabel( esc_html__( 'Order By', 'ohixm' ) )
		        ->setDescription( esc_html__( 'Sort retrieved posts.', 'ohixm' ) )
		        ->setDefault( "date" )
		        ->get();

		$control->addSelect( 'order', [
			'DESC' => esc_html__( 'descending', 'ohixm' ),
			'ASC'  => esc_html__( 'ascending', 'ohixm' )
		] )
		        ->setLabel( esc_html__( 'Order', 'ohixm' ) )
		        ->setDescription( esc_html__( 'Designates the ascending or descending order of the ‘orderby‘ parameter', 'ohixm' ) )
		        ->setDefault( "DESC" )
		        ->get();

	}

}
