<?php

use Dsn\Element\Ohixm_Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class OhixmTitle extends Widget_Base {

	use Ohixm_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_title';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return __( 'Ohixm Title Section', 'ohixm' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-post-title';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'title', 'header' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Title', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();


		$control->addText( 'num_title' )
		        ->setLabel( esc_html__( 'Number Title', 'ohixm' ) )
		        ->setPlaceholder( esc_html__( 'Enter your Number', 'ohixm' ) )
		        ->setDynamicActive( true )
		        ->get();

		$control->addTextarea( 'title' )
		        ->setLabel( esc_html__( 'Title', 'ohixm' ) )
		        ->setPlaceholder( esc_html__( 'Enter your title', 'ohixm' ) )
		        ->setDefault( esc_html__( 'Add Your Title', 'ohixm' ) )
		        ->setDynamicActive( true )
		        ->get();

		$control->addTextarea( 'description' )
		        ->setLabel( esc_html__( 'Description', 'ohixm' ) )
		        ->setSeparator( "before" )
		        ->setPlaceholder( esc_html__( 'Enter your description', 'ohixm' ) )
		        ->setDefault( esc_html__( 'Add Your Description', 'ohixm' ) )
		        ->setDynamicActive( true )
		        ->get();

		$control->addChoose( 'direction' )
		        ->setLabel( esc_html__( 'Direction', 'ohixm' ) )
		        ->setConditions( 'description', '!=', '' )
		        ->setOptionChoose( '1', __( 'Before Title', 'elementor' ), 'eicon-v-align-top' )
		        ->setOptionChoose( '', __( 'After Title', 'elementor' ), 'eicon-v-align-bottom' )
		        ->setDefault( '' )
		        ->get();


		$control->addHtmlTag()
		        ->setSeparator( 'before' )
		        ->get();

		$control->addSize()
		        ->setDefault( 'title-h2' )
		        ->get();

		$this->end_controls_section();

		$this->styleTab();

	}


	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style Content', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->getAlign()
		        ->setDefault( "left" )
		        ->getResponsive();

		$control->getJustifyContent()
		        ->getSelectorjustifyContent( '.section-title' )
		        ->getResponsive();


		$control->addSelect( 'dsn_section_width_layout', [
			''                                  => __( 'Default', 'ohixm' ),
			'dsn-container'                     => __( 'Wide Page', 'ohixm' ),
			'container'                         => __( 'Container Page', 'ohixm' ),
			'dsn-container dsn-right-container' => __( 'Right Container Page', 'ohixm' ),
			'dsn-container dsn-left-container'  => __( 'Left Container Page', 'ohixm' ),
		], [
			'label'        => __( 'Width Layout', 'ohixm' ),
			'default'      => '',
			'prefix_class' => '',
		] )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSlider( 'spaces_description' )
		        ->setLabel( __( 'Spacing Between', 'elementor' ) )
		        ->setRangePx( - 120, 120 )
		        ->setSelectors( '.description.mb-10', 'margin-bottom: {{SIZE}}{{UNIT}};' )
		        ->setSelectors( '.description.mt-10', 'margin-top: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSwitcher( 'space_section' )
		        ->setLabel( esc_html__( "Use Space Default", 'ohixm' ) )
		        ->setDefault( 'mb-70' )
		        ->setReturn_value( 'mb-70' )
		        ->get();

		$control->addHiddenNoSpace( 'hidden-space' )
		        ->setConditions( 'space_section', 'mb-70' )
		        ->get();

		$this->end_controls_section();


		$this->start_controls_section(
			'style_title_section',
			[
				'label' => esc_html__( 'Style Title', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addHeadingColor( 'title_color', '.dsn-heading-title' )
		        ->setLabel( __( 'Custom Color', 'ohixm' ) )
		        ->get();
		$control->addTypography( 'title_typography' )->getGroup();


		$control->addLineText( 'dsn_line_title' )
		        ->get();

		$control->addLineText( 'dsn_line_title_into' )
		        ->setLabel( __( 'Line Text Into', 'ohixm' ) )
		        ->get();

		$control->addSlider( 'space', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Max Width', 'elementor' ) )
		        ->setSelectors( '.dsn-heading-title', 'max-width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addTextShadow( 'title_Text_shadow' )->getGroup();
		$control->addBlendMode( 'title_blend_mode' )->get();

		$control->addSwitcher( 'use_as_stroke' )
		        ->setReturn_value( 'letter-stroke' )
		        ->setLabel( __( 'Use As Stroke', 'ohixm' ) )
		        ->get();

		$control->addSelect( 'dsn_title_animate', [
			''         => __( 'None', 'ohixm' ),
			'dsn-up'   => __( 'Fade', 'ohixm' ),
			'dsn-text' => __( 'Text', 'ohixm' ),
		] )
		        ->setLabel( __( 'Animate Text', 'ohixm' ) )
		        ->setDefault( '' )
		        ->setSeparator( "before" )
		        ->get();


		$this->end_controls_section();


		$this->start_controls_section(
			'style_number_section',
			[
				'label' => esc_html__( 'Style Number', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addHeadingColor( 'num_title_color', '.dsn-heading-number' )
		        ->setLabel( __( 'Custom Color', 'ohixm' ) )
			->setDefault('theme-color')
		        ->get();
		$control->addTypography( 'num_title_typography', ".dsn-heading-number" )->getGroup();


		$control->addLineText( 'dsn_line_number' )
		        ->get();

		$control->addSlider( 'space_num', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Space Between', 'ohixm' ) )
		        ->setSelectors( '.section-title', 'gap: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addTextShadow( 'title_Text_shadow_num', ".dsn-heading-number" )->getGroup();
		$control->addBlendMode( 'title_blend_mode_num', ".dsn-heading-number" )->get();


		$this->end_controls_section();


		$this->start_controls_section(
			'style_description_section',
			[
				'label' => esc_html__( 'Style Description', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addHeadingColor( 'description_color', '.description', [ 'default' => 'heading-color' ] )
		        ->setLabel( __( 'Custom Color', 'ohixm' ) )
		        ->get();
		$control->addTypography( 'description_typography', '.description' )->getGroup();


		$control->addLineText( 'dsn_line_description' )
		        ->setDefault( '' )
		        ->get();

		$control->addLineText( 'dsn_line_description_into' )
		        ->setDefault( 'bg-subtitle background-theme' )
		        ->setLabel( __( 'Line Text Into', 'ohixm' ) )
		        ->get();

		$control->addSlider( 'space_description', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Max Width', 'elementor' ) )
		        ->setSelectors( '.description', 'max-width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addSelect( 'dsn_description_animate', [
			''         => __( 'None', 'ohixm' ),
			'dsn-up'   => __( 'Fade', 'ohixm' ),
			'dsn-text' => __( 'Text', 'ohixm' ),
		] )
		        ->setLabel( __( 'Animate Text', 'ohixm' ) )
		        ->setDefault( '' )
		        ->setSeparator( "before" )
		        ->get();


		$this->end_controls_section();


	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$this->add_inline_editing_attributes( 'title' );
		$this->add_inline_editing_attributes( 'description' );

		ohixm_render_widget_motion_effect( $this, 'section-title' );
		echo ohixm_shortcode_render_group( 'title', array( 'widget-base' => $this ) );
	}

}