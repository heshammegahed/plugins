<?php


use Dsn\Element\ohixm_Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class OhixmSocial extends Widget_Base {

	use ohixm_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_social';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Ohixm Social', 'ohixm' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-image-rollover';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(), [ 'social', 'link' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();


		$control->addSlider( "image_space", [
			'label' => esc_html__( 'Spacing', 'ohixm' ),
			'range' => [
				'px' => [ 'max' => 100, ],
			],
		] )->setSelectors( "li:not(:last-of-type)", 'margin-right:{{SIZE}}{{UNIT}}' )
		        ->getResponsive();

		$control->addSlider( "image_space_row", [
			'label' => esc_html__( 'Row Gap', 'ohixm' ),
			'range' => [
				'px' => [ 'max' => 100, ],
			],
		] )->setSelectors( "li", 'margin-bottom:{{SIZE}}{{UNIT}}' )
		        ->getResponsive();


		$control->getAlign()
		        ->setSeparatorAfter()
		        ->getResponsive();

		$control->addSelect( 'bg_ver_item', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Item', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->setPrefix_class()
		        ->get();

		$control->addSelect( 'bg_item', $control->getOptionBackground( [
			'background-heading' => __( 'Background Heading', 'ohixm' ),
		] ) )
		        ->setLabel( esc_html__( 'Background Item', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-section' )
		        ->setSeparator( "after" )
		        ->get();

		$control->startRepeater();


		$control->get_element_base()->add_control(
			'icon',
			[
				'label'       => __( 'Icon', 'ohixm' ),
				'type'        => Controls_Manager::ICONS,
				'label_block' => true,
				'default'     => [
					'value'   => 'fas fa-star',
					'library' => 'solid',
				],
			]
		);

		$control->addText( 'title' )
		        ->setLabel( esc_html__( 'Title', 'ohixm' ) )
		        ->setDefault( 'FB' )
		        ->get();

		$control->addText( 'link' )
		        ->setLabel( esc_html__( 'Link', 'ohixm' ) )
		        ->setDefault( '#0' )
		        ->get();
		$control->endRepeater( 'items' )
		        ->setLabel( esc_html__( 'items', 'ohixm' ) )
		        ->setTitle_field_withIcon( 'icon', 'title' )
		        ->get();


		$this->end_controls_section();

		$this->style_icon();
	}

	private function style_icon() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_content_service_icon',
			[
				'label' => esc_html__( "icon", 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);


		$control->addIconColor( 'icon_color_select' )
		        ->setPrefix_class()
		        ->get();


		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'icon_color_select' => ''
				],
				'selectors' => [
					'{{WRAPPER}} .dsn-icon i'        => 'color: {{VALUE}};',
					'{{WRAPPER}} .dsn-icon svg'      => 'fill: {{VALUE}};',
					'{{WRAPPER}} .dsn-icon svg path' => 'fill: {{VALUE}};',
				],

			]
		);

		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-socials .dsn-icon', '--dsn-icon-size: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addPaddingGroup( 'item_padding_icon', 'a.init-color' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius_icon', 'a.init-color' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style_icon', 'a.init-color' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow_icon', 'a.init-color' )->getGroup();

		$this->end_controls_section();
	}


	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$this->add_inline_editing_attributes( 'title', 'none' );
		echo ohixm_shortcode_render_group( 'social', array( 'widget-base' => $this ) );
	}

}
