<?php

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}


/**
 * Page Header in Elementor Document Settings
 */
add_action('elementor/element/wp-page/document_settings/after_section_end', 'ohixm_document_settings_page_layout');
add_action('elementor/element/wp-post/document_settings/after_section_end', 'ohixm_document_settings_page_layout');
function ohixm_document_settings_page_layout(PageBase $page)
{

    $control = new OhixmControl($page);

    $page->start_controls_section(
        'page_layout_section',
        array(
            'label' => esc_html__('Layout', 'ohixm'),
            'tab' => Controls_Manager::TAB_SETTINGS,
        )
    );

    $control->addSelect('page_layout', [
        '' => esc_html__("Full Width", "ohixm"),
        'container' => esc_html__("Container", "ohixm"),
        'dsn-container' => esc_html__("Container Fluid", "ohixm"),
    ])
        ->setDefault(ohixm_is_work() ? '' : 'container')
        ->setLabel(esc_html__("Page Layout", "ohixm"))
        ->get();


    $control->addSelect('global_background_color', [
        "auto" => esc_html__("Auto", "ohixm"),
        'v-dark' => esc_html__("Dark", "ohixm"),
        'v-light' => esc_html__("Light", "ohixm"),
    ])
        ->setDefault("auto")
        ->setLabel(esc_html__("Background Color", "ohixm"))
        ->get();


    $control->addSwitcher('show_cart')
        ->setLabel(esc_attr__('Show Cart', 'ohixm'))
        ->setLabel_on(esc_attr__('Show', 'ohixm'))
        ->setLabel_off(esc_attr__('Hide', 'ohixm'))
        ->get();

    $control->addSwitcher('show_sidebar')
        ->setReturn_value('show')
        ->setLabel(esc_attr__('Show Sidebar', 'ohixm'))
        ->setLabel_on(esc_attr__('Show', 'ohixm'))
        ->setLabel_off(esc_attr__('Hide', 'ohixm'))
        ->setDefault('show')
        ->get();

    $control->addSelect('choose_sidebar', [
        "blog-sidebar-1" => esc_html__("Blog Sidebar", "ohixm"),
        'wc-sidebar-1' => esc_html__("Woocommerce Sidebar", "ohixm")
    ])
        ->setDefault("auto")
        ->setLabel(esc_html__("Choose Sidebar", "ohixm"))
        ->setConditions('show_sidebar', 'show')
        ->setDefault('blog-sidebar-1')
        ->get();

    $page->end_controls_section();

}