<?php

namespace Dsn\Ohixm\Element;


use OhixmControl;
use Elementor\Controls_Manager;

trait  ServiceControl {


	public function __content_controller( OhixmControl $control ) {

		$is_grid = isset( $this->isGrid ) && $this->isGrid;


		$control->addSwitcher( 'with_number' )
		        ->setLabel( esc_html__( 'With Number', 'ohixm' ) )
		        ->setReturn_value( 'list-with-number' )
		        ->setPrefix_class()
		        ->get();


		$control->addSwitcher( 'with_image' )
		        ->setLabel( esc_html__( 'With Bg Image', 'ohixm' ) )
		        ->setReturn_value( 'service-with-img' )
		        ->setPrefix_class()
		        ->get();


		$control->addChoose( 'position_icon' )
		        ->setOptionChoose( 'icon-left', __( 'Left', 'elementor' ), 'eicon-h-align-left' )
		        ->setOptionChoose( 'icon-top', __( 'Top', 'elementor' ), 'eicon-v-align-top' )
		        ->setOptionChoose( 'icon-right', __( 'Right', 'elementor' ), 'eicon-h-align-right' )
		        ->setDefault( 'icon-top' )
		        ->setLabel( esc_attr__( 'Position Icon', 'ohixm' ) )
		        ->setPrefix_class()
		        ->get();

		$control->addChoose( 'position_align' )
		        ->setOptionChoose( 'start', __( 'Start', 'elementor' ), 'eicon-v-align-top' )
		        ->setOptionChoose( 'center', __( 'Center', 'elementor' ), 'eicon-v-align-middle' )
		        ->setOptionChoose( 'end', __( 'End', 'elementor' ), 'eicon-v-align-bottom' )
		        ->setDefault( 'start' )
		        ->setSelectors( '.service-item .service-item-inner', 'align-items:{{VALUE}}' )
		        ->setConditions( 'position_icon', '!=', 'icon-top' )
		        ->setLabel( esc_attr__( 'Align Item', 'ohixm' ) )
		        ->getResponsive();


		$control->startRepeater();


		if ( $is_grid ) {
			$control->get_element_base()->start_controls_tabs( 'dsn_button_style' );
			$control->get_element_base()->start_controls_tab(
				'icon_tab',
				[
					'label' => __( 'Icon', 'ohixm' ),
				]
			);
			$control->get_element_base()->add_control(
				'icon',
				[
					'label'   => __( 'Icon', 'ohixm' ),
					'type'    => Controls_Manager::ICONS,
					'default' => [
						'value'   => 'fas fa-star',
						'library' => 'solid',
					],
				]
			);
			$control->get_element_base()->end_controls_tab();
			$control->get_element_base()->start_controls_tab(
				'image_tab',
				[
					'label' => __( 'Image', 'ohixm' ),
				]
			);
			$control->addImage()->get();
			$control->addImageSize()->get();
			$control->get_element_base()->end_controls_tab();
			$control->get_element_base()->end_controls_tabs();


		} else {
			$control->get_element_base()->add_control(
				'icon',
				[
					'label'   => __( 'Icon', 'ohixm' ),
					'type'    => Controls_Manager::ICONS,
					'default' => [
						'value'   => 'fas fa-star',
						'library' => 'solid',
					]
				]
			);
		}


		$control->addText( "title" )
		        ->setLabelBlock()
		        ->setLabel( esc_html__( 'Title', 'ohixm' ), true )
		        ->setDefault( esc_html__( 'Title Service', 'ohixm' ) )
		        ->setSeparatorBefore()
		        ->setDynamicActive( true )
		        ->get();

		$control->addTextarea( "description" )
		        ->setLabel( esc_html__( 'Description', 'ohixm' ), true )
		        ->setDefault( 'Te qui alii inermis vivendum, an decore libris eum. Te mel dico alia wisi, cu vitae noluisse <a href="#0" target="_blank">phaedrum</a>' )
		        ->setDynamicActive( true )
		        ->get();

		$control->addLink( 'link' )
		        ->setLabel( esc_html__( 'Link', 'ohixm' ), true )
		        ->setDynamicActive( true )
		        ->setDefault_url()
		        ->setDefault_is_external( true )
		        ->setDefault_is_nofollow( true )
		        ->get();

		$control->addTextarea( 'text_link' )
		        ->setLabel( esc_html__( 'Text Link', 'ohixm' ), true )
		        ->setDefault( esc_html__( "Read More", 'ohixm' ) )
		        ->setDynamicActive( true )
		        ->setConditions( 'link[url]', '!=', '' )
		        ->get();


		$control->endRepeater( 'items' )
		        ->setLabel( "Item Service" )
		        ->setTitle_field( 'title' )
		        ->get();


	}


	public function __style_controller( OhixmControl $control ) {
		$is_grid = isset( $this->isGrid ) && $this->isGrid;

		$control->getAlign()
		        ->setDefault( "left" )
		        ->getResponsive();

		$control->addSelect( 'bg_ver_btn', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Service', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_btn', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Service', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-main' )
		        ->get();
		if ( $is_grid ) {
			$control->getBackdropFilter();
		}

		$control->addPaddingGroup( 'item_padding_service', '.service-item-inner' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius', '.service-item' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style', '.service-item' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow', '.service-item' )->getGroup();
	}

	public function __style_content_controller( OhixmControl $control ) {

		$args = array(
			'service_title'       => esc_html__( 'Title', 'ohixm' ),
			'service_description' => esc_html__( 'Description', 'ohixm' )
		);

		foreach ( $args as $id => $value ):

			$this->start_controls_section(
				'style_content_service_' . $id,
				[
					'label' => $value,
					'tab'   => Controls_Manager::TAB_STYLE,
				]
			);


			$control->addColor( 'color_content_' . $id )
			        ->setLabel( esc_html__( "Color", 'ohixm' ) )
			        ->setSeparator( "before" )
			        ->setSelectors( '.' . $id, 'color:{{VALUE}};' )
			        ->get();

			$control->addTypography( 'item_typo_content_' . $id, '.' . $id )
			        ->getGroup();

			if ( $id === 'service_title' ) {
				$control->addSize()
				        ->setDefault( 'title-block' )
				        ->get();
				$control->addSelect( 'line_service_item', [
					''                                           => esc_html__( 'Default', '' ),
					'border-top pt-20'                           => esc_html__( 'Border Top', 'ohixm' ),
					'border-bottom pb-20 mb-20'                  => esc_html__( 'Border Bottom', 'ohixm' ),
					'border-top pt-20 border-bottom pb-20 mb-20' => esc_html__( 'Both Border Bottom', 'ohixm' ),
					'border-section-bottom'                      => esc_html__( 'Border Bottom Line', 'ohixm' ),
					'border-section-bottom border-top pt-20 '    => esc_html__( 'Both Border Bottom Line', 'ohixm' ),
				] )
				        ->setDefault( '' )
				        ->setLabel( __( 'Line Text', 'ohixm' ) )
				        ->get();
			} else {
				$control->addSpacing( 'space_' . $id, '.' . $id, 'top' )
				        ->get();
			}


			$control->addTextShadow( 'text_content_shadow_' . $id, '.' . $id )
			        ->getGroup();

			$this->end_controls_section();


		endforeach;


		$this->start_controls_section(
			'style_content_service_icon',
			[
				'label' => esc_html__( "icon", 'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addSwitcher( 'use_stroke' )
		        ->setLabel( esc_html__( "Color Stroke", "ohixm" ) )
		        ->setReturn_value( "dsn-icon-stroke" )
		        ->setPrefix_class()
		        ->get();
		$control->addIconColor( 'icon_color_select' )
		        ->setPrefix_class()
		        ->get();


		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Color', 'elementor' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'condition' => [
					'icon_color_select' => ''
				],
				'selectors' => [
					'{{WRAPPER}} .dsn-icon:not(.dsn-bg-before) i'        => 'color: {{VALUE}};',
					'{{WRAPPER}} .dsn-icon:not(.dsn-bg-before) svg'      => 'fill: {{VALUE}};',
					'{{WRAPPER}} .dsn-icon:not(.dsn-bg-before) svg path' => 'fill: {{VALUE}};',
				],

			]
		);

		$control->addSlider( 'width_icon_wrapper', $control->getDefaultWidthHeight() )
		        ->setLabel( __( 'width', 'elementor' ) )
		        ->setSelectors( '.dsn-icon', '--width-wrapper: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSlider( 'height_icon_wrapper', $control->getDefaultWidthHeight('hv') )
		        ->setLabel( __( 'Height', 'elementor' ) )
		        ->setSelectors( '.dsn-icon', '--height-wrapper: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addSelect( 'bg_ver_icon', $control->getOptionVerBackground() )
		        ->setLabel( esc_html__( 'Version Background Icon', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( '' )
		        ->get();

		$control->addSelect( 'bg_icon', $control->getOptionBackground() )
		        ->setLabel( esc_html__( 'Background Icon', 'ohixm' ) )
		        ->setLabelBlock()
		        ->setDefault( 'background-transparent' )
		        ->get();


		$control->addSlider( 'width_icon', $control->getDefaultWidthHeight() )
		        ->setSeparatorBefore()
		        ->setLabel( __( 'Size Icon', 'elementor' ) )
		        ->setSelectors( '.dsn-service .dsn-icon:not(.dsn-bg-before):not(.dsn-bg-before)', '--dsn-icon-size: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();


		$control->addPaddingGroup( 'item_padding_icon', '.icon-wrapper' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorderRadiusGroup( 'item_border_radius_icon', '.icon-wrapper' )
		        ->getResponsive();

		$control->addBorder( 'item_border_style_icon', '.icon-wrapper' )->getGroup();
		$control->addBoxShadow( 'item_box_shadow_icon', '.icon-wrapper' )->getGroup();

		$this->end_controls_section();
	}

}