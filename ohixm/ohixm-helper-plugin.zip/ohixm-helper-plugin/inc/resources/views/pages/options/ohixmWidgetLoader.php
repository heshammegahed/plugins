<?php


use Dsn\Element\OhixmRegisterElement;
use Elementor\Elements_Manager;
use Elementor\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Ohixm Widget Extension
 * The main class that initiates and runs the plugin.
 *
 */
class ohixmWidgetLoader extends OhixmRegisterElement {


	use notices;

	/**
	 * Instance
	 *
	 * @access private
	 * @static
	 * @var ohixmWidgetLoader The single instance of the class.
	 */
	private static $_instance = null;


	/**
	 * Register Block Name
	 */
	const DSN_BLOCK = array(
		'Heading',
		'Title',
		'Button',
		'Image',
		'AnimateLine',
		'posts'   => [
			'control' => 'Post',
			'PostGrid',
			'PostHover',
			'PostSwiper'
		],
		'service' => [
			'control' => 'Service',
			'Grid',
//			'Swiper'
		],
		'Testimonial',
		'Icon',
		'BGMask',
		'JustifyGallery',

		'posts/slider' => [
			'control' => 'Slider',
			'SliderProject',
			'SliderThreeJS',
		],
		'sliders'      => 'MediaSlider',
		'List',

		'Accordion',
		'Marquee',
		'brand'        => [
			'control' => 'Brand',
			'GridBrand',
			'SwiperBrand'
		],
		'team'         => [
			'control' => 'Team',
			'GridTeam',
			'SwiperTeam'
		],
		'Skills',
		'Experience',
		'Map',
		'Social',
		'CircleTextRotation',
		'Logo',

//
//		'Marquee',
//		'Head',
		'navigation' => [
			'Arrow'
		],
		'GridMasonry',

//		'SkillImg',
//
//
//


//		'Tabs',
//
//		'woocommerce' => [
//			'Products',
//			'Category',
//			'Breadcrumb',
//		],
//		'Facts',
		//		'Compare',
////		'PricingTable',
////		'MoveSection',
////		'Awards',
//		'Feature',


	);

	/**
	 * Minimum ELEMENTOR Version
	 */
	const MINIMUM_ELEMENTOR_VERSION = '3.0.0';


	/**
	 * Minimum PHP Version
	 */
	const MIN_PHP_VERSION = '7.0';


	/**
	 * Minimum ACF Version
	 */
	const MIN_ACF_VERSION = '5.0';


	const DSN_WIDGET = array(
//		'Social',
//        'Logo',
//		'ScrollTop',
	);


	/**
	 * Instance
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @access public
	 * @static
	 *
	 * @return ohixmWidgetLoader An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;

	}


	/**
	 * Initializing the ohixmWidgetLoader class.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		require_once __DIR__ . '/widgets/control/OhixmControl.php';
		add_action( 'widget_loader', [ $this, 'register_widget' ] );
	}


	function preload_style( $tag, $handle, $src ) {
		// the handles of the enqueued scripts we want to async
		$async_scripts = array( 'mestc-fonts' );


		if ( in_array( $handle, $async_scripts ) ) {
			return sprintf( '<link id="mestc-fonts" rel="preload" href="%1$s" as="style" onload="this.onload=null;this.rel=\'stylesheet\'"><noscript><link href="%1$s" rel="stylesheet"></noscript>',
				$src );
		}

		return $tag;
	}



	/**
	 *
	 */

	/**
	 * Initialize the Widget
	 * Retrieve the current widget initial configuration.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function register_widget() {


		if ( ! $this->elementorLoaded() || ! $this->PHPVer() ) {
			return;
		}

		add_action( 'elementor/controls/register', function ( $controls_manager ) {
			require_once( __DIR__ . '/controls/DsnSelectControl.php' );

			$controls_manager->register( new \DsnSelectControl() );
		} );


		/**
		 * registering new Elementor widgets Category
		 */
		add_action( 'elementor/elements/categories_registered', function ( Elements_Manager $elements_manager ) {

			$elements_manager->add_category(
				'ohixm_cat',
				[
					'title' => esc_html__( 'Ohixm Widget(Design Grid)', 'ohixm' ),
					'icon'  => 'fa fa-plug',
				]
			);

		} );


		/**
		 * registering new Elementor widgets
		 */

//		add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
		add_action( 'elementor/widgets/register', [ $this, 'register_widgets' ] );


		$this->registerWidgetSection();
		$this->registerRenderSection();


		add_action( 'elementor/elements/elements_registered', [ $this, 'register_elements' ] );

		//        // Register widgets Theme
		add_action( 'widgets_init', [ $this, 'register_widgets_theme' ] );

	}


	public function register_widgets_theme() {

		foreach ( self::DSN_WIDGET as $wid ):
			if ( $wid ) {
				$wid = 'Coba' . $wid;
				require_once __DIR__ . '/widgets/theme/' . $wid . '.php';
				register_widget( $wid );
			}

		endforeach;
	}

	/**
	 * Register oEmbed Widget.
	 *
	 * Include widget file and register widget class.
	 *
	 *
	 *
	 * @return void
	 * @since 1.0.0
	 */
	public function register_widgets( $widgets_manager ) {

		require_once __DIR__ . '/widgets/control/OhixmSlider.php';
		require_once __DIR__ . '/widgets/control/OhixmLayout.php';

		/**
		 * Control Widget
		 */


		foreach ( self::DSN_BLOCK as $key => $block ):


			if ( $block ) {
				if ( is_array( $block ) ) {
					foreach ( $block as $key2 => $instance ) {
						if ( $key2 === 'control' ) {
							require_once __DIR__ . '/widgets/' . $key . '/' . $instance . 'Control.php';
							continue;
						}

						$this->getInstanceWidget( $key, $instance, $widgets_manager );
					}
				} else {

					$this->getInstanceWidget( $key, $block, $widgets_manager );
				}


			}

		endforeach;


	}

	/**
	 * check version < 3.5.0
	 * @return bool|int
	 */
	private function CheckVersionElement() {
		return version_compare( ELEMENTOR_VERSION, "3.5.0", '<' );
	}


	/**
	 * @param $key
	 * @param $instance
	 *
	 */
	private function getInstanceWidget( $key, $instance, $widgets_manager ) {

		$instance = 'Ohixm' . $instance;
		if ( is_string( $key ) ) {
			$key .= '/';
		} else {
			$key = '';
		}

		require_once __DIR__ . '/widgets/' . $key . $instance . '.php';

		if ( $this->CheckVersionElement() ) {
			Plugin::instance()->widgets_manager->register_widget_type( new $instance() );
		} else {
			$widgets_manager->register( new $instance() );
		}
	}


	/**
	 * Register Custom Elements
	 *
	 * @access public
	 *
	 * @return void
	 */

	public function register_elements() {
		require_once 'widgets/control/ohixmColumn.php';
		require_once 'widgets/control/ohixmSection.php';
		Plugin::instance()->elements_manager->register_element_type( new ohixmColumn() );
		Plugin::instance()->elements_manager->register_element_type( new ohixmSection() );
	}


}

ohixmWidgetLoader::instance();