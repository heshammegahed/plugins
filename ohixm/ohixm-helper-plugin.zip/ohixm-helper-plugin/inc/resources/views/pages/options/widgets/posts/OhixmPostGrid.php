<?php

use Dsn\Ohixm\Element\PostControl;
use Dsn\Element\Ohixm_Widget_Base;
use Dsn\Element\OhixmLayout;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class OhixmPostGrid extends OhixmLayout {

	use Ohixm_Widget_Base;
	use PostControl;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name() {
		return 'dsn_posts';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title() {
		return __( 'Ohixm Posts Grid', 'ohixm' );

	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon() {
		return 'eicon-posts-grid';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords() {
		return array_merge( $this->dsn_keywords(),
			[ 'portfolio', 'posts', 'cpt', 'item', 'loop', 'query', 'cards' ] );
	}
//
//	protected function getLayoutStyle(): array {
//		return array_merge( parent::getLayoutStyle(), [
//			'dsn-isotope dsn-metro' => esc_html__( 'Metro Grid', 'ohixm' )
//		] );
//	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();


		$this->__content_controller( $control );

		$this->getLayout();


		$this->__title_content_controller( $control );
		$this->__excerpt_content_controller( $control );
		$this->__meta_content_controller( $control );
		$this->__link_content_controller( $control );

		$this->end_controls_section();

		$this->pagination();
		$this->filterBar();
		$this->animateGrid();
//		$this->getScroll();
		$this->styleLayoutTab();
		$this->__card_controller( $control );
		$this->__image_style_controller( $control );
		$this->__style_controller( $control );
		$this->query( $control );

	}


	private function pagination() {
		$control = $this->getControl();

		$this->start_controls_section(
			'pagination_section',
			[
				'label' => esc_html__( 'Pagination',
					'ohixm' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control->addSelect( 'pagination_type',
			[
				'none' => __( 'None', 'ohixm' ),
				'nav'  => __( 'Pagination With Number', 'ohixm' ),
				'ajax' => __( 'Button Ajax', 'ohixm' ),
			] )
		        ->setLabel( esc_html__( 'Pagination', 'ohixm' ) )
		        ->setDefault( 'none' )
		        ->get();

		$control->addText( 'next_post' )
		        ->setLabel( esc_html__( 'Next Post Title', 'ohixm' ), true )
		        ->setDefault( __( 'NEXT',
			        'ohixm' ) )
		        ->setConditions( 'pagination_type',
			        'nav' )
		        ->get();

		$control->addText( 'prev_post' )
		        ->setLabel( esc_html__( 'Prev Post Title', 'ohixm' ), true )
		        ->setDefault( __( 'PREV', 'ohixm' ) )
		        ->setConditions( 'pagination_type', 'nav' )
		        ->get();


		$control->addText( 'load_more_post' )
		        ->setLabel( esc_html__( 'Load More Title', 'ohixm' ), true )
		        ->setDefault( __( 'Load More', 'ohixm' ) )
		        ->setConditions( 'pagination_type', 'ajax' )
		        ->get();


		$control->addText( 'no_more_post' )
		        ->setLabel( esc_html__( 'No More Title', 'ohixm' ), true )
		        ->setDynamicActive( true )
		        ->setDefault( __( 'No More', 'ohixm' ) )
		        ->setConditions( 'pagination_type', 'ajax' )
		        ->get();

		$control->getJustifyContent( 'pagination_justify_content', '.dsn-p-pag' )
		        ->setSeparator( "before" )
		        ->setConditions( 'pagination_type', '!==', 'none' )
		        ->getResponsive();


		$control->addSlider( 'dsn-paginate-space', [
			'label' => esc_html__( 'Spacing', 'ohixm' ),
			'range' => [
				'px' => [ 'max' => 100, ],
			],
		] )
		        ->setSelectors( '.dsn-p-pag', '--dsn-row-item:{{SIZE}}{{UNIT}}' )
		        ->setConditions( 'pagination_type', '!==', 'none' )
		        ->getResponsive();


		$this->end_controls_section();
	}

	private function filterBar() {
		$control = $this->getControl();

		$this->start_controls_section(
			'filter_bar_section',
			[
				'label' => esc_html__( 'Filter Bar', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control->addSwitcher( 'filter_bar' )
		        ->setLabel( esc_html__( 'Filter Bar', 'ohixm' ) )
		        ->get();

		$control->addText( 'filter_title' )
		        ->setLabel( esc_html__( 'Filter Title', 'ohixm' ),
			        true )
		        ->setDynamicActive( true )
		        ->setDefault( __( 'Filter', 'ohixm' ) )
		        ->setConditions( 'filter_bar',
			        '1' )
		        ->get();

		$control->addText( 'all_filter' )
		        ->setLabel( esc_html__( 'Button All Filter', 'ohixm' ), true )
		        ->setDefault( __( 'All', 'ohixm' ) )
		        ->setConditions( 'filter_bar', '1' )
		        ->get();

		$control->getJustifyContent( 'filter_bar_justify_content', '.dsn-filtering' )
		        ->setSeparator( "before" )
		        ->setConditions( 'filter_bar', '1' )
		        ->getResponsive();

		$this->Spacing( 'dsn-filtering-space', '.dsn-filtering' )
		     ->setConditions( 'filter_bar', '1' )
		     ->getResponsive();

		$this->end_controls_section();
	}


	private function styleLayoutTab() {
		$control = $this->getControl();


		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Layout',
					'ohixm' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		$this->getGridSpace();

		$control->addSlider( 'height',
			$control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( esc_html__( 'Height',
			        'ohixm' ) )
		        ->setSelectors( '.box-image-link .box-image-bg',
			        'height:{{SIZE}}{{UNIT}};max-height:{{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->getAlign()
		        ->setDefault( "left" )
		        ->getResponsive();

		$control->getJustifyContent( 'justify_content_posts', '.dsn-posts:not(.box-image-ohixm) .post-content' )
		        ->setCondition( [
			        'style_post'       => 'cards',
			        'style_cards_post' => [ 'box-image-normal', 'box-image-normal box-image-hover' ],
		        ] )
		        ->getResponsive();

		$control->addPaddingGroup( 'item_padding_box', '.root-posts .dsn-posts .box-content' )
		        ->setSeparator( "before" )
		        ->getResponsive();


		$control->addBorder( 'item_border_style_box', '.root-posts .dsn-posts .box-content' )
		        ->getGroup();

		$control->addSwitcher( 'remove_last_border' )
		        ->setLabel( esc_html__( "Remove Last Border", "ohixm" ) )
		        ->setReturn_value( 'dsn-remove-last-border' )
		        ->setPrefix_class()
		        ->get();

		$control->addBorderRadiusGroup( 'item_border_radius_box', '.root-posts .dsn-posts .dsn-item-post' )
		        ->getResponsive();

		$this->end_controls_section();


	}


	/**
	 * @param $id
	 * @param $key
	 * @param string $value
	 *
	 * @return ohixmControl|null
	 */
	private function Spacing( $id, $key, string $value = 'bottom' ) {
		$control = $this->getControl();

		return $control->addSlider( $id, [
			'label' => esc_html__( 'Spacing', 'ohixm' ),
			'range' => [
				'px' => [ 'max' => 100, ],
			],
		] )->setSelectors( $key, 'margin-' . $value . ':{{SIZE}}{{UNIT}}' );

	}


	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {


		ohixm_render_widget_motion_effect( $this, 'dsn-posts' );

		$this->add_inline_editing_attributes( 'start_up_title' );
		$this->add_inline_editing_attributes( 'end_up_title' );
		$this->add_inline_editing_attributes( 'start_down_title' );
		$this->add_inline_editing_attributes( 'end_down_title' );

		$shortcode     = new ohixmShortCode( array( 'widget-base' => $this ) );
		$query_post    = $shortcode->getVal( 'query_post', "post" );
		$post_per_page = $shortcode->getVal( 'post_per_page', 6 );
		$CurrentPage   = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 1;

		$offset    = $shortcode->getVal( 'offset', 0 );
		$orderby   = $shortcode->getVal( 'orderby', 'date' );
		$order     = $shortcode->getVal( 'order', 'DESC' );
		$tax_query = array(
			'relation' => 'OR',
			array(
				'taxonomy' => $query_post === ohixm_project_slug() ? ohixm_category_slug() : "category",
				'field'    => 'term_id',
				'terms'    => $shortcode->getVal( 'include_tax', [] ),
				'operator' => $shortcode->getVal( 'operator_tax', "NOT IN" ),
			),
		);


		$option_query = array(
			'paged'          => $CurrentPage,
			'posts_per_page' => $post_per_page,
			'post_type'      => $query_post,
			'offset'         => $offset,
			'orderby'        => $orderby,
			'order'          => $order,
			'tax_query'      => $tax_query
		);

		$myposts = new WP_Query( $option_query );


		$this->addPrefixClassLayout( 'dsn-posts', $shortcode );
		$this->addAnimateFade( 'dsn-item-content', $shortcode );
		$this->add_render_attribute( 'dsn-posts',
			[
				'class' => [
					'dsn-posts dsn-post-type-' . $shortcode->getVal( 'style_post', 'classic' ),
					$shortcode->getVal( 'scroll_horizontal' ),
					$shortcode->getVal( 'style_cards_post', '' ),
					$shortcode->getVal( 'filter_bar' ) && ! $shortcode->getVal( 'scroll_horizontal' ) ? 'use-filter' : ''
				]
			] );


		?>
        <div class="root-posts<?php echo esc_attr( $shortcode->getVal( 'filter_bar' ) && ! $shortcode->getVal( 'scroll_horizontal' ) ? ' has-filter' : '' ) ?>"
             style="--dsn-row-item:<?php echo esc_attr( $shortcode->getValueNumberSlide( 'row_layout_gap', 30 ) ) ?>px">
			<?php

			/**
			 * Filter
			 */
			if ( ! $shortcode->getVal( 'scroll_horizontal' ) ) {
				$this->add_inline_editing_attributes( 'filter_title', 'none' );
				$this->add_inline_editing_attributes( 'all_filter', 'none' );
				echo ohixm_shortcode_render( 'post/content/filter', $shortcode, [
					'my-posts' => $myposts,
				] );
			}


			/**
			 * Post Content
			 */
			printf( '<div %s>%s</div>',
				$this->get_render_attribute_string( 'dsn-posts' ),
				ohixm_shortcode_render_group( 'post', array( 'widget-base' => $this ), $myposts ) );


			/**
			 * Paginate
			 */
			echo ohixm_shortcode_render( 'post/content/paginate', $shortcode, [
				'my-posts'     => $myposts,
				'option_query' => $option_query
			] );
			?>
        </div>

		<?php


	}
}