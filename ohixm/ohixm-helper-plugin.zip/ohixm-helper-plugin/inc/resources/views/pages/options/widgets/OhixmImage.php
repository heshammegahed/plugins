<?php

use Dsn\Element\Ohixm_Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Image_Size;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}


/**
 * Elementor accordion widget.
 *
 * Elementor widget that displays a collapsible display of content in an
 * accordion style, showing only one item at a time.
 *
 * @since 1.0.0
 */
class OhixmImage extends Widget_Base {

	use Ohixm_Widget_Base;


	/**
	 * Get widget name.
	 *
	 * Retrieve accordion widget name.
	 *
	 * @return string Widget name.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_name(): string {
		return 'dsn_image';
	}


	/**
	 * Get widget title.
	 *
	 * Retrieve accordion widget title.
	 *
	 * @return string Widget title.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_title(): string {
		return esc_html__( 'Parallax Image', 'ohixm' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve accordion widget icon.
	 *
	 * @return string Widget icon.
	 * @since 1.0.0
	 * @access public
	 *
	 */
	public function get_icon(): string {
		return 'eicon-image-rollover';
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the widget belongs to.
	 *
	 * @return array Widget keywords.
	 * @since 2.1.0
	 * @access public
	 *
	 */
	public function get_keywords(): array {
		return array_merge( $this->dsn_keywords(), [ 'parallax', 'image' ] );
	}


	/**
	 * Register accordion widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function register_controls() {


		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'ohixm' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$control = $this->getControl();
		$control->getGroupImage();


		$this->getOverlay();

		$control->addBlendMode( 'bland_overlay', '.img-box-parallax img' )
		        ->get();


		$control->addPopover( 'position_image' )
		        ->setLabel( esc_html__( 'Position Image', 'ohixm' ) )
		        ->get();
		$this->start_popover();

		$control->addNumberSlider( 'position_image_position_x', 0, 100, 1 )
		        ->setLabel( esc_html__( 'Position X', 'ohixm' ) )
		        ->setDefaultRange( 50 )
		        ->setSelectors( 'img', 'object-position:{{SIZE}}% {{position_image_position_y.SIZE}}%' )
		        ->getResponsive();

		$control->addNumberSlider( 'position_image_position_y', 0, 100, 1 )
		        ->setLabel( esc_html__( 'Position Y', 'ohixm' ) )
		        ->setDefaultRange( 50 )
		        ->setSelectors( 'img', 'object-position:{{position_image_position_x.SIZE}}% {{SIZE}}%' )
		        ->getResponsive();


		$this->end_popover();

		$this->add_control(
			'view',
			[
				'label'   => esc_html__( 'View', 'elementor' ),
				'type'    => Controls_Manager::HIDDEN,
				'default' => 'traditional',
			]
		);


		$this->end_controls_section();
		$this->getEntranceAnimationImage();


		$this->popupImage();

		$this->styleTab();

	}


	protected function popupImage() {

		$this->start_controls_section(
			'dsn_option_popup',
			[
				'label' => esc_html__( 'Popup Image', 'ohixm' ),
			]
		);
		$this->add_control(
			'use_as_popup',
			[
				'label'        => esc_html__( 'Show On Popup', 'ohixm' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => '1',
				'default'      => '',
			]
		);
		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'      => 'size_img_popup',
				'default'   => 'large',
				'separator' => 'none',
				'condition' => [ 'use_as_popup' => '1' ],

			]
		);

		$this->getControl()
		     ->addText( 'group_by_fancybox' )
		     ->setLabel( esc_html__( 'Group By', 'ohixm' ) )
		     ->setConditions( 'use_as_popup', '1' )
		     ->get();


		$this->end_controls_section();
	}

	private function getOverlay() {
		$control = $this->getControl();

		$control->addPopover( 'opacity_overlay_popover' )
		        ->setLabel( esc_html__( "Background Overlay", 'elementor' ) )
		        ->setSeparator( "before" )
		        ->get();

		$this->start_popover();

		$control->addColor( 'color_overlay' )
		        ->setLabel( esc_html__( 'Color Overlay' ) )
		        ->get();

		$control->addNumberSlider( 'opacity_overlay', 0, 10, 1 )
		        ->setLabel( esc_html__( 'Opacity Overlay' ) )
		        ->setDefaultRange( 0 )
		        ->get();

		$this->end_popover();

	}

	private function getEntranceAnimationImage() {

		$this->start_controls_section(
			'dsn_option_motion_effects',
			[
				'label' => esc_html__( 'Image Motion Effects', 'ohixm' ),
			]
		);
		$control = $this->getControl();

		$control->addSwitcher( "use_scrolling_effects" )
		        ->setSeparator( "before" )
		        ->setLabel( esc_html__( 'Scrolling Effects', 'ohixm' ) )
		        ->setDefault( "1" )
		        ->get();


		$control->addChoose( 'effect_open_image' )
		        ->setLabel( esc_html__( "Effect Open Image", 'ohixm' ) )
		        ->setOptionChoose( '', esc_html__( 'None', 'ohixm' ), 'eicon-minus-square-o' )
		        ->setOptionChoose( 'dsn-animate dsn-effect-up', esc_html__( 'Up', 'ohixm' ), 'eicon-arrow-up' )
		        ->setOptionChoose( 'dsn-animate dsn-effect-right', esc_html__( 'Right', 'ohixm' ), 'eicon-arrow-right' )
		        ->setOptionChoose( 'dsn-animate dsn-effect-down', esc_html__( 'Down', 'ohixm' ), 'eicon-arrow-down' )
		        ->setOptionChoose( 'dsn-animate dsn-effect-left', esc_html__( 'Left', 'ohixm' ), 'eicon-arrow-left' )
		        ->setConditions( 'use_scrolling_effects', '1' )
		        ->setDefault( '' )
		        ->setToggle()
		        ->get();


		$control->addHidden( 'hidden_effect_image' )
		        ->setDefault( 'over-hidden' )
		        ->setPrefix_class()
		        ->setConditions( 'effect_open_image', '!=', '', 'and' )
		        ->setConditions( 'use_scrolling_effects', '==', '1', 'and' )
		        ->get();


		$control->addChoose( 'direction_animate_image' )
		        ->setLabel( esc_html__( "Direction", 'ohixm' ) )
		        ->setOptionChoose( 'has-opposite-direction', esc_html__( 'Up', 'ohixm' ), 'eicon-arrow-up' )
		        ->setOptionChoose( 'has-direction', esc_html__( 'Down', 'ohixm' ), 'eicon-arrow-down' )
		        ->setDefault( 'has-direction' )
		        ->setConditions( 'use_scrolling_effects', '1' )
		        ->get();

		$control->addSelect( 'animate_image_style', [
			''                 => esc_html__( "Default", 'ohixm' ),
			'has-bigger-scale' => esc_html__( "Scale Down", 'ohixm' ),
			'has-scale'        => esc_html__( "Scale Up", 'ohixm' ),
		] )
		        ->setLabel( esc_html__( "Entrance Animation Type", 'ohixm' ) )
		        ->setConditions( 'use_scrolling_effects', '1' )
		        ->setDefault( '' )->get();


		$control->getTriggerHock( 'animate_image_triggerhook' )
		        ->setConditions( 'use_scrolling_effects', '1' )
		        ->get();


		$control->addNumberSlider( 'speed_animation_image', 0, 100, 10 )
		        ->setDefaultRange( 30 )
		        ->setLabel( esc_html__( 'Speed', 'ohixm' ) )
		        ->setConditions( 'use_scrolling_effects', '1' )
		        ->get();

		$this->mouseEffects();
		$this->end_controls_section();

	}

	private function mouseEffects() {
		$control = $this->getControl();

		$control->addSwitcher( "mouse_effects" )
		        ->setLabel( esc_html__( 'Mouse Effects', 'ohixm' ) )
		        ->setSeparator( "before" )
		        ->get();

		$control->addSwitcher( "zoom" )
		        ->setLabel( esc_html__( 'Zoom Button', 'ohixm' ) )
		        ->setReturn_value( 'image-zoom' )
		        ->setConditions( 'mouse_effects', '1' )
		        ->get();


	}

	private function styleTab() {
		$control = $this->getControl();

		$this->start_controls_section(
			'style_image_section',
			[
				'label' => esc_html__( 'Image', 'elementor' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$control->addSwitcher( 'dsn_equal_height', [
			'label'        => esc_html__( 'Enable Equal Height', 'ohixm' ),
			'prefix_class' => 'dsn-equal-height ',
			'default'      => '',
		] )
		        ->setReturn_value( 'h-100' )
		        ->get();

		$control->addSelect( 'custom_position', [
			'inherit'  => esc_html__( 'inherit', 'ohixm' ),
			'relative' => esc_html__( 'relative', 'ohixm' ),
			'absolute' => esc_html__( 'absolute', 'ohixm' ),
		], [
			'label'         => esc_html__( 'Position', 'elementor' ),
			'default'       => 'relative',
			'selectors'     => [
				'{{WRAPPER}} ' => 'position: {{VALUE}};',
			],
			'hide_in_inner' => true,
		] )
		        ->setPrefix_class( 'dsn-position%s-' )
		        ->getResponsive();


		$control->addSlider( 'width', $control->getDefaultWidthHeight() )
		        ->setLabel( esc_html__( 'Width', 'elementor' ) )
		        ->setSelectors( '.img-box-parallax', 'width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSlider( 'space', $control->getDefaultWidthHeight() )
		        ->setLabel( esc_html__( 'Max Width', 'elementor' ) )
		        ->setSelectors( '.img-box-parallax', 'max-width: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->addSlider( 'height', $control->getDefaultWidthHeight( 'vh' ) )
		        ->setLabel( esc_html__( 'Height', 'elementor' ) )
		        ->setSelectors( '.img-box-parallax', 'height: {{SIZE}}{{UNIT}};' )
		        ->getResponsive();

		$control->getAlign()->getResponsive();


		$control->addSelect( 'object-fit', [
			''        => esc_html__( 'Default', 'elementor' ),
			'fill'    => esc_html__( 'Fill', 'elementor' ),
			'cover'   => esc_html__( 'Cover', 'elementor' ),
			'contain' => esc_html__( 'Contain', 'elementor' ),
		], [
			'label' => esc_html__( 'Object Fit', 'elementor' ),

			'options'   => [
				''        => esc_html__( 'Default', 'elementor' ),
				'fill'    => esc_html__( 'Fill', 'elementor' ),
				'cover'   => esc_html__( 'Cover', 'elementor' ),
				'contain' => esc_html__( 'Contain', 'elementor' ),
			],
			'default'   => '',
			'selectors' => [
				'{{WRAPPER}} .img-box-parallax img' => 'object-fit: {{VALUE}};',
			],
		] )->setSeparator( "before" )->get();

		$this->hoverImage();


		$this->end_controls_section();


	}

	private function hoverImage() {


		$this->start_controls_tabs( 'image_effects' );

		$this->start_controls_tab( 'normal',
			[
				'label' => esc_html__( 'Normal', 'elementor' ),
			]
		);

		$this->add_control(
			'opacity',
			[
				'label'     => esc_html__( 'Opacity', 'elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .img-box-parallax ' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'css_filters',
				'selector' => '{{WRAPPER}} .img-box-parallax ',
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab( 'hover',
			[
				'label' => esc_html__( 'Hover', 'elementor' ),
			]
		);

		$this->add_control(
			'opacity_hover',
			[
				'label'     => esc_html__( 'Opacity', 'elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 1,
						'min'  => 0.10,
						'step' => 0.01,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .img-box-parallax:hover ' => 'opacity: {{SIZE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Css_Filter::get_type(),
			[
				'name'     => 'css_filters_hover',
				'selector' => '{{WRAPPER}} .img-box-parallax:hover ',
			]
		);

		$this->add_control(
			'background_hover_transition',
			[
				'label'     => esc_html__( 'Transition Duration', 'elementor' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'max'  => 3,
						'step' => 0.1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .img-box-parallax ' => 'transition: {{SIZE}}s;',
				],
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Hover Animation', 'elementor' ),
				'type'  => Controls_Manager::HOVER_ANIMATION,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();


		$this->add_responsive_control(
			'image_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'elementor' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'separator'  => 'before',
				'selectors'  => [
					'{{WRAPPER}} .img-box-parallax  , {{WRAPPER}} .img-box-parallax img ' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name'     => 'image_box_shadow',
				'exclude'  => [
					'box_shadow_position',
				],
				'selector' => '{{WRAPPER}} .img-box-parallax , {{WRAPPER}} .img-box-parallax img',
			]
		);
	}

	/**
	 * Render accordion widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {
		$this->add_inline_editing_attributes( 'caption' );
		ohixm_render_widget_motion_effect( $this, 'parallax' );

		echo ohixm_shortcode_render_group( 'image', array( 'widget-base' => $this ) );
	}


	public function get_style_depends() {
		return $this->getDepends();
	}

	public function get_script_depends() {
		return $this->getDepends();
	}

	private function getDepends() {

		if ( ohixm_is_built_with_elementor() ) {
			return [ OhixmFrontEnd::FANCYBOX ];
		}
		$out       = [];
		$shortcode = $this->getShortCode();
		if ( $shortcode->getVal( 'use_as_popup' ) ) {
			$out[] = OhixmFrontEnd::FANCYBOX;
		}

		return $out;
	}

}
