<?php

use Elementor\Controls_Manager;
use Elementor\Core\DocumentTypes\PageBase;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}




/**
 * Page Header in Elementor Document Settings
 */
add_action( 'elementor/element/wp-page/document_settings/after_section_end', 'ohixm_document_settings_page_footer' );
add_action( 'elementor/element/wp-post/document_settings/after_section_end', 'ohixm_document_settings_page_footer' );
function ohixm_document_settings_page_footer( PageBase $page ) {

//	if ( ohixm_is_work() )
//		return;

	$control = new OhixmControl( $page );

	$page->start_controls_section(
		'page_footer_section',
		array(
			'label' => esc_html__( 'Footer', 'ohixm' ),
			'tab'   => Controls_Manager::TAB_SETTINGS,
		)
	);


	$control->addSwitcher( 'show_footer' )
	        ->setLabel( esc_html__( 'Show Footer', 'ohixm' ) )
	        ->setDefault( '1' )
	        ->get();

	$control->addSelect( 'dsn_footer_layout', [
		''                                  => __( 'Default', 'ohixm' ),
		'dsn-container'                     => __( 'Wide Page', 'ohixm' ),
		'container'                         => __( 'Container Page', 'ohixm' ),
		'dsn-container dsn-right-container' => __( 'Right Container Page', 'ohixm' ),
		'dsn-container dsn-left-container'  => __( 'Left Container Page', 'ohixm' ),
	] )
	        ->setDefault( '' )
	        ->setLabel( __( 'Width Layout', 'ohixm' ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();

	$control->addSelect( 'dsn_footer_bg_ver', [
		''             => __( 'Default', 'ohixm' ),
		'v-light'      => __( 'Light', 'ohixm' ),
		'v-light-head' => __( 'Light (Static)', 'ohixm' ),
		'v-dark'       => __( 'Dark', 'ohixm' ),
		'v-dark-head'  => __( 'Dark  (Static)', 'ohixm' ),
	] )
	        ->setDefault( '' )
	        ->setLabelBlock()
	        ->setLabel( __( 'Version Background Section', 'ohixm' ) )
	        ->setDescription( __( 'If you choose the wallpaper version, it is best to choose the type of background section',
		        'ohixm' ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();

	$control->addSelect( 'dsn_footer_bg', [
		'background-transparent' => __( 'Default', 'ohixm' ),
		'background-main'        => __( 'Background Main', 'ohixm' ),
		'background-section'     => __( 'Background Section', 'ohixm' ),
		'background-theme'       => __( 'Background Theme', 'ohixm' ),
	] )
	        ->setLabelBlock()
	        ->setDefault( 'background-section' )
	        ->setLabel( __( 'Background Section', 'ohixm' ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();

	$control->addSelect( 'type_footer', [
		'default' => esc_html__( "Default", "ohixm" ),
		'custom'  => esc_html__( "Custom", "ohixm" )
	] )
	        ->setDefault( 'default' )
	        ->setSeparatorBefore()
	        ->setLabel( esc_html__( "Type Footer", "ohixm" ) )
	        ->setConditions( 'show_footer', '1' )
	        ->get();


	$control->addSelect2( 'choose_template_footer', ohixm_get_post_array( ohixm_footer_slug() ) )
	        ->setDefault( 'default' )
	        ->setLabelBlock()
	        ->setLabel( esc_html__( "Choose Template Footer", "ohixm" ) )
	        ->setConditions( 'show_footer', '===', '1' )
	        ->setConditions( 'type_footer', '===', 'custom', 'and' )
	        ->get();

	$page->end_controls_section();

}