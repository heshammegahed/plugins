<?php

/**
 * Plugin Name: OHIXM Functionality Plugins
 * Plugin URI: https://themeforest.net/user/design_grid
 * Description: Core Plugin for OHIXM WordPress Theme
 * Version: 1.1.0
 * Author URI: https://themeforest.net/user/design_grid
 * Text Domain: ohixm
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

define( 'OHIXM__PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'OHIXM__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'OHIXM__PLUGIN_DIR_URL', plugin_dir_url( __FILE__ ) );
define( 'OHIXM_MODULES_PATH', plugin_dir_url( __FILE__ ) . '/modules' );


class OhixmHelperPlugin {


	public function __construct() {
		$this->include_helper_files();

	}

	public function include_files( $files, $suffix = '' ) {
		foreach ( $files as $file ) {
			$filepath = OHIXM__PLUGIN_DIR . $suffix . $file . '.php';
			if ( ! file_exists( $filepath ) ) :
				trigger_error( sprintf( esc_html__( 'Error locating %s for inclusion', 'ohixm' ), $file ),
					E_USER_ERROR );
			endif;
			require_once $filepath;
		}
		unset( $file, $filepath );
	}

	public function include_helper_files() {

		$files = array(
			'ohixm-filter',
			'ohixm-function-helper',
			'OhixmFrontEnd',
			'ohixmBootstrapTemplate',
			'ohixm-function-widget',
			'OhixmAdminPost',
			'views/shortcode/ohixmShortCode',

			'ohixmStyle',


			'resources/views/pages/options/inc/notices',
			'resources/views/pages/options/widgets/control/OhixmRenderSectionElement',
			'resources/views/pages/options/widgets/control/OhixmRegisterElement',
			'resources/views/pages/options/widgets/control/Ohixm_Widget_Base',
			'resources/views/pages/options/widgets/control/OhixmSwiper',
		);
		$this->include_files( $files, 'inc/' );


	}


}


function ohixmDev(): OhixmHelperPlugin {

	if ( defined( 'OHIXM_DIRECTORY' ) && file_exists( OHIXM_DIRECTORY . '/inc/classes/OhixmTemplate.php' ) )
		require_once OHIXM_DIRECTORY . '/inc/classes/OhixmTemplate.php';

	add_action( 'wp_body_open', function () {
		echo '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="143.687px" height="139.25px" viewBox="0 0 143.687 139.25" enable-background="new 0 0 143.687 139.25"
	 xml:space="preserve" style="position:absolute;opacity: 0;transform: translateY(-150%)">
		<path id="circlePath" fill="none" d="M1.743,69.427c0-33.137,26.863-60,60-60c33.137,0,60,26.863,60,60c0,33.137-26.863,60-60,60
			C28.606,129.427,1.743,102.563,1.743,69.427"/>
	
</svg>
';
	} );


	return new OhixmHelperPlugin();
}

add_action( 'ohixm_developer', function ( $array = array() ) {


	ohixmDev();

	foreach ( $array as $value ):
		ohixm_resources( $value );
	endforeach;
} );
